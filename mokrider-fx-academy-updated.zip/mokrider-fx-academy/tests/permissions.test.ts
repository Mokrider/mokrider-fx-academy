import { describe, expect, it } from "vitest";
import { can, hasRoleAtLeast } from "@/lib/permissions";

describe("permissions", () => {
  it("guests have no access", () => {
    expect(hasRoleAtLeast(null, "STUDENT")).toBe(false);
    expect(can(undefined, "admin:access")).toBe(false);
  });
  it("only admins reach the admin area", () => {
    expect(can("STUDENT", "admin:access")).toBe(false);
    expect(can("MEMBER", "admin:access")).toBe(false);
    expect(can("MENTOR", "admin:access")).toBe(false);
    expect(can("ADMIN", "admin:access")).toBe(true);
  });
  it("mentors can manage content but not users", () => {
    expect(can("MENTOR", "content:manage")).toBe(true);
    expect(can("MENTOR", "users:manage")).toBe(false);
  });
  it("roles are ordered", () => {
    expect(hasRoleAtLeast("ADMIN", "MENTOR")).toBe(true);
    expect(hasRoleAtLeast("STUDENT", "MEMBER")).toBe(false);
  });
});
