import { describe, expect, it } from "vitest";
import { gmailUrl, mailtoUrl, outlookUrl, whatsappDigits, whatsappUrl } from "../src/lib/contact";

const msg = { subject: "Hi & hello", body: "Line 1\nLine 2" };

describe("whatsappDigits", () => {
  it("turns local Kenyan numbers into 254 numbers", () => {
    expect(whatsappDigits("0712 345 678")).toBe("254712345678");
    expect(whatsappDigits("0112345678")).toBe("254112345678");
    expect(whatsappDigits("712345678")).toBe("254712345678");
  });
  it("keeps international numbers and strips punctuation", () => {
    expect(whatsappDigits("+254 712-345-678")).toBe("254712345678");
    expect(whatsappDigits("00254712345678")).toBe("254712345678");
  });
  it("returns an empty string for unusable input", () => {
    expect(whatsappDigits("")).toBe("");
    expect(whatsappDigits(undefined)).toBe("");
    expect(whatsappDigits("abc")).toBe("");
    expect(whatsappDigits("123")).toBe("");
  });
});

describe("link builders", () => {
  it("encodes the subject and body", () => {
    expect(mailtoUrl("a@b.co", msg)).toBe("mailto:a@b.co?subject=Hi%20%26%20hello&body=Line%201%0ALine%202");
    expect(gmailUrl("a@b.co", msg)).toContain("su=Hi%20%26%20hello");
    expect(outlookUrl("a@b.co", msg)).toContain("subject=Hi%20%26%20hello");
  });
  it("builds a wa.me link only when there is a number", () => {
    expect(whatsappUrl("0712345678", "Hello there")).toBe("https://wa.me/254712345678?text=Hello%20there");
    expect(whatsappUrl("", "Hello")).toBeNull();
  });
});
