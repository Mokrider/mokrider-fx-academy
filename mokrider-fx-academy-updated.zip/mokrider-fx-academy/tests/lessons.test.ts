import { describe, expect, it } from "vitest";
import { toEmbedUrl } from "@/lib/learning/video";
import { firstIncomplete, neighbours } from "@/lib/learning/nav";

describe("video embeds", () => {
  it("accepts YouTube links in common forms", () => {
    const want = "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ";
    expect(toEmbedUrl("https://www.youtube.com/watch?v=dQw4w9WgXcQ")).toBe(want);
    expect(toEmbedUrl("https://youtu.be/dQw4w9WgXcQ")).toBe(want);
    expect(toEmbedUrl("https://www.youtube.com/embed/dQw4w9WgXcQ")).toBe(want);
  });
  it("accepts Vimeo links", () => {
    expect(toEmbedUrl("https://vimeo.com/123456789")).toBe("https://player.vimeo.com/video/123456789");
    expect(toEmbedUrl("https://player.vimeo.com/video/123456789")).toBe("https://player.vimeo.com/video/123456789");
  });
  it("rejects other providers, plain http and junk", () => {
    expect(toEmbedUrl("https://evil.example.com/watch?v=dQw4w9WgXcQ")).toBeNull();
    expect(toEmbedUrl("http://www.youtube.com/watch?v=dQw4w9WgXcQ")).toBeNull();
    expect(toEmbedUrl("https://www.youtube.com/watch?v=short")).toBeNull();
    expect(toEmbedUrl("javascript:alert(1)")).toBeNull();
    expect(toEmbedUrl("not a url")).toBeNull();
  });
});

describe("lesson navigation", () => {
  const order = [{ id: "a" }, { id: "b" }, { id: "c" }];
  it("finds neighbours", () => {
    expect(neighbours(order, "a")).toEqual({ prev: null, next: "b" });
    expect(neighbours(order, "b")).toEqual({ prev: "a", next: "c" });
    expect(neighbours(order, "c")).toEqual({ prev: "b", next: null });
    expect(neighbours(order, "zzz")).toEqual({ prev: null, next: null });
  });
  it("finds the first incomplete lesson", () => {
    expect(firstIncomplete(order, new Set(["a"]))).toBe("b");
    expect(firstIncomplete(order, new Set())).toBe("a");
    expect(firstIncomplete(order, new Set(["a", "b", "c"]))).toBeNull();
    expect(firstIncomplete([], new Set())).toBeNull();
  });
});
