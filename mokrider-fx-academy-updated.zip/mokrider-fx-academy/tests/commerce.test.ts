import { describe, expect, it } from "vitest";
import { effectivePriceMinor, isWholeShillings, orderTotals } from "@/lib/commerce/pricing";
import { last4, normalizeKenyanPhone } from "@/lib/commerce/phone";
import { PAYABLE_STATUSES, canTransition, referenceFrom } from "@/lib/commerce/orders";
import { parseCart, serializeCart } from "@/lib/commerce/cart";
import { MAX_UPLOAD_BYTES, detectFileType } from "@/lib/commerce/fileType";
import { darajaTimestamp, mapResultCode, parseStkCallback, stkPassword } from "@/lib/mpesa/parse";

describe("pricing", () => {
  const now = new Date("2026-11-01T00:00:00Z");
  it("uses the sale price only while the discount is active", () => {
    const p = { priceMinor: 100000, discountMinor: 70000, discountEndsAt: null };
    expect(effectivePriceMinor(p, now)).toBe(70000);
    expect(effectivePriceMinor({ ...p, discountEndsAt: new Date("2026-12-01T00:00:00Z") }, now)).toBe(70000);
    expect(effectivePriceMinor({ ...p, discountEndsAt: new Date("2026-10-01T00:00:00Z") }, now)).toBe(100000);
  });
  it("ignores a sale price that is not lower", () => {
    expect(effectivePriceMinor({ priceMinor: 100000, discountMinor: 100000, discountEndsAt: null }, now)).toBe(100000);
    expect(effectivePriceMinor({ priceMinor: 100000, discountMinor: null, discountEndsAt: null }, now)).toBe(100000);
  });
  it("requires whole shillings for M-Pesa", () => {
    expect(isWholeShillings(150000)).toBe(true);
    expect(isWholeShillings(150050)).toBe(false);
    expect(isWholeShillings(0)).toBe(true);
    expect(isWholeShillings(-100)).toBe(false);
  });
  it("totals orders", () => {
    expect(orderTotals([{ listMinor: 100000, unitMinor: 70000 }, { listMinor: 50000, unitMinor: 50000 }])).toEqual({ subtotalMinor: 150000, discountMinor: 30000, totalMinor: 120000 });
  });
});

describe("phone numbers", () => {
  it("normalises common Kenyan formats", () => {
    for (const v of ["0712345678", "+254712345678", "254712345678", "712345678", "0712 345 678", "07-12345678"]) expect(normalizeKenyanPhone(v)).toBe("254712345678");
    expect(normalizeKenyanPhone("0112345678")).toBe("254112345678");
  });
  it("rejects invalid numbers", () => {
    for (const v of ["", "12345", "0612345678", "+255712345678", "07123456789", "abc"]) expect(normalizeKenyanPhone(v)).toBeNull();
    expect(last4("254712345678")).toBe("5678");
  });
});

describe("order rules", () => {
  it("allows only sensible transitions", () => {
    expect(canTransition("AWAITING_PAYMENT", "PAID")).toBe(true);
    expect(canTransition("PAID", "REFUNDED")).toBe(true);
    expect(canTransition("PAID", "AWAITING_PAYMENT")).toBe(false);
    expect(canTransition("REFUNDED", "PAID")).toBe(false);
    expect(canTransition("CANCELLED", "PAID")).toBe(false);
    expect(PAYABLE_STATUSES.includes("PAID")).toBe(false);
  });
  it("builds readable references", () => {
    const ref = referenceFrom(new Date("2026-11-01T10:00:00Z"), new Uint8Array([0, 1, 2, 3, 31, 30]));
    expect(ref).toBe("MFX-261101-0123ZY");
    expect(ref).toMatch(/^MFX-\d{6}-[0-9A-HJKMNP-TV-Z]{6}$/);
  });
});

describe("cart cookie", () => {
  it("round-trips and drops junk", () => {
    const items = parseCart("p:abcdefghij1,c:abcdefghij2,p:abcdefghij1,x:abcdefghij3,p:short,<script>");
    expect(items).toEqual([{ kind: "PRODUCT", id: "abcdefghij1" }, { kind: "COURSE", id: "abcdefghij2" }]);
    expect(parseCart(serializeCart(items))).toEqual(items);
    expect(parseCart(undefined)).toEqual([]);
  });
  it("caps the cart size", () => {
    const raw = Array.from({ length: 40 }, (_, i) => `p:product${String(i).padStart(4, "0")}`).join(",");
    expect(parseCart(raw).length).toBe(20);
  });
});

describe("upload checks", () => {
  it("identifies files by content", () => {
    expect(detectFileType(new TextEncoder().encode("%PDF-1.7 ..."))?.ext).toBe("pdf");
    expect(detectFileType(new Uint8Array([0x50, 0x4b, 0x03, 0x04, 1]))?.ext).toBe("zip");
    expect(detectFileType(new TextEncoder().encode("<html>"))).toBeNull();
    expect(detectFileType(new Uint8Array([0x4d, 0x5a, 0x90]))).toBeNull(); // Windows executable
    expect(MAX_UPLOAD_BYTES).toBe(4194304);
  });
});

describe("M-Pesa helpers", () => {
  it("builds the Daraja timestamp in East Africa Time", () => {
    expect(darajaTimestamp(new Date("2026-11-01T21:30:05Z"))).toBe("20261102003005");
  });
  it("builds the STK password", () => {
    expect(stkPassword("174379", "KEY", "20261102003005")).toBe(Buffer.from("174379KEY20261102003005").toString("base64"));
  });
  it("maps result codes", () => {
    expect(mapResultCode("0")).toBe("SUCCEEDED");
    expect(mapResultCode(0)).toBe("SUCCEEDED");
    expect(mapResultCode("1032")).toBe("CANCELLED");
    expect(mapResultCode(1037)).toBe("TIMED_OUT");
    expect(mapResultCode("1")).toBe("FAILED");
  });
  it("parses a successful callback", () => {
    const body = { Body: { stkCallback: { MerchantRequestID: "29115-34620561-1", CheckoutRequestID: "ws_CO_191220191020363925", ResultCode: 0, ResultDesc: "The service request is processed successfully.",
      CallbackMetadata: { Item: [{ Name: "Amount", Value: 1 }, { Name: "MpesaReceiptNumber", Value: "NLJ7RT61SV" }, { Name: "TransactionDate", Value: 20191219102115 }, { Name: "PhoneNumber", Value: 254708374149 }] } } } };
    expect(parseStkCallback(body)).toEqual({ checkoutRequestId: "ws_CO_191220191020363925", merchantRequestId: "29115-34620561-1", resultCode: 0,
      resultDesc: "The service request is processed successfully.", amount: 1, receipt: "NLJ7RT61SV", transactionDate: "20191219102115" });
  });
  it("parses a cancelled callback and rejects junk", () => {
    const cancelled = parseStkCallback({ Body: { stkCallback: { CheckoutRequestID: "ws_CO_1", ResultCode: 1032, ResultDesc: "Request cancelled by user" } } });
    expect(cancelled?.resultCode).toBe(1032);
    expect(cancelled?.receipt).toBeNull();
    expect(parseStkCallback({})).toBeNull();
    expect(parseStkCallback("hi")).toBeNull();
    expect(parseStkCallback({ Body: { stkCallback: { CheckoutRequestID: "x", ResultCode: "abc" } } })).toBeNull();
  });
  it("ignores a malformed receipt number", () => {
    const r = parseStkCallback({ Body: { stkCallback: { CheckoutRequestID: "ws_1", ResultCode: 0, CallbackMetadata: { Item: [{ Name: "MpesaReceiptNumber", Value: "<b>x</b>" }] } } } });
    expect(r?.receipt).toBeNull();
  });
});
