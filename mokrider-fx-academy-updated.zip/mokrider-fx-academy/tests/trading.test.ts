import { describe, expect, it } from "vitest";
import { calcPositionSize, roundDownToStep } from "@/lib/trading/positionSize";
import { calcRiskReward, checkTradeLevels } from "@/lib/trading/riskReward";
import { calcCompounding } from "@/lib/trading/compounding";
import { moveValue, pipsToPrice, valuePerPipPerLot } from "@/lib/trading/pips";
import { SESSIONS, isSessionOpen, sessionWindow, zonedLocalToUtc } from "@/lib/trading/sessions";
import { journalStats } from "@/lib/trading/journalStats";
import { parseNum } from "@/lib/trading/num";
import { parseSignedMajorToMinor } from "@/lib/money";

const london = SESSIONS.find((s) => s.id === "london")!;
const newyork = SESSIONS.find((s) => s.id === "newyork")!;

describe("position size", () => {
  const base = { balance: 1000, riskPercent: 1, contractSize: 100000, quoteToAccountRate: 1, lotStep: 0.01, minLot: 0.01 };
  it("EURUSD 20 pip stop risking 1% of 1000 USD is 0.05 lots", () => {
    const r = calcPositionSize({ ...base, entry: 1.1, stop: 1.098 });
    expect(r.ok && r.lots).toBe(0.05);
    expect(r.ok && Math.round(r.actualRisk)).toBe(10);
  });
  it("Gold uses its own contract size", () => {
    const r = calcPositionSize({ balance: 5000, riskPercent: 1, entry: 2000, stop: 1990, contractSize: 100, quoteToAccountRate: 1, lotStep: 0.01, minLot: 0.01 });
    expect(r.ok && r.lots).toBe(0.05);
  });
  it("converts currency with the supplied rate and rounds down", () => {
    const r = calcPositionSize({ ...base, balance: 100000, quoteToAccountRate: 129, entry: 1.1, stop: 1.098 });
    expect(r.ok && r.lots).toBe(0.03);
    expect(r.ok && r.actualRisk).toBeLessThanOrEqual(1000);
  });
  it("warns and returns zero lots when the minimum lot is too big", () => {
    const r = calcPositionSize({ ...base, balance: 100, entry: 1.1, stop: 1.09 });
    expect(r.ok && r.lots).toBe(0);
    expect(r.ok && r.warnings[0]).toContain("minimum lot");
  });
  it("rejects bad input", () => {
    expect(calcPositionSize({ ...base, entry: 1.1, stop: 1.1 }).ok).toBe(false);
    expect(calcPositionSize({ ...base, riskPercent: 0, entry: 1.1, stop: 1.09 }).ok).toBe(false);
    expect(calcPositionSize({ ...base, quoteToAccountRate: 0, entry: 1.1, stop: 1.09 }).ok).toBe(false);
  });
  it("rounds down to the lot step", () => {
    expect(roundDownToStep(0.0399, 0.01)).toBe(0.03);
    expect(roundDownToStep(0.05, 0.01)).toBe(0.05);
  });
});

describe("risk reward", () => {
  it("computes ratio and break-even win rate", () => {
    const r = calcRiskReward({ direction: "LONG", entry: 100, stop: 95, target: 115 });
    expect(r.ok && r.ratio).toBe(3);
    expect(r.ok && r.breakEvenWinRate).toBe(25);
  });
  it("rejects levels on the wrong side", () => {
    expect(calcRiskReward({ direction: "LONG", entry: 100, stop: 105, target: 110 }).ok).toBe(false);
    expect(calcRiskReward({ direction: "SHORT", entry: 100, stop: 105, target: 110 }).ok).toBe(false);
    expect(checkTradeLevels("SHORT", 100, 105, 90)).toBeNull();
  });
  it("prices the trade only when contract details are given", () => {
    const r = calcRiskReward({ direction: "LONG", entry: 2000, stop: 1990, target: 2030, lots: 0.1, contractSize: 100, quoteToAccountRate: 1 });
    expect(r.ok && r.lossAtStop).toBe(100);
    expect(r.ok && r.profitAtTarget).toBe(300);
  });
});

describe("compounding", () => {
  it("compounds each period", () => {
    const r = calcCompounding({ start: 1000, contribution: 0, periods: 2, ratePercent: 10 });
    expect(r.ok && Math.round(r.final * 100) / 100).toBe(1210);
  });
  it("adds contributions", () => {
    const r = calcCompounding({ start: 0, contribution: 100, periods: 3, ratePercent: 0 });
    expect(r.ok && r.final).toBe(300);
    expect(r.ok && r.contributed).toBe(300);
  });
  it("validates", () => {
    expect(calcCompounding({ start: 1000, contribution: 0, periods: 0, ratePercent: 5 }).ok).toBe(false);
    expect(calcCompounding({ start: 1000, contribution: 0, periods: 12, ratePercent: -100 }).ok).toBe(false);
  });
});

describe("pips", () => {
  it("EURUSD is 10 USD per pip per standard lot", () => expect(valuePerPipPerLot(0.0001, 100000)).toBe(10));
  it("converts pips and values", () => {
    expect(pipsToPrice(20, 0.0001)).toBe(0.002);
    expect(moveValue(0.002, 0.5, 100000, 1)).toBe(100);
  });
});

describe("sessions and daylight saving", () => {
  it("London opens at 07:00 UTC in summer and 08:00 UTC in winter", () => {
    expect(zonedLocalToUtc(2026, 7, 1, 8, 0, "Europe/London").toISOString()).toBe("2026-07-01T07:00:00.000Z");
    expect(zonedLocalToUtc(2026, 12, 1, 8, 0, "Europe/London").toISOString()).toBe("2026-12-01T08:00:00.000Z");
  });
  it("New York shifts when US daylight saving ends (1 Nov 2026)", () => {
    expect(zonedLocalToUtc(2026, 10, 30, 8, 0, "America/New_York").toISOString()).toBe("2026-10-30T12:00:00.000Z");
    expect(zonedLocalToUtc(2026, 11, 2, 8, 0, "America/New_York").toISOString()).toBe("2026-11-02T13:00:00.000Z");
  });
  it("reports open and closed correctly", () => {
    expect(isSessionOpen(london, new Date("2026-07-01T06:30:00Z"))).toBe(false);
    expect(isSessionOpen(london, new Date("2026-07-01T07:30:00Z"))).toBe(true);
    expect(isSessionOpen(london, new Date("2026-07-04T10:00:00Z"))).toBe(false); // Saturday
    expect(isSessionOpen(newyork, new Date("2026-11-02T12:30:00Z"))).toBe(false);
    expect(isSessionOpen(newyork, new Date("2026-11-02T13:30:00Z"))).toBe(true);
  });
  it("gives the window for the session's own day", () => {
    const w = sessionWindow(london, new Date("2026-07-01T12:00:00Z"));
    expect(w.start.toISOString()).toBe("2026-07-01T07:00:00.000Z");
    expect(w.end.toISOString()).toBe("2026-07-01T16:00:00.000Z");
  });
});

describe("journal statistics", () => {
  const t = (d: number) => new Date(Date.UTC(2026, 10, d));
  const rows = [
    { tradedAt: t(1), instrument: "XAUUSD", setup: "FVG", currency: "USD", resultMinor: 10000, plannedRiskMinor: 5000 },
    { tradedAt: t(2), instrument: "XAUUSD", setup: "FVG", currency: "USD", resultMinor: -5000, plannedRiskMinor: 5000 },
    { tradedAt: t(3), instrument: "EURUSD", setup: null, currency: "USD", resultMinor: 10000, plannedRiskMinor: null },
    { tradedAt: t(4), instrument: "EURUSD", setup: null, currency: "USD", resultMinor: -5000, plannedRiskMinor: null },
    { tradedAt: t(5), instrument: "EURUSD", setup: null, currency: "USD", resultMinor: null, plannedRiskMinor: null },
    { tradedAt: t(6), instrument: "EURUSD", setup: null, currency: "KES", resultMinor: 100, plannedRiskMinor: null },
  ];
  const s = journalStats(rows);
  const usd = s.byCurrency.find((c) => c.currency === "USD")!;
  it("keeps currencies separate and counts open trades", () => {
    expect(s.byCurrency.map((c) => c.currency)).toEqual(["KES", "USD"]);
    expect(s.openEntries).toBe(1);
  });
  it("computes the core numbers", () => {
    expect(usd.closed).toBe(4);
    expect(usd.winRate).toBe(0.5);
    expect(usd.netMinor).toBe(10000);
    expect(usd.profitFactor).toBe(2);
    expect(usd.payoffRatio).toBe(2);
    expect(usd.maxDrawdownMinor).toBe(5000);
  });
  it("averages R only where planned risk exists and flags small samples", () => {
    expect(usd.rCount).toBe(2);
    expect(usd.avgR).toBe(0.5);
    expect(usd.smallSample).toBe(true);
  });
  it("has no profit factor without losing trades", () => {
    expect(s.byCurrency.find((c) => c.currency === "KES")!.profitFactor).toBeNull();
  });
});

describe("input parsing", () => {
  it("parses numbers", () => {
    expect(parseNum("1,250.5")).toBe(1250.5);
    expect(parseNum("")).toBeNull();
    expect(parseNum("abc")).toBeNull();
  });
  it("parses signed money", () => {
    expect(parseSignedMajorToMinor("-12.50", "USD")).toBe(-1250);
    expect(parseSignedMajorToMinor("+3", "USD")).toBe(300);
    expect(parseSignedMajorToMinor("-0", "USD")).toBe(0);
    expect(parseSignedMajorToMinor("x", "USD")).toBeNull();
  });
});
