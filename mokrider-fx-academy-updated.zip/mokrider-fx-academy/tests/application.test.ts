import { describe, expect, it } from "vitest";
import { cleanContactPhone } from "@/lib/commerce/phone";
import { BOTTLENECKS, EXPERIENCE, FOCUS, labelFor, values } from "@/content/application";

describe("contact phone numbers", () => {
  it("accepts international formats and strips punctuation", () => {
    expect(cleanContactPhone("+254 712-345-678")).toBe("+254712345678");
    expect(cleanContactPhone("(020) 123 4567")).toBe("0201234567");
  });
  it("rejects junk", () => {
    expect(cleanContactPhone("07123")).toBeNull();
    expect(cleanContactPhone("abc")).toBeNull();
    expect(cleanContactPhone("+1234567890123456")).toBeNull();
    expect(cleanContactPhone("")).toBeNull();
  });
});

describe("application options", () => {
  it("has unique values and readable labels", () => {
    for (const list of [EXPERIENCE, BOTTLENECKS, FOCUS]) {
      const v = values(list);
      expect(new Set(v).size).toBe(v.length);
    }
    expect(labelFor(EXPERIENCE, "1_2_years")).toBe("1 to 2 years");
    expect(labelFor(FOCUS, "nope")).toBe("nope");
  });
});
