import { describe, expect, it } from "vitest";
import { parseLines, parseTags, readingMinutes, slugify } from "@/lib/text";
import { formatEat, parseEatInput, toEatInput } from "@/lib/time";
import { isVisible, resolvePublishedAt } from "@/lib/publishing";

describe("text helpers", () => {
  it("slugifies", () => {
    expect(slugify("  Gold: Session Highs & Lows!  ")).toBe("gold-session-highs-lows");
    expect(slugify("Café Prices")).toBe("cafe-prices");
  });
  it("estimates reading time with a minimum of one minute", () => {
    expect(readingMinutes("short")).toBe(1);
    expect(readingMinutes(Array(450).fill("word").join(" "))).toBe(3);
  });
  it("parses tags and lines", () => {
    expect(parseTags("Gold, gold , Risk Management")).toEqual(["gold", "risk-management"]);
    expect(parseLines("a\n\n b \r\n")).toEqual(["a", "b"]);
  });
});

describe("East Africa Time", () => {
  it("round-trips datetime-local values", () => {
    const d = parseEatInput("2026-11-02T09:30");
    expect(d?.toISOString()).toBe("2026-11-02T06:30:00.000Z");
    expect(toEatInput(d)).toBe("2026-11-02T09:30");
  });
  it("rejects bad input", () => {
    expect(parseEatInput("tomorrow")).toBeNull();
    expect(parseEatInput("")).toBeNull();
  });
  it("formats with the EAT label", () => {
    expect(formatEat(new Date("2026-11-02T06:30:00Z"))).toContain("EAT");
  });
});

describe("publishing rules", () => {
  const now = new Date("2026-11-01T12:00:00Z");
  const later = new Date("2026-11-05T12:00:00Z");
  it("uses the scheduled time for scheduled items", () => {
    expect(resolvePublishedAt("SCHEDULED", later, null, now)).toEqual(later);
  });
  it("keeps the original publish time when re-saving a published item", () => {
    const earlier = new Date("2026-10-01T00:00:00Z");
    expect(resolvePublishedAt("PUBLISHED", null, earlier, now)).toEqual(earlier);
    expect(resolvePublishedAt("PUBLISHED", null, null, now)).toEqual(now);
  });
  it("hides drafts, archived and future-scheduled items", () => {
    expect(isVisible("DRAFT", now, now)).toBe(false);
    expect(isVisible("ARCHIVED", now, now)).toBe(false);
    expect(isVisible("SCHEDULED", later, now)).toBe(false);
    expect(isVisible("SCHEDULED", now, now)).toBe(true);
    expect(isVisible("PUBLISHED", null, now)).toBe(false);
  });
});
