import { describe, expect, it } from "vitest";
import { buildCsp } from "@/lib/security/csp";
import { securityHeaders } from "@/lib/security/headers";

describe("content security policy", () => {
  const prod = buildCsp(true);
  it("locks down plugins, framing and form targets", () => {
    expect(prod).toContain("object-src 'none'");
    expect(prod).toContain("frame-ancestors 'none'");
    expect(prod).toContain("form-action 'self'");
    expect(prod).toContain("base-uri 'self'");
  });
  it("allows video embeds only from YouTube and Vimeo", () => {
    expect(prod).toContain("frame-src https://www.youtube-nocookie.com https://player.vimeo.com");
  });
  it("does not allow eval or websockets in production", () => {
    expect(prod).not.toContain("unsafe-eval");
    expect(prod).not.toContain("ws:");
    expect(prod).toContain("upgrade-insecure-requests");
  });
  it("relaxes only what development needs", () => {
    const dev = buildCsp(false);
    expect(dev).toContain("'unsafe-eval'");
    expect(dev).not.toContain("upgrade-insecure-requests");
  });
});

describe("security headers", () => {
  it("adds CSP and HSTS only in production", () => {
    expect(securityHeaders({ NODE_ENV: "development" })).toEqual({});
    const h = securityHeaders({ NODE_ENV: "production" });
    expect(Object.keys(h)).toContain("Content-Security-Policy");
    expect(h["Strict-Transport-Security"]).toContain("max-age=");
  });
  it("supports report-only mode", () => {
    const h = securityHeaders({ NODE_ENV: "production", CSP_MODE: "report-only" });
    expect(Object.keys(h)).toContain("Content-Security-Policy-Report-Only");
    expect(Object.keys(h)).not.toContain("Content-Security-Policy");
  });
});
