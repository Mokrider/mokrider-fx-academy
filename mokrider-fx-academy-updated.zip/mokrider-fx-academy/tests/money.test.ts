import { describe, expect, it } from "vitest";
import { formatMoney, parseMajorToMinor, sumByCurrency } from "@/lib/money";

describe("money", () => {
  it("formats minor units", () => {
    expect(formatMoney(150000, "KES")).toBe("KES 1,500.00");
    expect(formatMoney(5, "USD")).toBe("USD 0.05");
    expect(formatMoney(-2550, "USD")).toBe("-USD 25.50");
  });
  it("parses decimals without float error", () => {
    expect(parseMajorToMinor("1,500.5", "KES")).toBe(150050);
    expect(parseMajorToMinor("0.1", "USD")).toBe(10);
    expect(parseMajorToMinor("19.99", "USD")).toBe(1999);
  });
  it("rejects invalid input", () => {
    expect(parseMajorToMinor("abc", "KES")).toBeNull();
    expect(parseMajorToMinor("1.234", "KES")).toBeNull();
    expect(parseMajorToMinor("-5", "KES")).toBeNull();
    expect(parseMajorToMinor("", "KES")).toBeNull();
  });
  it("never mixes currencies", () => {
    expect(sumByCurrency([
      { currency: "KES", amountMinor: 100 },
      { currency: "USD", amountMinor: 50 },
      { currency: "KES", amountMinor: 25 },
    ])).toEqual({ KES: 125, USD: 50 });
  });
});
