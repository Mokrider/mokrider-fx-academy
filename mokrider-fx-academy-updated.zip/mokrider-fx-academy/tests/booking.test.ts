import { describe, expect, it } from "vitest";
import { canStudentCancel, isBlackout, overlaps, parseBlackoutDates, reminderDue, seatsTaken, slotBookable, weeklySlots } from "@/lib/booking/rules";

const now = new Date("2026-11-10T08:00:00Z");
const mins = (n: number) => new Date(now.getTime() - n * 60 * 1000);

describe("seat counting", () => {
  it("counts confirmed bookings and fresh unpaid holds only", () => {
    const seats = seatsTaken([
      { status: "CONFIRMED", createdAt: mins(500) },
      { status: "AWAITING_PAYMENT", createdAt: mins(10) },  // active hold
      { status: "AWAITING_PAYMENT", createdAt: mins(45) },  // expired hold
      { status: "CANCELLED", createdAt: mins(5) },
      { status: "NO_SHOW", createdAt: mins(900) },
    ], now);
    expect(seats).toBe(3);
  });
  it("is zero for an empty slot", () => expect(seatsTaken([], now)).toBe(0));
});

describe("notice and cancellation windows", () => {
  it("closes bookings 2 hours before the start", () => {
    expect(slotBookable(new Date("2026-11-10T10:30:00Z"), now)).toBe(true);
    expect(slotBookable(new Date("2026-11-10T09:30:00Z"), now)).toBe(false);
  });
  it("allows student cancellation up to 24 hours before", () => {
    expect(canStudentCancel(new Date("2026-11-11T09:00:00Z"), now)).toBe(true);
    expect(canStudentCancel(new Date("2026-11-11T07:00:00Z"), now)).toBe(false);
  });
});

describe("overlaps and blackout dates", () => {
  const t = (h: number) => new Date(Date.UTC(2026, 10, 12, h));
  it("detects overlapping sessions but not back-to-back ones", () => {
    expect(overlaps(t(9), t(10), t(9), t(10))).toBe(true);
    expect(overlaps(t(9), t(11), t(10), t(12))).toBe(true);
    expect(overlaps(t(9), t(10), t(10), t(11))).toBe(false);
  });
  it("matches blackout dates by East Africa date", () => {
    // 22:00 UTC on 24 Dec is 01:00 EAT on 25 Dec
    expect(isBlackout(new Date("2026-12-24T22:00:00Z"), ["2026-12-25"])).toBe(true);
    expect(isBlackout(new Date("2026-12-24T20:00:00Z"), ["2026-12-25"])).toBe(false);
  });
  it("parses blackout date lists", () => {
    expect(parseBlackoutDates("2026-12-25\n2026-01-01, 2026-12-25\nnot a date\n2026-02-30")).toEqual({ dates: ["2026-01-01", "2026-12-25"], invalid: ["not a date", "2026-02-30"] });
  });
});

describe("recurring slots and reminders", () => {
  it("creates weekly slots with the right end time", () => {
    const s = weeklySlots(new Date("2026-11-10T06:00:00Z"), 3, 60);
    expect(s.length).toBe(3);
    expect(s[1].startsAt.toISOString()).toBe("2026-11-17T06:00:00.000Z");
    expect(s[2].endsAt.toISOString()).toBe("2026-11-24T07:00:00.000Z");
  });
  it("sends reminders only inside the window", () => {
    expect(reminderDue(new Date("2026-11-11T06:00:00Z"), now)).toBe(true);
    expect(reminderDue(new Date("2026-11-13T06:00:00Z"), now)).toBe(false);
    expect(reminderDue(new Date("2026-11-10T07:00:00Z"), now)).toBe(false);
  });
});
