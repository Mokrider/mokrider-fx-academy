import { describe, expect, it } from "vitest";
import { QUESTIONS, TOPICS } from "@/content/coach/questions";
import { accuracy, pickNext, shuffleOptions, summarize, topicStats, workingLevel, type Attempt } from "@/lib/coach/engine";

const seeded = (seed: number) => () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);

describe("question bank", () => {
  it("has unique ids, four distinct options and a valid answer index", () => {
    const ids = new Set<string>();
    for (const q of QUESTIONS) {
      expect(ids.has(q.id)).toBe(false);
      ids.add(q.id);
      expect(new Set(q.o).size).toBe(4);
      expect(q.a).toBeGreaterThanOrEqual(0);
      expect(q.a).toBeLessThan(4);
      expect(q.why.length).toBeGreaterThan(10);
    }
  });
  it("covers every topic at beginner level", () => {
    for (const t of TOPICS) expect(QUESTIONS.some((q) => q.t === t.id && q.l === 1)).toBe(true);
  });
});

describe("shuffleOptions", () => {
  it("keeps the correct answer trackable after shuffling", () => {
    for (const q of QUESTIONS) {
      const { options, answerIndex } = shuffleOptions(q, seeded(7));
      expect(options[answerIndex]).toBe(q.o[q.a]);
      expect([...options].sort()).toEqual([...q.o].sort());
    }
  });
});

describe("pickNext", () => {
  it("respects topic and level filters", () => {
    const q = pickNext(QUESTIONS, [], { topic: "risk", level: 2, rng: seeded(1) });
    expect(q?.t).toBe("risk");
    expect(q?.l).toBe(2);
  });
  it("starts adaptive students at beginner level", () => {
    for (let s = 1; s <= 20; s++) expect(pickNext(QUESTIONS, [], { rng: seeded(s) })?.l).toBe(1);
  });
  it("avoids the last 12 questions when other choices exist", () => {
    const hist: Attempt[] = QUESTIONS.filter((q) => q.t === "risk").slice(0, 3).map((q, i) => ({ id: q.id, t: q.t, ok: true, at: i }));
    for (let s = 1; s <= 20; s++) {
      const q = pickNext(QUESTIONS, hist, { topic: "risk", rng: seeded(s) })!;
      expect(hist.some((h) => h.id === q.id)).toBe(false);
    }
  });
  it("returns null when nothing matches", () => {
    expect(pickNext(QUESTIONS, [], { topic: "risk", skipIds: QUESTIONS.filter((q) => q.t === "risk").map((q) => q.id) })).toBeNull();
  });
});

describe("levels and summary", () => {
  it("raises the working level with steady results", () => {
    expect(workingLevel(undefined)).toBe(1);
    expect(workingLevel({ asked: 3, correct: 3 })).toBe(2);
    expect(workingLevel({ asked: 6, correct: 5 })).toBe(3);
    expect(workingLevel({ asked: 6, correct: 2 })).toBe(1);
  });
  it("uses a prior so one answer does not mean 0% or 100%", () => {
    expect(accuracy({ asked: 1, correct: 1 })).toBeCloseTo(2 / 3);
    expect(accuracy({ asked: 1, correct: 0 })).toBeCloseTo(1 / 3);
  });
  it("finds weak and strong topics", () => {
    const h: Attempt[] = [
      { id: "a", t: "risk", ok: false, at: 1 }, { id: "b", t: "risk", ok: false, at: 2 },
      { id: "c", t: "gold", ok: true, at: 3 }, { id: "d", t: "gold", ok: true, at: 4 }, { id: "e", t: "gold", ok: true, at: 5 },
    ];
    const s = summarize(h);
    expect(s.total).toBe(5);
    expect(s.percent).toBe(60);
    expect(s.weakest).toEqual(["risk"]);
    expect(s.strongest).toEqual(["gold"]);
    expect(topicStats(h).risk).toEqual({ asked: 2, correct: 0 });
  });
});
