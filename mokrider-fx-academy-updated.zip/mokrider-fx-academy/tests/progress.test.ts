import { describe, expect, it } from "vitest";
import { computeProgress } from "@/lib/progress";

describe("computeProgress", () => {
  it("reports 0% for an empty course", () => {
    expect(computeProgress([], ["a"])).toEqual({ total: 0, completed: 0, percent: 0 });
  });
  it("counts only lessons that belong to the course", () => {
    expect(computeProgress(["a", "b", "c", "d"], ["a", "b", "x"])).toEqual({ total: 4, completed: 2, percent: 50 });
  });
  it("ignores duplicate completions", () => {
    expect(computeProgress(["a", "b"], ["a", "a", "a"]).percent).toBe(50);
  });
});
