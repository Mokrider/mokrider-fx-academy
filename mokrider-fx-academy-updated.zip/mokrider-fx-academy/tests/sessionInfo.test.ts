import { describe, expect, it } from "vitest";
import { SESSIONS } from "@/lib/trading/sessions";
import { SESSION_TRAITS, activeOverlaps, dayTimeline, formatCountdown, isWeekendClosed, openSessionIds } from "@/lib/trading/sessionInfo";

describe("session traits", () => {
  it("has notes for every session", () => {
    for (const s of SESSIONS) {
      const t = SESSION_TRAITS[s.id];
      expect(t).toBeDefined();
      expect(t.watch.length).toBeGreaterThan(0);
      expect(t.activity).toBeGreaterThanOrEqual(1);
      expect(t.activity).toBeLessThanOrEqual(4);
    }
  });
});

describe("open sessions and overlaps", () => {
  it("London and New York overlap at 14:00 UTC on a winter Wednesday", () => {
    const at = new Date("2026-01-14T14:00:00Z");
    expect(openSessionIds(at)).toEqual(expect.arrayContaining(["london", "newyork"]));
    expect(activeOverlaps(at).map((o) => o.label)).toContain("London + New York");
  });
  it("only Asia is open at 02:00 UTC", () => {
    const ids = openSessionIds(new Date("2026-01-14T02:00:00Z"));
    expect(ids).toContain("tokyo");
    expect(ids).not.toContain("london");
    expect(ids).not.toContain("newyork");
  });
  it("detects the weekend closure", () => {
    expect(isWeekendClosed(new Date("2026-01-17T12:00:00Z"))).toBe(true); // Saturday
    expect(isWeekendClosed(new Date("2026-01-14T12:00:00Z"))).toBe(false); // Wednesday
  });
});

describe("dayTimeline", () => {
  it("puts London at 11:00 to 20:00 Nairobi time in winter (London is UTC+0, Nairobi UTC+3)", () => {
    const { rows } = dayTimeline(new Date("2026-01-14T10:00:00Z"), "Africa/Nairobi");
    const london = rows.find((r) => r.id === "london")!;
    expect(london.segments).toEqual([{ startMin: 11 * 60, endMin: 20 * 60 }]);
  });
  it("shifts London an hour earlier in summer", () => {
    const { rows } = dayTimeline(new Date("2026-07-14T10:00:00Z"), "Africa/Nairobi");
    const london = rows.find((r) => r.id === "london")!;
    expect(london.segments).toEqual([{ startMin: 10 * 60, endMin: 19 * 60 }]);
  });
  it("reports where now sits in the display zone", () => {
    const { nowMin } = dayTimeline(new Date("2026-01-14T10:30:00Z"), "Africa/Nairobi");
    expect(nowMin).toBe(13 * 60 + 30);
  });
});

describe("formatCountdown", () => {
  it("formats hours, minutes and seconds", () => {
    expect(formatCountdown(3725)).toBe("1h 02m 05s");
    expect(formatCountdown(59)).toBe("0m 59s");
    expect(formatCountdown(-5)).toBe("0m 00s");
  });
});
