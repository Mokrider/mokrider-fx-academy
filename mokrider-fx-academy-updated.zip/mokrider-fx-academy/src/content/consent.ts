export const NEWSLETTER_CONSENT_TEXT =
  "I agree to receive educational emails from MOKRIDER FX ACADEMY and understand I can unsubscribe at any time.";
