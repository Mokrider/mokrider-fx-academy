/**
 * Photos from real MOKRIDER FX ACADEMY sessions.
 *
 * How to add one: put the file in /public/gallery/, then add an entry below.
 * Only add photos that (1) you or the academy took, and (2) show people who agreed to appear.
 * Never use pictures taken from other companies, courses or the internet: the page presents these as
 * YOUR sessions. The section is hidden while this list is empty.
 */
export type GalleryPhoto = { src: string; alt: string; caption: string; width: number; height: number };

export const gallery: GalleryPhoto[] = [
  { src: "/gallery/teaching-big-screen.jpg", alt: "A trading mentor points at a candlestick chart on a large wall screen during a lesson", caption: "Walking through market structure on the big screen", width: 735, height: 728 },
  { src: "/gallery/desk-chart-review.jpg", alt: "A student studies a candlestick chart with marked levels and an indicator on a desktop monitor", caption: "Marking levels and reviewing a chart at the desk", width: 735, height: 981 },
  { src: "/gallery/flipchart-walkthrough.jpg", alt: "A mentor explains a hand-drawn price pattern on a flipchart beside a screen showing a chart", caption: "Sketching the idea by hand before looking at the chart", width: 720, height: 720 },
  { src: "/gallery/notes-and-journal.jpg", alt: "A student with a laptop and graph-paper notebooks open, taking notes", caption: "Notes and journal first, trades second", width: 736, height: 981 },
  { src: "/gallery/charts-on-the-go.jpg", alt: "A laptop on a student's lap in a car showing a gold chart with trendlines", caption: "Reviewing a Gold chart between appointments", width: 736, height: 981 },
  { src: "/gallery/eurusd-between-meals.jpg", alt: "A laptop showing a EURUSD daily chart next to a phone on a cafe table", caption: "Checking the EURUSD daily chart over lunch", width: 736, height: 1308 },
];
