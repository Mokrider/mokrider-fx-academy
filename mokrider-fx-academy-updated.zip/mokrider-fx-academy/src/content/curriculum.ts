// Curriculum OUTLINE only. Lesson content is written later through the admin dashboard.
export type CourseOutline = {
  slug: string;
  title: string;
  level: "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
  summary: string;
  topics: string[];
};

export const curriculum: CourseOutline[] = [
  {
    slug: "introduction-to-trading",
    title: "Introduction to Trading",
    level: "BEGINNER",
    summary: "How markets work, how quotes read, and the vocabulary you need before placing any trade.",
    topics: ["How financial markets work", "Forex pairs and quotes", "Understanding Gold (XAUUSD)", "Pips, points, spreads, swaps and commissions", "Candlesticks and chart reading", "Market sessions", "Orders and execution", "Broker and platform terminology"],
  },
  {
    slug: "technical-analysis-foundations",
    title: "Technical Analysis Foundations",
    level: "BEGINNER",
    summary: "Read trend, structure and key levels across timeframes.",
    topics: ["Trends and market structure", "Support and resistance", "Swing highs and lows", "Candlestick behavior", "Breakouts and false breakouts", "Multi-timeframe analysis", "Chart preparation"],
  },
  {
    slug: "liquidity-imbalances-price-action",
    title: "Liquidity, Imbalances and Price Action",
    level: "INTERMEDIATE",
    summary: "Liquidity, fair value gaps and order blocks, with their limits and common misreadings.",
    topics: ["Liquidity concepts", "Fair value gaps", "Imbalances", "Inverse fair value gaps", "Order blocks", "Displacement", "Mitigation and retests", "Confluences and invalidation", "Common interpretation mistakes"],
  },
  {
    slug: "gold-trading",
    title: "Gold Trading",
    level: "INTERMEDIATE",
    summary: "What makes XAUUSD behave differently, and how to plan around it.",
    topics: ["Gold market characteristics", "Relevant economic releases", "Volatility and spread considerations", "Higher-timeframe context", "Lower-timeframe analysis", "Trade planning", "Stop-loss placement", "Position sizing and risk"],
  },
  {
    slug: "eurusd-trading",
    title: "EURUSD Trading",
    level: "INTERMEDIATE",
    summary: "Session-based planning for the world's most traded currency pair.",
    topics: ["Currency-pair fundamentals", "London and New York sessions", "Session highs and lows", "Market structure", "FVG-based educational examples", "Trade planning and invalidation", "Risk and trade management"],
  },
  {
    slug: "risk-management",
    title: "Risk Management",
    level: "BEGINNER",
    summary: "Decide how much you can lose before you decide anything else.",
    topics: ["Risk per trade", "Position sizing", "Stop-loss and take-profit planning", "Risk/reward ratios", "Drawdown", "Losing streaks", "Correlated positions", "News risk", "Trading journals", "When not to trade"],
  },
  {
    slug: "trading-psychology",
    title: "Trading Psychology",
    level: "BEGINNER",
    summary: "Build a routine that holds up when a trade goes against you.",
    topics: ["Emotional discipline", "Fear and greed", "Overtrading", "Revenge trading", "FOMO", "Process-based decision-making", "Handling losses", "Building a repeatable routine"],
  },
];
