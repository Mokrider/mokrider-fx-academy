/**
 * Teaching facts supplied by the academy owner. They describe teaching volume, never trading results.
 * Update the numbers and `asOf` together. A fact with value 0 is hidden automatically.
 */
export type Fact = { id: string; prefix?: string; value: number; suffix?: string; label: string };

export const FACTS_AS_OF = "November 2026";

export const facts: Fact[] = [
  { id: "students", value: 200, suffix: "+", label: "students taught, in person and online" },
  { id: "sessions", prefix: "about ", value: 100, label: "sessions held" },
  { id: "years", value: 5, label: "years teaching forex" },
];
