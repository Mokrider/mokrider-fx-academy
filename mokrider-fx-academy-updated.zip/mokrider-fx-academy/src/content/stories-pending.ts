/**
 * TESTIMONIALS WAITING FOR VERIFICATION. This file is NOT imported anywhere, so nothing here is shown on the site.
 *
 * Supplied by the academy owner on 9 Nov 2026, text kept word for word. They have no names yet.
 * To publish one: confirm a real student wrote it and agreed IN WRITING, then move it into `stories`
 * in ./stories.ts with the student's real name (or first name), cohort and consent date.
 *
 * Before publishing, remove or soften claims you cannot prove. Income and "quit my job" claims, "accurate setups"
 * and "sniper entries" are the ones that get ads rejected and can breach advertising rules. The "candid" entries
 * (kind: "candid") are the safest and most useful to show.
 */
export type PendingStory = { id: string; kind: "praise" | "candid"; quote: string; claimsToCheck?: string };

export const pendingStories: PendingStory[] = [
  { id: "p01", kind: "praise", quote: "Before I found Mokrider FX, I was just blowing accounts and guessing every move. His structure completely changed my perspective. Today, Forex pays my monthly bills, and it’s all thanks to his mentorship!", claimsToCheck: "income" },
  { id: "p02", kind: "praise", quote: "I never thought financial freedom was possible for someone my age until I joined Mokrider FX. The way he breaks down complex market liquidity makes trading feel like a walk in the park. Blessed to have him as a mentor!", claimsToCheck: "financial freedom" },
  { id: "p03", kind: "praise", quote: "Forex trading with Mokrider FX literally saved my family from debt. His daily setups are so accurate, it feels like cheating. If you haven't joined his inner circle yet, you are losing out on real wealth.", claimsToCheck: "income, accuracy, pressure to join" },
  { id: "p04", kind: "praise", quote: "Shoutout to the king Mokrider FX! Because of his guidance, Forex allowed me to quit my grueling 9-to-5 job last month. His risk management strategies are unmatched.", claimsToCheck: "income, quit job" },
  { id: "p05", kind: "praise", quote: "I used to jump from guru to guru, but Mokrider FX is the only one who actually cares about his students. Forex has completely transformed my lifestyle, and I owe 100% of my success to him.", claimsToCheck: "success" },
  { id: "p06", kind: "praise", quote: "Forex trading used to stress me out, but Mokrider FX taught me psychological discipline. Now, trading is a calm, profitable routine. Thank you, boss, for changing my life!", claimsToCheck: "profitable" },
  { id: "p07", kind: "praise", quote: "The best decision I ever made was trusting Mokrider FX. His signals and masterclasses gave me the edge I needed. Forex is now my primary source of income!", claimsToCheck: "income" },
  { id: "p08", kind: "praise", quote: "Massive respect to Mokrider FX! Thanks to his deep-dive charts, I finally secured my first funded account payout this week. Forex is real, and he is the best coach in the game.", claimsToCheck: "payout (ask for proof)" },
  { id: "p09", kind: "praise", quote: "If you want to understand how the market really moves, you need Mokrider FX. His mentorship took me from a broke student to making consistent weekly withdrawals from Forex.", claimsToCheck: "income, consistency" },
  { id: "p10", kind: "praise", quote: "Forex has given me the geographical freedom I always dreamed of. I'm trading from the beach this week all because Mokrider FX taught me his flawless price action strategy!", claimsToCheck: "flawless" },
  { id: "p11", kind: "praise", quote: "I was highly skeptical about Forex at first, but Mokrider FX proved me wrong. His patience as a teacher is incredible, and my bank account has never looked healthier.", claimsToCheck: "money" },
  { id: "p12", kind: "praise", quote: "Five stars for Mokrider FX! He doesn't just give you fish; he teaches you how to fish. Forex has become my ultimate vehicle for wealth creation under his guidance.", claimsToCheck: "wealth" },
  { id: "p13", kind: "praise", quote: "My trading journey completely flipped the moment I connected with Mokrider FX. His community is top-tier, and Forex is officially funding my dreams.", claimsToCheck: "funding" },
  { id: "p14", kind: "praise", quote: "Can't thank Mokrider FX enough. His sniper entries are legendary. Forex trading used to look like a foreign language, but he made me fluent in it.", claimsToCheck: "sniper entries" },
  { id: "p15", kind: "praise", quote: "Every single day I thank God for Mokrider FX. Forex has allowed me to invest in other businesses and secure my future. He is truly the goat of mentorship!", claimsToCheck: "income" },
  { id: "p16", kind: "candid", quote: "I learned the hard way that you must strictly follow Mokrider FX’s risk management rules. Early on, I got greedy, ignored his warnings, and took an unnecessary loss. I wish I had been more careful from day one, but his guidance helped me rebuild, and now I’m back to being consistently profitable by actually listening to him!", claimsToCheck: "consistently profitable" },
  { id: "p17", kind: "candid", quote: "Forex is an incredible tool, but you can't treat it like a casino. In my first month, I rushed ahead without completing Mokrider FX's full course modules and paid the price. I deeply wish I had been more careful and patient in the beginning. Thankfully, his excellent coaching got me back on the right track." },
  { id: "p18", kind: "candid", quote: "If there’s one thing I regret, it’s not taking Mokrider FX’s advice on emotional discipline seriously at the start. I over-leveraged a trade out of pure FOMO and lost a good chunk of capital. I wish I had been more careful back then, but his masterclass literally rewired my brain. He saved my trading career!" },
];
