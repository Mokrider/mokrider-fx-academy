/**
 * "Sponsor a student" programme. Edit the text here; the page at /sponsor reads it.
 * Only the USD 100 figure was supplied by the owner. Other amounts are deliberately "ask us".
 */
export const FULL_SPONSORSHIP_USD = 100;

export const whatFullSponsorshipCovers = [
  "Every course in the academy, for as long as the student keeps learning",
  "Mentorship sessions with the mentor",
  "Lifetime access to the academy's signals channel (educational trade ideas, not advice)",
  "The trading journal and all calculators",
];

/** Ways to give. "Amount" is left as text so you can change it without touching code. */
export const waysToGive: { title: string; text: string; amount: string }[] = [
  { title: "Sponsor a whole student", text: "Pay for one student to learn everything, from first chart to mentorship.", amount: `USD ${FULL_SPONSORSHIP_USD}` },
  { title: "Fund a course seat", text: "Cover one student's place in a single course.", amount: "Ask us for the current price" },
  { title: "Fund a mentorship session", text: "Pay for a one-to-one session for a student who has earned it.", amount: "Ask us for the current price" },
  { title: "A thank-you from a graduate", text: "If the academy helped you, give back whatever feels right as a token of appreciation. Nothing is expected, and nobody is asked to share their results.", amount: "Any amount" },
  { title: "Gift a seat to a friend", text: "Pay for someone you know who is serious about learning but cannot afford it right now.", amount: "Ask us" },
  { title: "Sponsor the next cohort", text: "Pool with others to fund several seats at once, in your name or anonymously.", amount: "Any amount" },
  { title: "Back a live class or workshop", text: "Help pay for a free community class or a workshop outside Nairobi.", amount: "Any amount" },
  { title: "Community or company sponsor", text: "A group, church, school or business sponsoring students together.", amount: "Talk to us" },
];

/** How sponsored students are chosen. Published in full so nobody has to guess. */
export const selectionCriteria: { title: string; text: string }[] = [
  { title: "Commitment", text: "Attends sessions, finishes lessons and does the exercises. Showing up counts for more than talent." },
  { title: "Process, not profit", text: "A journal kept honestly, risk rules followed, losses reviewed. We do not choose students by how much they made." },
  { title: "Real need", text: "The student cannot reasonably pay the full price right now." },
  { title: "Discipline and attitude", text: "Takes feedback well, asks good questions and helps other students." },
  { title: "A short application", text: "Why you want to learn, what you have done so far, and what you will do with it." },
  { title: "A chance for everyone", text: "Sponsors may pick a category (for example a woman, a student under 25, or someone outside Nairobi) but never an individual they know." },
];

export const sponsorshipSteps: [string, string][] = [
  ["Reach out first", "Email or WhatsApp us. No payment is taken on this website."],
  ["We talk", "We explain what is covered, answer your questions and agree what you want to fund."],
  ["You pay directly", "We give you the payment details in that conversation. You get a receipt."],
  ["A student is chosen", "We pick from the students who meet the criteria below and tell you who and when."],
  ["You see the outcome", "We tell you how the student is getting on, without sharing anything private, and only with their consent."],
];
