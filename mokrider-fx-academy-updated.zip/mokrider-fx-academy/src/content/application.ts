// Options for the private mentorship application form. Edit the wording here.
export type Option = readonly [value: string, label: string];

export const EXPERIENCE: readonly Option[] = [
  ["under_6_months", "Under 6 months"],
  ["6_12_months", "6 to 12 months"],
  ["1_2_years", "1 to 2 years"],
  ["2_plus_years", "2 years or more"],
];

export const BOTTLENECKS: readonly Option[] = [
  ["overtrading", "Overtrading or forcing setups out of boredom"],
  ["exits", "Cutting winners early or letting losses run"],
  ["prop_rules", "Struggling with prop firm drawdown rules"],
  ["analysis", "Reading structure and choosing entries"],
  ["other", "Something else"],
];

export const FOCUS: readonly Option[] = [
  ["learn", "Learning the process before trading real money"],
  ["personal", "Growing a personal account responsibly"],
  ["prop", "Preparing for a prop firm challenge"],
  ["existing", "Improving results on an account I already trade"],
];

export const APPLICATION_CONSENT =
  "I agree that MOKRIDER FX ACADEMY may contact me about my application using the details I have given, and I understand my answers will be stored for that purpose.";

export function values(options: readonly Option[]): [string, ...string[]] {
  return options.map((o) => o[0]) as [string, ...string[]];
}

export function labelFor(options: readonly Option[], value: string): string {
  return options.find((o) => o[0] === value)?.[1] ?? value;
}
