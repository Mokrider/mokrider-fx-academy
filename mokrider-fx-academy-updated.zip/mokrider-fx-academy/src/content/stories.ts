/**
 * Student and mentee stories, in their own words.
 *
 * RULES (these protect you legally and keep the page believable):
 *  - Add a story only after the person has agreed IN WRITING to this exact text being published.
 *  - Never invent, merge, paraphrase or "improve" a story. Never add results or income figures you cannot document.
 *  - Keep what "could have been better": critical feedback is what makes the page credible.
 *  - Do not show a trade profit as typical. Trading results vary and most people lose money.
 *  - If someone withdraws permission, delete the entry from this file and redeploy.
 *
 * The page shows an honest empty state while this array is empty.
 */
export type StoryVoice = "Student" | "Mentee" | "Graduate";

export type Story = {
  id: string;
  voice: StoryVoice;
  name: string;
  /** e.g. "Introduction to Trading, 2026 cohort" */
  cohort: string;
  /** One or two sentences, in the person's own words. */
  quote: string;
  background: string;
  /** What changed for them. Skills and habits, not profit claims. */
  whatChanged: string;
  /** What they would like improved. Required: candour is the point. */
  wouldImprove: string;
  recommends: boolean;
  /** ISO date the person gave written permission. */
  consentGivenOn: string;
};

export const stories: Story[] = [];

export const storyVoices: StoryVoice[] = ["Student", "Mentee", "Graduate"];
