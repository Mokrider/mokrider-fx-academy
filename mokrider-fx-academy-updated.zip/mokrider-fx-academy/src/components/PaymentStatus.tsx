"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export function PaymentStatus({ reference, status, checkAction }: { reference: string; status: string; checkAction: () => Promise<void> }) {
  const router = useRouter();
  const [slow, setSlow] = useState(false);
  const waiting = status === "AWAITING_PAYMENT" || status === "PENDING";

  useEffect(() => {
    if (!waiting) return;
    const started = Date.now();
    const id = setInterval(async () => {
      if (Date.now() - started > 150_000) { setSlow(true); clearInterval(id); return; }
      try {
        const res = await fetch(`/api/orders/${reference}/status`, { cache: "no-store" });
        if (res.ok) {
          const data = (await res.json()) as { status: string };
          if (data.status !== status) router.refresh();
        }
      } catch { /* try again on the next tick */ }
    }, 4000);
    return () => clearInterval(id);
  }, [waiting, reference, status, router]);

  if (!waiting) return null;
  return (
    <div role="status" aria-live="polite" className="rounded-md border border-accent p-5">
      <p className="font-medium">Waiting for your M-Pesa payment</p>
      <p className="mt-1 text-sm text-muted">Check your phone and enter your M-Pesa PIN when prompted. This page updates by itself. We never see your PIN.</p>
      {slow && <p className="mt-2 text-sm">This is taking longer than usual. If you already paid, press the button below to check again.</p>}
      <form action={checkAction} className="mt-3"><button type="submit" className="btn btn-ghost">Check payment now</button></form>
    </div>
  );
}
