"use client";
import { useActionState } from "react";
import { subscribeNewsletter, type NewsletterState } from "@/app/actions/newsletter";

export function NewsletterForm({ consentText }: { consentText: string }) {
  const [state, action, pending] = useActionState<NewsletterState, FormData>(subscribeNewsletter, null);
  return (
    <form action={action} className="space-y-3" noValidate>
      <div className="flex flex-col gap-3 sm:flex-row">
        <label htmlFor="nl-email" className="sr-only">Email address</label>
        <input id="nl-email" name="email" type="email" autoComplete="email" required placeholder="you@example.com" className="field sm:max-w-sm" />
        <button type="submit" className="btn btn-primary" disabled={pending}>{pending ? "Subscribing..." : "Subscribe"}</button>
      </div>
      <label className="flex items-start gap-2 text-sm text-muted">
        <input type="checkbox" name="consent" required className="mt-1" />
        <span>{consentText}</span>
      </label>
      <p role="status" aria-live="polite" className={`text-sm ${state?.ok ? "text-up" : "text-down"}`}>{state?.message}</p>
    </form>
  );
}
