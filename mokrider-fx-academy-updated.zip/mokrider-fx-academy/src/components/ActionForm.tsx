"use client";
import { useActionState } from "react";

export type FormState = { error?: string; ok?: string } | null;

export function ActionForm({
  action,
  children,
  submitLabel = "Save",
}: {
  action: (prev: FormState, formData: FormData) => Promise<FormState>;
  children: React.ReactNode;
  submitLabel?: string;
}) {
  const [state, formAction, pending] = useActionState(action, null);
  return (
    <form action={formAction} className="space-y-5">
      {children}
      <p role="alert" aria-live="assertive" className="min-h-5 text-sm text-down">{state?.error}</p>
      {state?.ok && <p role="status" className="text-sm text-up">{state.ok}</p>}
      <button type="submit" className="btn btn-primary" disabled={pending}>{pending ? "Saving..." : submitLabel}</button>
    </form>
  );
}
