import { formatMoney } from "@/lib/money";
import type { JournalStats } from "@/lib/trading/journalStats";

const pct = (n: number | null) => (n === null ? "n/a" : `${(n * 100).toFixed(1)}%`);
const num = (n: number | null) => (n === null ? "n/a" : n.toFixed(2));

export function JournalStatsView({ stats }: { stats: JournalStats }) {
  if (stats.byCurrency.length === 0) {
    return <p className="text-muted">No closed trades yet. Statistics appear once you record a net result.</p>;
  }
  return (
    <div className="space-y-10">
      {stats.byCurrency.map((c) => {
        const m = (v: number) => formatMoney(v, c.currency);
        const rows: [string, string][] = [
          ["Closed trades", String(c.closed)],
          ["Win rate", `${pct(c.winRate)} (${c.wins} wins, ${c.losses} losses, ${c.breakeven} break-even)`],
          ["Net result", m(c.netMinor)],
          ["Profit factor", c.profitFactor === null ? "n/a (no losing trades)" : num(c.profitFactor)],
          ["Average win / average loss", c.payoffRatio === null ? "n/a" : `${num(c.payoffRatio)}  (${c.avgWinMinor !== null ? m(c.avgWinMinor) : "n/a"} / ${c.avgLossMinor !== null ? m(c.avgLossMinor) : "n/a"})`],
          ["Average result in R", c.avgR === null ? "n/a (no planned risk recorded)" : `${num(c.avgR)} R across ${c.rCount} trade${c.rCount === 1 ? "" : "s"}`],
          ["Maximum drawdown (recorded results)", m(c.maxDrawdownMinor)],
        ];
        return (
          <section key={c.currency} aria-label={`${c.currency} statistics`}>
            <h3 className="text-2xl">{c.currency} results</h3>
            {c.smallSample && (
              <p className="mt-3 rounded-md border border-line bg-surface p-3 text-sm text-muted">
                Based on only {c.closed} closed trade{c.closed === 1 ? "" : "s"}. Fewer than 30 trades is too few to say anything reliable about a strategy, and this is not proof of profitability.
              </p>
            )}
            <dl className="mt-4">
              {rows.map(([k, v]) => (
                <div key={k} className="flex flex-wrap justify-between gap-4 border-b border-line py-2"><dt className="text-sm text-muted">{k}</dt><dd className="font-medium">{v}</dd></div>
              ))}
            </dl>
            <div className="mt-6 grid gap-8 sm:grid-cols-2">
              {([["By instrument", c.byInstrument], ["By setup", c.bySetup]] as const).map(([title, group]) => (
                <div key={title}>
                  <h4 className="text-lg">{title}</h4>
                  <ul className="mt-2 divide-y divide-line border-y border-line text-sm">
                    {Object.entries(group).map(([name, g]) => <li key={name} className="flex justify-between gap-4 py-2"><span>{name} ({g.count})</span><span>{m(g.netMinor)}</span></li>)}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        );
      })}
      <p className="text-xs text-muted">Statistics use only the results you enter, per currency. Win rate and profit factor mean little without enough trades and consistent record-keeping.</p>
    </div>
  );
}
