"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Pause, Play } from "lucide-react";

export type CarouselItem = { id: string; href: string; kind: string; title: string; blurb: string; meta: string };

const INTERVAL_MS = 5000;

/**
 * Auto-advancing panel: moves every 5 seconds, pauses on hover or keyboard focus, has jump bars and an
 * explicit pause button, and never auto-advances for people who prefer reduced motion.
 */
export function LatestCarousel({ items }: { items: CarouselItem[] }) {
  const [index, setIndex] = useState(0);
  const [hovering, setHovering] = useState(false);
  const [userPaused, setUserPaused] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduceMotion(mq.matches);
    const onChange = () => setReduceMotion(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  const running = items.length > 1 && !hovering && !userPaused && !reduceMotion;

  useEffect(() => {
    if (!running) return;
    const t = window.setInterval(() => setIndex((i) => (i + 1) % items.length), INTERVAL_MS);
    return () => window.clearInterval(t);
  }, [running, items.length]);

  if (items.length === 0) return null;
  const current = items[Math.min(index, items.length - 1)];

  return (
    <div
      className="bg-card border border-line p-6 md:p-8"
      role="group"
      aria-roledescription="carousel"
      aria-label="Latest analysis and articles"
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => setHovering(false)}
      onFocus={() => setHovering(true)}
      onBlur={() => setHovering(false)}
    >
      <div aria-live={running ? "off" : "polite"} className="min-h-40">
        <p className="text-sm font-semibold uppercase tracking-widest text-accent-text">{current.kind}</p>
        <h3 className="mt-2 text-2xl md:text-3xl">
          <Link href={current.href} className="hover:text-accent-text">{current.title}</Link>
        </h3>
        {current.blurb && <p className="mt-3 max-w-2xl text-muted">{current.blurb}</p>}
        <p className="mt-3 text-xs text-muted">{current.meta}</p>
      </div>
      {items.length > 1 && (
        <div className="mt-6 flex items-center gap-4">
          <div className="flex flex-1 gap-2" role="tablist" aria-label="Choose a slide">
            {items.map((it, i) => (
              <button
                key={it.id}
                type="button"
                role="tab"
                aria-selected={i === index}
                aria-label={`Slide ${i + 1} of ${items.length}: ${it.title}`}
                className="jump-bar"
                data-active={i === index}
                onClick={() => setIndex(i)}
              />
            ))}
          </div>
          <button
            type="button"
            className="btn btn-ghost !px-3"
            aria-label={userPaused ? "Resume automatic rotation" : "Pause automatic rotation"}
            onClick={() => setUserPaused((p) => !p)}
          >
            {userPaused ? <Play size={16} aria-hidden /> : <Pause size={16} aria-hidden />}
          </button>
        </div>
      )}
    </div>
  );
}
