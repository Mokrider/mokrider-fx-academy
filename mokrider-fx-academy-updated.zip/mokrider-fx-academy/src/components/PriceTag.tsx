import { formatMoney } from "@/lib/money";

export function PriceTag({ listMinor, unitMinor, currency, className = "" }: { listMinor: number; unitMinor: number; currency: string; className?: string }) {
  if (unitMinor === 0) return <span className={className}>Free</span>;
  return (
    <span className={className}>
      {formatMoney(unitMinor, currency)}
      {unitMinor < listMinor && <s className="ml-2 text-sm text-muted"><span className="sr-only">Was </span>{formatMoney(listMinor, currency)}</s>}
    </span>
  );
}
