import Image from "next/image";
import Link from "next/link";
import { gallery } from "@/content/gallery";

/** Captioned photos from real sessions. Renders nothing until photos are added in src/content/gallery.ts. */
export function SessionGallery() {
  if (gallery.length === 0) return null;
  return (
    <section className="container-page py-20" aria-labelledby="gallery-heading">
      <h2 id="gallery-heading" className="text-3xl md:text-4xl">Learning in practice</h2>
      <p className="mt-3 max-w-2xl text-muted">Teaching, studying and chart work from around the academy.</p>
      <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {gallery.map((p) => (
          <li key={p.src} className="bg-card overflow-hidden border border-line">
            <Image src={p.src} alt={p.alt} width={p.width} height={p.height} className="aspect-[4/5] w-full object-cover object-top" sizes="(min-width: 1024px) 22rem, (min-width: 640px) 50vw, 100vw" />
            <p className="p-4 text-sm text-muted">{p.caption}</p>
          </li>
        ))}
      </ul>
      <Link href="/mentorship" className="btn btn-ghost mt-8">Join a session</Link>
    </section>
  );
}
