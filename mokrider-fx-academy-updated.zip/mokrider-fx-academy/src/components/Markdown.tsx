import type { ReactNode } from "react";

// Small, safe Markdown subset: #/##/### headings, - lists, 1. lists, **bold**, *italic*, [links](https://...).
// React escapes all text, and links are limited to http(s) and site-relative URLs.
function inline(text: string): ReactNode[] {
  const parts = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*|\[[^\]]+\]\([^)\s]+\))/g);
  return parts.map((p, i) => {
    if (p.length > 4 && p.startsWith("**") && p.endsWith("**")) return <strong key={i} className="text-fg">{p.slice(2, -2)}</strong>;
    if (p.length > 2 && p.startsWith("*") && p.endsWith("*")) return <em key={i}>{p.slice(1, -1)}</em>;
    const m = /^\[([^\]]+)\]\(([^)\s]+)\)$/.exec(p);
    if (m) {
      const href = m[2];
      const safe = /^https?:\/\//.test(href) || (href.startsWith("/") && !href.startsWith("//"));
      return safe ? <a key={i} href={href} rel="noopener noreferrer" className="link-accent">{m[1]}</a> : m[1];
    }
    return p;
  });
}

export function Markdown({ source }: { source: string }) {
  const blocks = source.replace(/\r\n/g, "\n").trim().split(/\n{2,}/);
  return (
    <div className="space-y-4 leading-relaxed text-muted">
      {blocks.map((block, i) => {
        const lines = block.split("\n");
        const first = lines[0];
        if (lines.length === 1 && first.startsWith("### ")) return <h3 key={i} className="pt-2 text-xl text-fg">{inline(first.slice(4))}</h3>;
        if (lines.length === 1 && first.startsWith("## ")) return <h2 key={i} className="pt-4 text-2xl text-fg">{inline(first.slice(3))}</h2>;
        if (lines.length === 1 && first.startsWith("# ")) return <h2 key={i} className="pt-4 text-2xl text-fg">{inline(first.slice(2))}</h2>;
        if (lines.every((l) => l.startsWith("- "))) return <ul key={i} className="list-disc space-y-1 pl-6">{lines.map((l, j) => <li key={j}>{inline(l.slice(2))}</li>)}</ul>;
        if (lines.every((l) => /^\d+\. /.test(l))) return <ol key={i} className="list-decimal space-y-1 pl-6">{lines.map((l, j) => <li key={j}>{inline(l.replace(/^\d+\. /, ""))}</li>)}</ol>;
        return <p key={i}>{inline(lines.join(" "))}</p>;
      })}
    </div>
  );
}
