"use client";
import { ActionForm, type FormState } from "@/components/ActionForm";
import { APPLICATION_CONSENT, BOTTLENECKS, EXPERIENCE, FOCUS, type Option } from "@/content/application";

function Pick({ id, label, options }: { id: string; label: string; options: readonly Option[] }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-semibold">{label}</label>
      <select id={id} name={id} required defaultValue="" className="field">
        <option value="" disabled>Choose one</option>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </div>
  );
}

export function ApplicationForm({ action }: { action: (prev: FormState, fd: FormData) => Promise<FormState> }) {
  return (
    <ActionForm action={action} submitLabel="Send application">
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label htmlFor="name" className="mb-1 block text-sm font-semibold">Your name</label><input id="name" name="name" required autoComplete="name" className="field" /></div>
        <div><label htmlFor="email" className="mb-1 block text-sm font-semibold">Email</label><input id="email" name="email" type="email" required autoComplete="email" className="field" /></div>
      </div>
      <div>
        <label htmlFor="phone" className="mb-1 block text-sm font-semibold">Phone or WhatsApp (optional)</label>
        <input id="phone" name="phone" type="tel" autoComplete="tel" placeholder="+254 712 345 678" className="field" />
      </div>
      <Pick id="experience" label="1. How long have you been trading?" options={EXPERIENCE} />
      <Pick id="bottleneck" label="2. What is your biggest challenge right now?" options={BOTTLENECKS} />
      <Pick id="focus" label="3. What are you mainly working towards?" options={FOCUS} />
      <div>
        <label htmlFor="goals" className="mb-1 block text-sm font-semibold">Anything else we should know? (optional)</label>
        <textarea id="goals" name="goals" rows={4} maxLength={1500} className="field" />
      </div>
      {/* Honeypot for bots. Hidden from people and screen readers. */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label>Website<input name="website" tabIndex={-1} autoComplete="off" /></label>
      </div>
      <label className="flex items-start gap-2 text-sm text-muted">
        <input type="checkbox" name="consent" required className="mt-1" />
        <span>{APPLICATION_CONSENT}</span>
      </label>
    </ActionForm>
  );
}
