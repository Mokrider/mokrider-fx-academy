import type { JournalEntry } from "@prisma/client";
import { ActionForm } from "@/components/ActionForm";
import { Field, SelectField, TextArea } from "@/components/formFields";
import { toEatInput } from "@/lib/time";
import { saveJournalEntry } from "@/app/tools/journal/actions";

export function JournalForm({ entry }: { entry: JournalEntry | null }) {
  const d = (v: { toString(): string } | null | undefined) => (v == null ? "" : v.toString());
  const money = (m: number | null | undefined) => (m == null ? "" : (m / 100).toFixed(2));
  return (
    <ActionForm action={saveJournalEntry} submitLabel={entry ? "Save changes" : "Add entry"}>
      <input type="hidden" name="id" value={entry?.id ?? ""} />
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label="Instrument" name="instrument" required defaultValue={entry?.instrument ?? "XAUUSD"} />
        <SelectField label="Direction" name="direction" defaultValue={entry?.direction ?? "LONG"} options={[["LONG", "Long (buy)"], ["SHORT", "Short (sell)"]]} />
        <Field label="Trade time (East Africa Time)" name="tradedAt" type="datetime-local" required defaultValue={toEatInput(entry?.tradedAt)} />
      </div>
      <div className="grid gap-4 sm:grid-cols-4">
        <Field label="Entry" name="entryPrice" required defaultValue={d(entry?.entryPrice)} />
        <Field label="Stop-loss" name="stopLoss" defaultValue={d(entry?.stopLoss)} />
        <Field label="Take-profit" name="takeProfit" defaultValue={d(entry?.takeProfit)} />
        <Field label="Exit price" name="exitPrice" defaultValue={d(entry?.exitPrice)} />
      </div>
      <div className="grid gap-4 sm:grid-cols-4">
        <Field label="Position size (lots)" name="positionSize" defaultValue={d(entry?.positionSize)} />
        <SelectField label="Currency" name="currency" defaultValue={entry?.currency ?? "USD"} options={[["USD", "USD"], ["EUR", "EUR"], ["GBP", "GBP"], ["KES", "KES"]]} />
        <Field label="Planned risk" name="plannedRisk" defaultValue={money(entry?.plannedRiskMinor)} hint="Amount, for example 10." />
        <Field label="Net result" name="result" defaultValue={money(entry?.resultMinor)} hint="After costs. Negative for a loss. Leave blank while open." />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Setup" name="setup" defaultValue={entry?.setup} hint="For example FVG retest or London sweep." />
        <Field label="Emotional state" name="emotionalState" defaultValue={entry?.emotionalState} hint="For example calm, rushed, fearful." />
      </div>
      <TextArea label="Reason for entry" name="reasonEntry" rows={3} defaultValue={entry?.reasonEntry} />
      <TextArea label="Reason for exit" name="reasonExit" rows={3} defaultValue={entry?.reasonExit} />
      <TextArea label="Lessons learned" name="lessons" rows={3} defaultValue={entry?.lessons} />
    </ActionForm>
  );
}
