import Link from "next/link";
import { prisma } from "@/lib/db";
import { visibleWhere } from "@/lib/publishing";
import { formatEat } from "@/lib/time";
import { LatestCarousel, type CarouselItem } from "@/components/LatestCarousel";

/** Home-page rotating panel of the newest published analysis and articles. Renders nothing when there is none. */
export async function LatestContent() {
  let analyses: { id: string; slug: string; title: string; instrument: string; timeframe: string; publishedAt: Date | null }[] = [];
  let articles: { id: string; slug: string; title: string; excerpt: string; publishedAt: Date | null }[] = [];
  try {
    [analyses, articles] = await Promise.all([
      prisma.marketAnalysis.findMany({ where: visibleWhere(), orderBy: { publishedAt: "desc" }, take: 3, select: { id: true, slug: true, title: true, instrument: true, timeframe: true, publishedAt: true } }),
      prisma.article.findMany({ where: visibleWhere(), orderBy: { publishedAt: "desc" }, take: 3, select: { id: true, slug: true, title: true, excerpt: true, publishedAt: true } }),
    ]);
  } catch {
    return null;
  }

  const items: (CarouselItem & { at: number })[] = [
    ...analyses.map((a) => ({
      id: `analysis-${a.id}`,
      href: `/market-analysis/${a.slug}`,
      kind: `Analysis · ${a.instrument} · ${a.timeframe}`,
      title: a.title,
      blurb: "Educational analysis. Not a signal and not live.",
      meta: a.publishedAt ? `Published ${formatEat(a.publishedAt)}` : "",
      at: a.publishedAt?.getTime() ?? 0,
    })),
    ...articles.map((a) => ({
      id: `article-${a.id}`,
      href: `/blog/${a.slug}`,
      kind: "From the blog",
      title: a.title,
      blurb: a.excerpt,
      meta: a.publishedAt ? `Published ${formatEat(a.publishedAt)}` : "",
      at: a.publishedAt?.getTime() ?? 0,
    })),
  ]
    .sort((x, y) => y.at - x.at)
    .slice(0, 5);

  if (items.length === 0) return null;
  return (
    <section className="container-page py-20" aria-labelledby="latest-heading">
      <h2 id="latest-heading" className="text-3xl md:text-4xl">Latest from the desk</h2>
      <p className="mb-8 mt-3 max-w-2xl text-muted">New analysis and lessons, newest first. The panel moves on its own every five seconds and stops when you hover over it.</p>
      <LatestCarousel items={items.map((i) => ({ id: i.id, href: i.href, kind: i.kind, title: i.title, blurb: i.blurb, meta: i.meta }))} />
      <div className="mt-5 flex flex-wrap gap-6 text-sm">
        {analyses.length > 0 && <Link href="/market-analysis" className="link-accent">All analysis</Link>}
        {articles.length > 0 && <Link href="/blog" className="link-accent">All articles</Link>}
      </div>
    </section>
  );
}
