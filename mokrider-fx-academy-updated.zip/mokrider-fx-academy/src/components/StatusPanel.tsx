import Link from "next/link";
import { prisma } from "@/lib/db";
import { visibleWhere } from "@/lib/publishing";
import { curriculum } from "@/content/curriculum";

type Counts = { courses: number; analyses: number; articles: number; packages: number };

async function loadCounts(): Promise<Counts | null> {
  try {
    const [courses, analyses, articles, packages] = await Promise.all([
      prisma.course.count({ where: { status: "PUBLISHED" } }),
      prisma.marketAnalysis.count({ where: visibleWhere() }),
      prisma.article.count({ where: visibleWhere() }),
      prisma.mentorshipPackage.count({ where: { status: "PUBLISHED" } }),
    ]);
    return { courses, analyses, articles, packages };
  } catch {
    return null;
  }
}

/**
 * "What is open right now" panel. The numbers are read from the database, never typed in by hand,
 * so the panel can only ever say what is true. When the database is unreachable it says so plainly.
 */
export async function StatusPanel() {
  const c = await loadCounts();
  const cards: { label: string; value: string; note: string; href: string; cta: string }[] = [
    {
      label: "Courses",
      value: c ? String(c.courses) : "-",
      note: c ? (c.courses === 0 ? `${curriculum.length} courses outlined, lessons being written` : "published and open to enrol") : "Live count unavailable",
      href: "/learn",
      cta: "Browse courses",
    },
    {
      label: "Market analysis",
      value: c ? String(c.analyses) : "-",
      note: c ? (c.analyses === 0 ? "None published yet" : "educational write-ups, time-stamped") : "Live count unavailable",
      href: "/market-analysis",
      cta: "Read analysis",
    },
    {
      label: "Mentorship plans",
      value: c ? String(c.packages) : "-",
      note: c ? (c.packages === 0 ? "Apply for 1-on-1 while plans are set up" : "bookable, times in East Africa Time") : "Live count unavailable",
      href: "/mentorship",
      cta: "See mentorship",
    },
    {
      label: "Articles",
      value: c ? String(c.articles) : "-",
      note: c ? (c.articles === 0 ? "None published yet" : "on risk, structure and process") : "Live count unavailable",
      href: "/blog",
      cta: "Read the blog",
    },
  ];

  return (
    <section className="container-page py-20" aria-labelledby="status-heading">
      <h2 id="status-heading" className="text-3xl md:text-4xl">What is open right now</h2>
      <p className="mt-3 max-w-2xl text-muted">A live count of what is published on this site today. If a number is zero, that part is still being built, and we say so.</p>
      <ul className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((card) => (
          <li key={card.label} className="bg-card flex flex-col border border-line p-5">
            <p className="text-xs font-semibold uppercase tracking-widest text-muted">{card.label}</p>
            <p className="font-display mt-2 text-4xl text-accent-text">{card.value}</p>
            <p className="mt-1 flex-1 text-sm text-muted">{card.note}</p>
            <Link href={card.href} className="link-accent mt-4 text-sm font-semibold">{card.cta} &rarr;</Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
