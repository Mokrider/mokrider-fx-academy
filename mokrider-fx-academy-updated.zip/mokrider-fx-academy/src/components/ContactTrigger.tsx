"use client";

import { OPEN_CONTACT_EVENT, type ContactMessage } from "@/lib/contact";

/** A button that opens the contact dialog with a pre-filled subject and body. */
export function ContactTrigger({ message, className = "btn btn-ghost", children }: { message?: ContactMessage; className?: string; children: React.ReactNode }) {
  return (
    <button type="button" className={className} onClick={() => window.dispatchEvent(new CustomEvent(OPEN_CONTACT_EVENT, { detail: message }))}>
      {children}
    </button>
  );
}
