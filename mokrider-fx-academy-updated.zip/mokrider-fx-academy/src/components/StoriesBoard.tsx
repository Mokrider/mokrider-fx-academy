"use client";

import { useState } from "react";
import type { Story, StoryVoice } from "@/content/stories";

/** Filter bar with counts (All / Student / Mentee / Graduate) above a list of consented stories. */
export function StoriesBoard({ stories, voices }: { stories: Story[]; voices: StoryVoice[] }) {
  const [filter, setFilter] = useState<StoryVoice | "All">("All");
  const shown = filter === "All" ? stories : stories.filter((s) => s.voice === filter);
  const tabs: (StoryVoice | "All")[] = ["All", ...voices];

  return (
    <div>
      <div role="group" aria-label="Filter stories by voice" className="flex flex-wrap gap-2">
        {tabs.map((t) => {
          const n = t === "All" ? stories.length : stories.filter((s) => s.voice === t).length;
          return (
            <button key={t} type="button" className="chip" aria-pressed={filter === t} onClick={() => setFilter(t)}>
              {t} ({n})
            </button>
          );
        })}
      </div>
      <ul className="mt-8 grid gap-6 md:grid-cols-2">
        {shown.map((s) => (
          <li key={s.id} className="bg-card border border-line p-6">
            <p className="text-xs font-semibold uppercase tracking-widest text-accent-text">{s.voice} &middot; {s.cohort}</p>
            <blockquote className="mt-3 text-lg">&ldquo;{s.quote}&rdquo;</blockquote>
            <p className="mt-1 text-sm font-semibold">{s.name}</p>
            <details className="mt-4">
              <summary className="cursor-pointer text-sm font-semibold text-accent-text">Read the full story</summary>
              <dl className="mt-3 space-y-3 text-sm text-muted">
                <div><dt className="font-semibold text-fg">Where they started</dt><dd>{s.background}</dd></div>
                <div><dt className="font-semibold text-fg">What changed</dt><dd>{s.whatChanged}</dd></div>
                <div><dt className="font-semibold text-fg">What they would like improved</dt><dd>{s.wouldImprove}</dd></div>
                <div><dt className="font-semibold text-fg">Recommends us?</dt><dd>{s.recommends ? "Yes" : "Not yet"}</dd></div>
              </dl>
            </details>
          </li>
        ))}
      </ul>
    </div>
  );
}
