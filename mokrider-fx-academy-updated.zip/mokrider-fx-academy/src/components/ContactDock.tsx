"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowUp, Check, Copy, Mail, MessageCircle, X } from "lucide-react";
import { DEFAULT_MESSAGE, OPEN_CONTACT_EVENT, gmailUrl, mailtoUrl, outlookUrl, whatsappUrl, type ContactMessage } from "@/lib/contact";

/**
 * Floating dock on every public page: a WhatsApp chat button, an email button that opens a
 * "choose your mail app" dialog (Gmail, Outlook, default app, or copy the address), and back-to-top.
 * The dialog can also be opened with a custom message from <ContactTrigger>.
 */
export function ContactDock({ email, whatsapp }: { email: string | null; whatsapp: string | null }) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [message, setMessage] = useState<ContactMessage>(DEFAULT_MESSAGE);
  const [copied, setCopied] = useState(false);
  const [showTop, setShowTop] = useState(false);

  const open = useCallback((m?: ContactMessage) => {
    setMessage(m ?? DEFAULT_MESSAGE);
    setCopied(false);
    const d = dialogRef.current;
    if (d && !d.open) d.showModal();
  }, []);

  useEffect(() => {
    const onOpen = (e: Event) => open((e as CustomEvent<ContactMessage | undefined>).detail);
    window.addEventListener(OPEN_CONTACT_EVENT, onOpen);
    const onScroll = () => setShowTop(window.scrollY > 600);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener(OPEN_CONTACT_EVENT, onOpen);
      window.removeEventListener("scroll", onScroll);
    };
  }, [open]);

  async function copy() {
    if (!email) return;
    try {
      await navigator.clipboard.writeText(email);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  const wa = whatsappUrl(whatsapp, "Hello, I would like to ask about MOKRIDER FX ACADEMY.");
  const optionClass = "btn btn-ghost w-full justify-start";

  return (
    <>
      <div className="fixed bottom-4 right-4 z-30 flex flex-col items-end gap-2">
        {showTop && (
          <button type="button" className="dock-btn" aria-label="Back to top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
            <ArrowUp size={18} aria-hidden />
          </button>
        )}
        {email && (
          <button type="button" className="dock-btn" aria-label="Email us" onClick={() => open()}>
            <Mail size={18} aria-hidden />
          </button>
        )}
        {wa && (
          <a className="dock-btn dock-btn-primary" href={wa} target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp">
            <MessageCircle size={20} aria-hidden />
          </a>
        )}
      </div>

      <dialog
        ref={dialogRef}
        className="contact-dialog"
        aria-labelledby="contact-dialog-title"
        onClick={(e) => { if (e.target === dialogRef.current) dialogRef.current?.close(); }}
      >
        <div className="p-6">
          <div className="flex items-start justify-between gap-4">
            <h2 id="contact-dialog-title" className="text-2xl">Email us</h2>
            <button type="button" className="btn btn-ghost !px-3" aria-label="Close" onClick={() => dialogRef.current?.close()}>
              <X size={18} aria-hidden />
            </button>
          </div>
          {email ? (
            <>
              <p className="mt-2 text-sm text-muted">Pick your mail app. The message is already written for you, so you only need to press send.</p>
              <div className="mt-5 flex flex-col gap-2">
                <a className={optionClass} href={gmailUrl(email, message)} target="_blank" rel="noopener noreferrer">Open in Gmail</a>
                <a className={optionClass} href={outlookUrl(email, message)} target="_blank" rel="noopener noreferrer">Open in Outlook</a>
                <a className={optionClass} href={mailtoUrl(email, message)}>Open in my default mail app</a>
                <button type="button" className={optionClass} onClick={copy}>
                  {copied ? <Check size={16} aria-hidden /> : <Copy size={16} aria-hidden />}
                  {copied ? "Copied" : `Copy ${email}`}
                </button>
              </div>
              <p className="mt-4 text-xs text-muted" aria-live="polite">{copied ? "Address copied to your clipboard." : ""}</p>
            </>
          ) : (
            <p className="mt-4 text-muted">A contact email has not been set up yet.</p>
          )}
        </div>
      </dialog>
    </>
  );
}
