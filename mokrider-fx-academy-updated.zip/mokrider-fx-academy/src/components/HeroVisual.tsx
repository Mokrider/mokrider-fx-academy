import { HeroChart } from "@/components/HeroChart";

/**
 * Hero artwork: the teaching chart inside a "trading terminal" frame, a large faint M mark behind it,
 * and floating cards for the habits the academy teaches. All drawn in code, so it is original, sharp on
 * every screen, and follows the dark/light theme. Nothing here is live data.
 */
export function HeroVisual() {
  return (
    <div className="relative mx-auto w-full max-w-xl lg:max-w-none">
      {/* Big watermark of the logo mark */}
      <svg
        viewBox="0 0 64 64"
        aria-hidden="true"
        className="pointer-events-none absolute -right-10 -top-16 h-72 w-72 opacity-[0.07] md:h-96 md:w-96"
      >
        <line x1="14" y1="8" x2="14" y2="58" stroke="var(--text)" strokeWidth="3" strokeLinecap="round" />
        <rect x="9" y="16" width="10" height="34" rx="2.5" fill="var(--text)" />
        <path d="M19 20 L32 42 L45 16" fill="none" stroke="var(--text)" strokeWidth="6.5" strokeLinejoin="round" strokeLinecap="round" />
        <line x1="50" y1="3" x2="50" y2="54" stroke="var(--accent)" strokeWidth="3" strokeLinecap="round" />
        <rect x="45" y="10" width="10" height="36" rx="2.5" fill="var(--accent)" />
      </svg>

      {/* Red glow under the frame */}
      <div aria-hidden="true" className="absolute inset-x-6 -bottom-6 h-24 rounded-full bg-accent/40 blur-3xl" />

      {/* Terminal frame */}
      <div className="hero-frame relative overflow-hidden rounded-xl border border-line bg-surface">
        <div className="flex items-center justify-between border-b border-line px-4 py-2.5">
          <div className="flex items-center gap-1.5" aria-hidden="true">
            <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
          </div>
          <p className="text-[0.65rem] font-semibold uppercase tracking-[0.3em] text-muted">XAUUSD &middot; EURUSD</p>
          <span className="w-10" aria-hidden="true" />
        </div>
        <div className="p-3 sm:p-4">
          <HeroChart />
        </div>
      </div>

      {/* Floating cards (hidden on very small screens so they never cover the chart) */}
      <div className="hero-float hero-float-a absolute -left-3 top-24 hidden w-48 rounded-lg border border-line bg-card p-3 shadow-xl sm:block lg:-left-8">
        <p className="text-[0.65rem] font-bold uppercase tracking-widest text-accent-text">Step 1 &middot; Plan</p>
        <p className="mt-1 text-sm font-semibold">Risk 1% of the account</p>
        <p className="mt-0.5 text-xs text-muted">Know where the idea is wrong first.</p>
      </div>
      <div className="hero-float hero-float-b absolute -bottom-5 right-3 hidden w-52 rounded-lg border border-line bg-card p-3 shadow-xl sm:block lg:-right-5">
        <p className="text-[0.65rem] font-bold uppercase tracking-widest text-accent-text">Step 2 &middot; Journal</p>
        <p className="mt-1 text-sm font-semibold">Every trade, win or loss</p>
        <p className="mt-0.5 text-xs text-muted">Your record is your proof.</p>
      </div>
    </div>
  );
}
