"use client";
import type { ReactNode } from "react";

export function NumInput({ id, label, value, onChange, hint, placeholder }: { id: string; label: string; value: string; onChange: (v: string) => void; hint?: string; placeholder?: string }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-medium">{label}</label>
      <input id={id} inputMode="decimal" autoComplete="off" value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} className="field" />
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  );
}

export function SelectInput({ id, label, value, onChange, options, hint }: { id: string; label: string; value: string; onChange: (v: string) => void; options: [string, string][]; hint?: string }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-medium">{label}</label>
      <select id={id} value={value} onChange={(e) => onChange(e.target.value)} className="field">
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  );
}

export function Result({ label, value, strong }: { label: string; value: ReactNode; strong?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-line py-2">
      <dt className="text-sm text-muted">{label}</dt>
      <dd className={strong ? "font-display text-2xl" : "font-medium"}>{value}</dd>
    </div>
  );
}

export function Notes({ items, tone = "warn" }: { items: string[]; tone?: "warn" | "error" }) {
  if (!items.length) return null;
  return (
    <ul className={`mt-4 space-y-2 text-sm ${tone === "error" ? "text-down" : "text-muted"}`}>
      {items.map((w) => <li key={w} className="rounded-md border border-line bg-surface p-3">{w}</li>)}
    </ul>
  );
}

export function Panel({ children }: { children: ReactNode }) {
  return <div className="rounded-md border border-line bg-card p-6" aria-live="polite">{children}</div>;
}
