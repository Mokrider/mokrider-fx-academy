"use client";
import { useState } from "react";
import { calcRiskReward, type Direction } from "@/lib/trading/riskReward";
import { fmt, parseNum } from "@/lib/trading/num";
import { NumInput, Notes, Panel, Result, SelectInput } from "./ui";
import { useInstrumentSetup } from "./useInstrumentSetup";

function PlanDiagram({ direction, entry, stop, target }: { direction: Direction; entry: number; stop: number; target: number }) {
  const lo = Math.min(entry, stop, target), hi = Math.max(entry, stop, target);
  const y = (p: number) => 20 + ((hi - p) / (hi - lo || 1)) * 160;
  const label = (name: string, p: number) => `${name} ${p}`;
  return (
    <svg viewBox="0 0 320 200" role="img" aria-label={`Trade plan: ${direction === "LONG" ? "long" : "short"} from ${entry}, stop at ${stop}, target at ${target}`} className="w-full rounded-md border border-line bg-surface">
      <rect x="20" y={Math.min(y(entry), y(stop))} width="180" height={Math.abs(y(entry) - y(stop))} fill="var(--down)" opacity="0.22" />
      <rect x="20" y={Math.min(y(entry), y(target))} width="180" height={Math.abs(y(entry) - y(target))} fill="var(--up)" opacity="0.22" />
      {[[stop, "Stop", "var(--down)"], [entry, "Entry", "var(--text)"], [target, "Target", "var(--up)"]].map(([p, n, c]) => (
        <g key={n as string}>
          <line x1="20" x2="200" y1={y(p as number)} y2={y(p as number)} stroke={c as string} strokeWidth="2" />
          <text x="208" y={y(p as number) + 4} fontSize="12" fill="var(--text)">{label(n as string, p as number)}</text>
        </g>
      ))}
    </svg>
  );
}

export function RiskRewardCalculator() {
  const setup = useInstrumentSetup();
  const [direction, setDirection] = useState<Direction>("LONG");
  const [entry, setEntry] = useState("");
  const [stop, setStop] = useState("");
  const [target, setTarget] = useState("");
  const [lots, setLots] = useState("");

  const e = parseNum(entry), s = parseNum(stop), t = parseNum(target);
  const result = e !== null && s !== null && t !== null
    ? calcRiskReward({ direction, entry: e, stop: s, target: t, lots: parseNum(lots), contractSize: setup.contractSize, quoteToAccountRate: setup.rate })
    : null;

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div className="space-y-4">
        <SelectInput id="dir" label="Direction" value={direction} onChange={(v) => setDirection(v as Direction)} options={[["LONG", "Long (buy)"], ["SHORT", "Short (sell)"]]} />
        <div className="grid gap-4 sm:grid-cols-3">
          <NumInput id="entry" label="Entry" value={entry} onChange={setEntry} />
          <NumInput id="stop" label="Stop-loss" value={stop} onChange={setStop} />
          <NumInput id="target" label="Take-profit" value={target} onChange={setTarget} />
        </div>
        <details className="rounded-md border border-line p-4">
          <summary className="cursor-pointer text-sm font-medium">Estimate profit and loss in money (optional)</summary>
          <div className="mt-4 space-y-4">
            <NumInput id="lots" label="Position size (lots)" value={lots} onChange={setLots} />
            {setup.fields}
          </div>
        </details>
      </div>
      <Panel>
        <h2 className="text-2xl">Result</h2>
        {!result && <p className="mt-3 text-sm text-muted">Enter entry, stop-loss and take-profit.</p>}
        {result && !result.ok && <Notes items={[result.error]} tone="error" />}
        {result && result.ok && e !== null && s !== null && t !== null && (
          <>
            <dl className="mt-3">
              <Result label="Risk : reward" value={`1 : ${fmt(result.ratio)}`} strong />
              <Result label="Risk distance" value={fmt(result.riskDistance, 5)} />
              <Result label="Reward distance" value={fmt(result.rewardDistance, 5)} />
              <Result label="Win rate needed to break even (before costs)" value={`${fmt(result.breakEvenWinRate, 1)}%`} />
              {result.lossAtStop !== null && <Result label={`Loss at stop (${setup.account})`} value={fmt(result.lossAtStop)} />}
              {result.profitAtTarget !== null && <Result label={`Profit at target (${setup.account})`} value={fmt(result.profitAtTarget)} />}
            </dl>
            <div className="mt-4"><PlanDiagram direction={direction} entry={e} stop={s} target={t} /></div>
            <Notes items={["A good ratio does not make a trade likely to win. Spread, commission and slippage also change the real numbers."]} />
          </>
        )}
      </Panel>
    </div>
  );
}
