"use client";
import { useState } from "react";
import { moveValue, pipsToPrice, valuePerPipPerLot } from "@/lib/trading/pips";
import { fmt, parseNum } from "@/lib/trading/num";
import { NumInput, Notes, Panel, Result } from "./ui";
import { useInstrumentSetup } from "./useInstrumentSetup";

export function PipCalculator() {
  const setup = useInstrumentSetup();
  const [pips, setPips] = useState("10");
  const [lots, setLots] = useState("1");

  const n = parseNum(pips), l = parseNum(lots);
  const ready = n !== null && l !== null && setup.pipSize && setup.contractSize && setup.rate;
  const distance = ready ? pipsToPrice(n as number, setup.pipSize as number) : null;

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <NumInput id="pips" label="Move in pips" value={pips} onChange={setPips} />
          <NumInput id="lots" label="Position size (lots)" value={lots} onChange={setLots} />
        </div>
        {setup.fields}
      </div>
      <Panel>
        <h2 className="text-2xl">Result</h2>
        {!ready || distance === null ? <p className="mt-3 text-sm text-muted">Fill in the fields to see what the move is worth.</p> : (
          <dl className="mt-3">
            <Result label="Price distance" value={fmt(distance, 5)} />
            <Result label={`Value of that move (${setup.account})`} value={fmt(moveValue(distance, l as number, setup.contractSize as number, setup.rate as number))} strong />
            <Result label={`Value of 1 pip per 1.00 lot (${setup.account})`} value={fmt(valuePerPipPerLot(setup.pipSize as number, setup.contractSize as number, setup.rate as number))} />
          </dl>
        )}
        <Notes items={["Pip and point definitions are not identical across brokers, especially for Gold. Use your broker's specification for the pip size and contract size."]} />
      </Panel>
    </div>
  );
}
