"use client";
import { useState } from "react";
import { CUSTOM_SPEC, INSTRUMENTS } from "@/lib/trading/instruments";
import { parseNum } from "@/lib/trading/num";
import { NumInput, SelectInput } from "./ui";

const CURRENCIES = ["USD", "EUR", "GBP", "KES", "JPY"];
const ALL = [...INSTRUMENTS, CUSTOM_SPEC];

/** Shared instrument and currency inputs. Every spec is editable because brokers differ. */
export function useInstrumentSetup(opts: { lot?: boolean; defaultAccount?: string } = {}) {
  const [preset, setPreset] = useState(INSTRUMENTS[0].symbol);
  const first = INSTRUMENTS[0];
  const [contractSize, setContractSize] = useState(String(first.contractSize));
  const [pipSize, setPipSize] = useState(String(first.pipSize));
  const [lotStep, setLotStep] = useState(String(first.lotStep));
  const [minLot, setMinLot] = useState(String(first.minLot));
  const [quote, setQuote] = useState(first.quoteCurrency);
  const [account, setAccount] = useState(opts.defaultAccount ?? "USD");
  const [rate, setRate] = useState("");

  function choose(symbol: string) {
    const s = ALL.find((x) => x.symbol === symbol) ?? CUSTOM_SPEC;
    setPreset(symbol);
    setContractSize(String(s.contractSize));
    setPipSize(String(s.pipSize));
    setLotStep(String(s.lotStep));
    setMinLot(String(s.minLot));
    setQuote(s.quoteCurrency);
  }

  const spec = ALL.find((x) => x.symbol === preset) ?? CUSTOM_SPEC;
  const sameCurrency = quote === account;
  const effectiveRate = sameCurrency ? 1 : parseNum(rate);

  const fields = (
    <div className="space-y-4">
      <SelectInput id="preset" label="Instrument" value={preset} onChange={choose} options={ALL.map((s) => [s.symbol, s.label])} hint={spec.note} />
      <div className="grid gap-4 sm:grid-cols-2">
        <NumInput id="contract" label="Contract size (units per 1.00 lot)" value={contractSize} onChange={setContractSize} />
        <NumInput id="pipsize" label="Pip size (price distance)" value={pipSize} onChange={setPipSize} />
        {opts.lot && <NumInput id="lotstep" label="Lot step" value={lotStep} onChange={setLotStep} />}
        {opts.lot && <NumInput id="minlot" label="Minimum lot" value={minLot} onChange={setMinLot} />}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <SelectInput id="quote" label="Instrument quote currency" value={quote} onChange={setQuote} options={CURRENCIES.map((c) => [c, c])} />
        <SelectInput id="account" label="Account currency" value={account} onChange={setAccount} options={CURRENCIES.map((c) => [c, c])} />
      </div>
      {!sameCurrency && (
        <NumInput id="rate" label={`Exchange rate: 1 ${quote} = ? ${account}`} value={rate} onChange={setRate} hint="Enter the rate yourself. No rate is assumed or fetched, so results stay in your control." />
      )}
    </div>
  );

  return {
    fields, account, quote, rate: effectiveRate,
    contractSize: parseNum(contractSize), pipSize: parseNum(pipSize), lotStep: parseNum(lotStep), minLot: parseNum(minLot),
  };
}
