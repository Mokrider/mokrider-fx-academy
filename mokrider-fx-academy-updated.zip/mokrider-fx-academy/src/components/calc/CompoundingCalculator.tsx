"use client";
import { useState } from "react";
import { calcCompounding } from "@/lib/trading/compounding";
import { fmt, parseNum } from "@/lib/trading/num";
import { NumInput, Notes, Panel, Result, SelectInput } from "./ui";

export function CompoundingCalculator() {
  const [start, setStart] = useState("");
  const [contribution, setContribution] = useState("0");
  const [periods, setPeriods] = useState("12");
  const [rate, setRate] = useState("");
  const [unit, setUnit] = useState("months");

  const a = parseNum(start), c = parseNum(contribution), p = parseNum(periods), r = parseNum(rate);
  const result = a !== null && c !== null && p !== null && r !== null ? calcCompounding({ start: a, contribution: c, periods: p, ratePercent: r }) : null;

  let spark: string | null = null;
  if (result && result.ok) {
    const vals = result.rows.map((x) => x.balance);
    const lo = Math.min(...vals, a ?? 0), hi = Math.max(...vals, 1);
    spark = vals.map((v, i) => `${(i / Math.max(1, vals.length - 1)) * 300},${90 - ((v - lo) / (hi - lo || 1)) * 80}`).join(" ");
  }

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div className="grid gap-4 sm:grid-cols-2">
        <NumInput id="start" label="Starting balance" value={start} onChange={setStart} />
        <NumInput id="contrib" label="Added each period" value={contribution} onChange={setContribution} hint="Added at the end of each period." />
        <SelectInput id="unit" label="Period" value={unit} onChange={setUnit} options={[["weeks", "Weekly"], ["months", "Monthly"], ["years", "Yearly"]]} />
        <NumInput id="periods" label={`Number of ${unit}`} value={periods} onChange={setPeriods} />
        <NumInput id="rate" label={`Assumed return per period (%)`} value={rate} onChange={setRate} hint="A number you choose. Real trading returns are not steady and can be negative." />
      </div>
      <Panel>
        <h2 className="text-2xl">Scenario</h2>
        {!result && <p className="mt-3 text-sm text-muted">Enter a starting balance and an assumed return.</p>}
        {result && !result.ok && <Notes items={result.errors} tone="error" />}
        {result && result.ok && (
          <>
            <dl className="mt-3">
              <Result label={`Balance after ${periods} ${unit}`} value={fmt(result.final)} strong />
              <Result label="Total you put in" value={fmt(result.contributed)} />
              <Result label="Growth in this scenario" value={fmt(result.growth)} />
            </dl>
            {spark && (
              <svg viewBox="0 0 300 100" className="mt-4 w-full rounded-md border border-line bg-surface" role="img" aria-label="Line showing the scenario balance over time">
                <polyline points={spark} fill="none" stroke="var(--accent)" strokeWidth="2" />
              </svg>
            )}
            <details className="mt-4 text-sm">
              <summary className="cursor-pointer font-medium">Period by period</summary>
              <div className="mt-2 max-h-64 overflow-auto">
                <table className="w-full text-left"><thead className="text-muted"><tr><th className="py-1">#</th><th>Balance</th><th>Put in</th></tr></thead>
                  <tbody>{result.rows.map((row) => <tr key={row.period} className="border-t border-line"><td className="py-1">{row.period}</td><td>{fmt(row.balance)}</td><td>{fmt(row.contributed)}</td></tr>)}</tbody>
                </table>
              </div>
            </details>
          </>
        )}
        <Notes items={["This is arithmetic for a hypothetical scenario. It is not a prediction, a target or a promise of any trading result."]} />
      </Panel>
    </div>
  );
}
