"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { DISPLAY_ZONES, SESSIONS, isSessionOpen, nextChange, sessionWindow } from "@/lib/trading/sessions";
import { SESSION_TRAITS, activeOverlaps, dayTimeline, formatCountdown, isWeekendClosed } from "@/lib/trading/sessionInfo";
import { zonedParts } from "@/lib/trading/sessions";
import { SelectInput } from "./ui";

const hm = (d: Date, tz: string) =>
  new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(d);
const hms = (d: Date, tz: string) =>
  new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).format(d);
const longDate = (d: Date, tz: string) =>
  new Intl.DateTimeFormat("en-GB", { timeZone: tz, weekday: "long", day: "numeric", month: "long" }).format(d);
const shortWhen = (d: Date, tz: string) =>
  new Intl.DateTimeFormat("en-GB", { timeZone: tz, weekday: "short", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(d);

function deviceZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "Africa/Nairobi";
  } catch {
    return "Africa/Nairobi";
  }
}

function zoneLabel(z: string, device: string): string {
  if (z === device) return `My device (${z.replace(/_/g, " ")})`;
  return z === "Africa/Nairobi" ? "East Africa Time (Nairobi)" : z.replace(/_/g, " ");
}

/**
 * Live trading-session timer. Shows your own local time, which sessions are open, a countdown to each
 * open or close, a 24-hour map of the day and what each session is usually like.
 * `compact` keeps just the map and the countdowns (used on the home page).
 */
export function SessionClock({ compact = false }: { compact?: boolean }) {
  const [now, setNow] = useState<Date | null>(null);
  const [device, setDevice] = useState("Africa/Nairobi");
  const [tz, setTz] = useState("Africa/Nairobi");

  useEffect(() => {
    const d = deviceZone();
    setDevice(d);
    setTz(d);
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // Open/close moments are searched for only every 5 seconds, since they do not change second to second.
  const bucket = now ? Math.floor(now.getTime() / 5000) : 0;
  const changes = useMemo(
    () => Object.fromEntries(SESSIONS.map((s) => [s.id, nextChange(s, new Date(bucket * 5000))])) as Record<string, Date | null>,
    [bucket],
  );

  if (!now) return <p className="text-muted">Loading clock...</p>;

  const zones = Array.from(new Set([device, ...DISPLAY_ZONES]));
  const weekend = isWeekendClosed(now);
  const overlaps = weekend ? [] : activeOverlaps(now);
  const { rows, nowMin } = dayTimeline(now, tz);
  const todayInTz = zonedParts(now, tz).day;

  return (
    <div className="space-y-8">
      {/* Live local time */}
      <div className={compact ? "" : "grid gap-6 sm:grid-cols-[1fr_1fr] sm:items-end"}>
        <div>
          <p className="text-sm font-medium text-muted">{compact ? "Your time now" : "Time now"}</p>
          <p className="font-display text-4xl tabular-nums sm:text-5xl" aria-live="off">{hms(now, tz)}</p>
          <p className="mt-1 text-sm text-muted">{longDate(now, tz)} &middot; {zoneLabel(tz, device)}</p>
        </div>
        {!compact && (
          <SelectInput id="tz" label="Show times in" value={tz} onChange={setTz} options={zones.map((z) => [z, zoneLabel(z, device)])} hint="Your device's time zone is picked for you. Daylight saving is handled automatically." />
        )}
      </div>

      {weekend && (
        <p className="rounded-md border border-line bg-surface p-3 text-sm">The major forex centres are closed for the weekend. Trading resumes around Sunday evening New York time, as the Sydney session begins.</p>
      )}
      {overlaps.map((o) => (
        <p key={o.label} className="rounded-md border border-accent p-3 text-sm"><strong>{o.label} overlap is on now.</strong> {o.note}</p>
      ))}

      {/* 24-hour map */}
      <section aria-label="Today's sessions on a 24-hour map">
        <div className="relative">
          <div className="space-y-2">
            {rows.map((r) => {
              const def = SESSIONS.find((s) => s.id === r.id)!;
              const isOpen = !weekend && isSessionOpen(def, now);
              return (
                <div key={r.id} className="grid grid-cols-[4.5rem_1fr] items-center gap-3">
                  <span className={`text-xs font-semibold uppercase tracking-wider ${isOpen ? "text-fg" : "text-muted"}`}>{r.name}</span>
                  <div className="relative h-5 rounded bg-surface ring-1 ring-inset ring-[var(--border)]">
                    {r.segments.map((seg) => (
                      <span
                        key={seg.startMin}
                        className="absolute top-0 h-full rounded"
                        style={{
                          left: `${(seg.startMin / 1440) * 100}%`,
                          width: `${((seg.endMin - seg.startMin) / 1440) * 100}%`,
                          background: "var(--accent)",
                          opacity: isOpen ? 1 : 0.4,
                        }}
                        title={`${r.name}: ${String(Math.floor(seg.startMin / 60)).padStart(2, "0")}:${String(seg.startMin % 60).padStart(2, "0")} to ${String(Math.floor(seg.endMin / 60) % 24).padStart(2, "0")}:${String(seg.endMin % 60).padStart(2, "0")}`}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
          {/* "Now" marker */}
          <div className="pointer-events-none absolute bottom-6 top-0 grid grid-cols-[4.5rem_1fr] gap-3" aria-hidden>
            <span />
            <div className="relative">
              <span className="absolute -top-1 bottom-0 w-0.5 bg-fg" style={{ left: `${(nowMin / 1440) * 100}%` }} />
            </div>
          </div>
          <div className="mt-1 grid grid-cols-[4.5rem_1fr] gap-3 text-[0.65rem] text-muted" aria-hidden>
            <span />
            <div className="flex justify-between"><span>00:00</span><span>06:00</span><span>12:00</span><span>18:00</span><span>24:00</span></div>
          </div>
        </div>
        <p className="mt-2 text-xs text-muted">Bright bar means open now. The white line is the current time in {zoneLabel(tz, device)}.</p>
      </section>

      {/* Sessions */}
      <ul className={compact ? "grid gap-3 sm:grid-cols-2" : "grid gap-6 lg:grid-cols-2"}>
        {SESSIONS.map((s) => {
          const isOpen = !weekend && isSessionOpen(s, now);
          const w = sessionWindow(s, now);
          const change = changes[s.id];
          const secs = change ? (change.getTime() - now.getTime()) / 1000 : null;
          const traits = SESSION_TRAITS[s.id];
          const dayNote = zonedParts(w.end, tz).day !== todayInTz ? " (next day)" : "";
          return (
            <li key={s.id} className="bg-card flex flex-col gap-3 border border-line p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-xl">{s.name}</h3>
                  {!compact && <p className="text-sm text-muted">{traits.tagline}</p>}
                </div>
                <span className={`rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-wider ${isOpen ? "border-up text-up" : "border-line text-muted"}`}>{isOpen ? "Open" : "Closed"}</span>
              </div>
              {secs !== null && (
                <p className="font-display text-2xl tabular-nums">
                  <span className="text-sm font-normal text-muted">{isOpen ? "Closes in " : "Opens in "}</span>{formatCountdown(secs)}
                </p>
              )}
              <p className="text-sm text-muted">
                {hm(w.start, tz)} to {hm(w.end, tz)}{dayNote} your selected time
                <span className="block text-xs">{String(s.start[0]).padStart(2, "0")}:00 to {String(s.end[0]).padStart(2, "0")}:00 local {s.name} time{change ? ` · ${isOpen ? "closes" : "opens"} ${shortWhen(change, tz)}` : ""}</span>
              </p>
              {!compact && (
                <>
                  <div className="flex items-center gap-3 text-sm">
                    <span className="flex gap-1" role="img" aria-label={`Typical activity ${traits.activity} out of 4`}>
                      {[1, 2, 3, 4].map((n) => (
                        <span key={n} className="h-2.5 w-5 rounded-sm" style={{ background: n <= traits.activity ? "var(--accent)" : "var(--border)" }} />
                      ))}
                    </span>
                    <span className="text-muted">{traits.activityLabel}</span>
                  </div>
                  <p className="text-sm">{traits.character}</p>
                  <dl className="space-y-2 border-t border-line pt-3 text-sm">
                    <div><dt className="font-semibold">Gold (XAUUSD)</dt><dd className="text-muted">{traits.gold}</dd></div>
                    <div><dt className="font-semibold">EURUSD</dt><dd className="text-muted">{traits.eurusd}</dd></div>
                    <div><dt className="font-semibold">Most active currencies</dt><dd className="text-muted">{traits.mainCurrencies}</dd></div>
                    <div>
                      <dt className="font-semibold">Worth watching</dt>
                      <dd><ul className="list-disc pl-5 text-muted">{traits.watch.map((x) => <li key={x}>{x}</li>)}</ul></dd>
                    </div>
                  </dl>
                </>
              )}
            </li>
          );
        })}
      </ul>

      {compact ? (
        <Link href="/tools/session-clock" className="link-accent inline-block text-sm font-semibold">Open the full session timer &rarr;</Link>
      ) : (
        <p className="text-xs text-muted">
          Hours are typical windows in each centre&apos;s local time, converted with real time-zone rules so daylight saving is handled. They are not official exchange schedules, and forex trades around the clock on weekdays. The notes describe tendencies seen often, not rules. News can make any session fast, and a quiet one can still surprise you. Educational only, not advice.
        </p>
      )}
    </div>
  );
}
