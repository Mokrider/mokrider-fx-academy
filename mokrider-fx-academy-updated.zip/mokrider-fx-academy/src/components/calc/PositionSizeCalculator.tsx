"use client";
import { useState } from "react";
import { calcPositionSize } from "@/lib/trading/positionSize";
import { fmt, parseNum } from "@/lib/trading/num";
import { NumInput, Notes, Panel, Result } from "./ui";
import { useInstrumentSetup } from "./useInstrumentSetup";

export function PositionSizeCalculator() {
  const setup = useInstrumentSetup({ lot: true });
  const [balance, setBalance] = useState("");
  const [risk, setRisk] = useState("1");
  const [entry, setEntry] = useState("");
  const [stop, setStop] = useState("");

  const b = parseNum(balance), r = parseNum(risk), e = parseNum(entry), s = parseNum(stop);
  const result = b !== null && r !== null && e !== null && s !== null
    ? calcPositionSize({
        balance: b, riskPercent: r, entry: e, stop: s, contractSize: setup.contractSize ?? 0,
        quoteToAccountRate: setup.rate ?? 0, lotStep: setup.lotStep ?? 0, minLot: setup.minLot ?? 0,
      })
    : null;

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <NumInput id="balance" label={`Account balance (${setup.account})`} value={balance} onChange={setBalance} />
          <NumInput id="risk" label="Risk per trade (%)" value={risk} onChange={setRisk} />
          <NumInput id="entry" label="Entry price" value={entry} onChange={setEntry} />
          <NumInput id="stop" label="Stop-loss price" value={stop} onChange={setStop} />
        </div>
        {setup.fields}
      </div>
      <Panel>
        <h2 className="text-2xl">Result</h2>
        {!result && <p className="mt-3 text-sm text-muted">Enter your balance, risk, entry and stop-loss to see the position size.</p>}
        {result && !result.ok && <Notes items={result.errors} tone="error" />}
        {result && result.ok && (
          <>
            <dl className="mt-3">
              <Result label="Position size" value={`${fmt(result.lots, 2)} lots`} strong />
              <Result label={`Amount you chose to risk (${setup.account})`} value={fmt(result.riskAmount)} />
              <Result label="Stop distance (price)" value={fmt(result.stopDistance, 5)} />
              <Result label={`Loss per 1.00 lot at the stop (${setup.account})`} value={fmt(result.lossPerLot)} />
              <Result label="Unrounded size" value={`${fmt(result.rawLots, 4)} lots`} />
              <Result label={`Actual risk with rounded size (${setup.account})`} value={`${fmt(result.actualRisk)} (${fmt(result.actualRiskPercent)}%)`} />
            </dl>
            <Notes items={result.warnings} />
          </>
        )}
        <details className="mt-6 text-sm text-muted">
          <summary className="cursor-pointer font-medium text-fg">How this is calculated</summary>
          <p className="mt-2">Amount at risk = balance x risk %.</p>
          <p className="mt-1">Loss per lot = |entry - stop| x contract size x exchange rate (quote currency to account currency).</p>
          <p className="mt-1">Position size = amount at risk / loss per lot, rounded down to your lot step.</p>
          <p className="mt-1">Limits: it does not include spread, commission, swap or slippage, and it relies on the contract specification and exchange rate you enter. Check your broker&apos;s own specification before trading.</p>
        </details>
      </Panel>
    </div>
  );
}
