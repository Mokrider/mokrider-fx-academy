"use client";
import { ActionForm, type FormState } from "@/components/ActionForm";

export function PhoneForm({ action, label }: { action: (prev: FormState, fd: FormData) => Promise<FormState>; label: string }) {
  return (
    <ActionForm action={action} submitLabel={label}>
      <div>
        <label htmlFor="phone" className="mb-1 block text-sm font-medium">M-Pesa phone number</label>
        <input id="phone" name="phone" type="tel" inputMode="tel" autoComplete="tel" required placeholder="0712 345 678" className="field" />
        <p className="mt-1 text-xs text-muted">You will get a prompt on this phone to enter your M-Pesa PIN. We never see your PIN.</p>
      </div>
    </ActionForm>
  );
}
