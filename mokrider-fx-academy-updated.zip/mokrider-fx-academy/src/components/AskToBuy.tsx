import Link from "next/link";
import { ContactTrigger } from "@/components/ContactTrigger";
import { getContact, whatsappUrl } from "@/lib/contact";

/**
 * Buttons for when something cannot be bought online yet (no M-Pesa, no price, no file).
 * They send a ready-written message by WhatsApp or email instead of leaving a dead button.
 */
export function AskToBuy({ subject, message, label = "Ask about this" }: { subject: string; message: string; label?: string }) {
  const c = getContact();
  const wa = whatsappUrl(c.whatsapp, `${subject}\n\n${message}`);
  return (
    <div className="flex flex-col gap-2">
      {wa && <a className="btn btn-primary w-full" href={wa} target="_blank" rel="noopener noreferrer">{label} on WhatsApp</a>}
      {c.email && <ContactTrigger className={`btn w-full ${wa ? "btn-ghost" : "btn-primary"}`} message={{ subject, body: message }}>{label} by email</ContactTrigger>}
      {!wa && !c.email && <Link href="/contact" className="btn btn-primary w-full">Contact us</Link>}
    </div>
  );
}
