"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { authClient } from "@/lib/auth-client";

export function AuthForm({ mode, next }: { mode: "login" | "register"; next: string }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    const form = new FormData(e.currentTarget);
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");
    const name = String(form.get("name") ?? "").trim();

    if (mode === "register" && name.length < 2) return setError("Enter your name.");
    if (password.length < 10) return setError("Use a password of at least 10 characters.");

    setPending(true);
    const result =
      mode === "register"
        ? await authClient.signUp.email({ name, email, password })
        : await authClient.signIn.email({ email, password });
    setPending(false);

    if (result.error) {
      setError(mode === "login" ? "Email or password is incorrect." : result.error.message ?? "Could not create the account.");
      return;
    }
    router.push(next);
    router.refresh();
  }

  const isRegister = mode === "register";
  return (
    <form onSubmit={onSubmit} className="space-y-4" noValidate>
      {isRegister && (
        <div>
          <label htmlFor="name" className="mb-1 block text-sm font-medium">Full name</label>
          <input id="name" name="name" autoComplete="name" required className="field" />
        </div>
      )}
      <div>
        <label htmlFor="email" className="mb-1 block text-sm font-medium">Email</label>
        <input id="email" name="email" type="email" autoComplete="email" required className="field" />
      </div>
      <div>
        <label htmlFor="password" className="mb-1 block text-sm font-medium">Password</label>
        <input id="password" name="password" type="password" autoComplete={isRegister ? "new-password" : "current-password"} required minLength={10} className="field" />
        {isRegister && <p className="mt-1 text-xs text-muted">At least 10 characters.</p>}
      </div>
      <p role="alert" aria-live="assertive" className="min-h-5 text-sm text-down">{error}</p>
      <button type="submit" className="btn btn-primary w-full" disabled={pending}>
        {pending ? "Please wait..." : isRegister ? "Create account" : "Sign in"}
      </button>
      <p className="text-sm text-muted">
        {isRegister ? "Already have an account? " : "New here? "}
        <Link className="link-accent" href={isRegister ? "/login" : "/register"}>{isRegister ? "Sign in" : "Create an account"}</Link>
      </p>
    </form>
  );
}
