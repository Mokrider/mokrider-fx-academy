import { prisma } from "@/lib/db";
import { facts, FACTS_AS_OF } from "@/content/facts";

/**
 * Numbers strip. Owner-supplied teaching facts come from src/content/facts.ts. The learner count on
 * this platform is read live from the database and only appears once it is above zero, so it can
 * never show a number that is not true.
 */
export async function FactsStrip() {
  let enrolled = 0;
  try {
    enrolled = await prisma.enrollment.count();
  } catch {
    enrolled = 0;
  }
  const items = [
    ...facts.filter((f) => f.value > 0).map((f) => ({ id: f.id, big: `${f.prefix ?? ""}${f.value}${f.suffix ?? ""}`, label: f.label })),
    ...(enrolled > 0 ? [{ id: "enrolled", big: String(enrolled), label: "course enrolments on this platform (live)" }] : []),
  ];
  if (items.length === 0) return null;
  return (
    <section className="border-b border-line" aria-label="The academy in numbers">
      <div className="container-page py-8">
        <ul className="grid gap-6 text-center sm:grid-cols-2 lg:grid-cols-4">
          {items.map((i) => (
            <li key={i.id}>
              <p className="font-display text-4xl text-accent-text">{i.big}</p>
              <p className="mt-1 text-sm text-muted">{i.label}</p>
            </li>
          ))}
        </ul>
        <p className="mt-5 text-center text-xs text-muted">Teaching figures are the academy&apos;s own count as of {FACTS_AS_OF}. They describe how much we have taught, not trading results.</p>
      </div>
    </section>
  );
}
