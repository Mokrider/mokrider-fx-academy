"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X } from "lucide-react";

type NavLink = { href: string; label: string };

/**
 * Phone menu. Unlike a bare <details>, it closes when you tap a link, change page, press Escape,
 * or tap anywhere outside it.
 */
export function MobileMenu({ links, accountLink, guest }: { links: NavLink[]; accountLink: NavLink | null; guest: boolean }) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    const onDown = (e: MouseEvent | TouchEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("touchstart", onDown);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("touchstart", onDown);
    };
  }, [open]);

  const item = "rounded px-3 py-2 text-fg hover:bg-card";
  const close = () => setOpen(false);

  return (
    <div ref={rootRef} className="relative lg:hidden">
      <button
        type="button"
        className="btn btn-ghost !px-3"
        aria-label={open ? "Close menu" : "Open menu"}
        aria-expanded={open}
        aria-controls="mobile-menu"
        onClick={() => setOpen((o) => !o)}
      >
        {open ? <X size={20} aria-hidden /> : <Menu size={20} aria-hidden />}
      </button>
      {open && (
        <nav id="mobile-menu" aria-label="Mobile" className="absolute right-0 mt-2 flex max-h-[80vh] w-64 flex-col gap-1 overflow-y-auto rounded-md border border-line bg-surface p-3 shadow-lg">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className={item} onClick={close}>{l.label}</Link>
          ))}
          <hr className="my-1 border-line" />
          {accountLink && <Link href={accountLink.href} className={item} onClick={close}>{accountLink.label}</Link>}
          {guest && (
            <>
              <Link href="/login" className={item} onClick={close}>Sign in</Link>
              <Link href="/register" className="rounded px-3 py-2 text-accent-text hover:bg-card" onClick={close}>Create account</Link>
            </>
          )}
        </nav>
      )}
    </div>
  );
}
