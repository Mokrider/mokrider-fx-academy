import Link from "next/link";

export function AdminHeader({ title, newHref, saved }: { title: string; newHref?: string; saved?: boolean }) {
  return (
    <div className="mb-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-4xl">{title}</h1>
        {newHref && <Link href={newHref} className="btn btn-primary">New</Link>}
      </div>
      {saved && <p role="status" className="mt-4 rounded-md border border-line bg-surface p-3 text-sm text-up">Saved.</p>}
    </div>
  );
}
