import Link from "next/link";
import { Logo } from "@/components/Logo";
import { ContactDock } from "@/components/ContactDock";
import { getContact } from "@/lib/contact";

const columns: { title: string; links: { href: string; label: string }[] }[] = [
  {
    title: "Learn",
    links: [
      { href: "/learn", label: "Courses" },
      { href: "/tools", label: "Trading tools" },
      { href: "/tools/journal", label: "Trading journal" },
      { href: "/tools/session-clock", label: "Session timer" },
      { href: "/coach", label: "Market Coach" },
      { href: "/market-analysis", label: "Market analysis" },
      { href: "/blog", label: "Blog" },
    ],
  },
  {
    title: "Work with us",
    links: [
      { href: "/mentorship", label: "Mentorship" },
      { href: "/mentorship/apply", label: "Apply for 1-on-1" },
      { href: "/shop", label: "Shop" },
      { href: "/sponsor", label: "Sponsor a student" },
      { href: "/stories", label: "Student stories" },
    ],
  },
  {
    title: "About",
    links: [
      { href: "/about", label: "The mentor" },
      { href: "/contact", label: "Contact" },
      { href: "/risk-disclosure", label: "Risk disclosure" },
    ],
  },
];

export function SiteFooter() {
  const c = getContact();
  return (
    <footer className="mt-24 border-t border-line bg-surface">
      <div className="container-page grid gap-10 py-12 md:grid-cols-[1.4fr_repeat(3,1fr)]">
        <div className="space-y-4">
          <Logo />
          <p className="max-w-sm text-sm text-muted">
            Trading education focused on XAUUSD (Gold) and EURUSD. Times shown in East Africa Time (Africa/Nairobi) unless stated.
          </p>
          {(c.email || c.phone) && (
            <p className="text-sm text-muted">
              {c.email && <a className="link-accent" href={`mailto:${c.email}`}>{c.email}</a>}
              {c.email && c.phone && <span aria-hidden> &nbsp;|&nbsp; </span>}
              {c.phone && <a className="link-accent" href={`tel:${c.phone}`}>{c.phone}</a>}
            </p>
          )}
          {c.hours && <p className="text-sm text-muted">{c.hours}</p>}
          {c.socials.length > 0 && (
            <ul className="flex flex-wrap gap-x-4 gap-y-1 text-sm" aria-label="Social media">
              {c.socials.map((s) => (
                <li key={s.label}>
                  <a className="link-accent" href={s.href} target="_blank" rel="noopener noreferrer">{s.label}</a>
                </li>
              ))}
            </ul>
          )}
        </div>
        {columns.map((col) => (
          <nav key={col.title} aria-label={col.title} className="space-y-2 text-sm">
            <p className="font-semibold">{col.title}</p>
            {col.links.map((l) => (
              <Link key={l.href} className="block text-muted hover:text-fg" href={l.href}>{l.label}</Link>
            ))}
          </nav>
        ))}
      </div>
      <div className="border-t border-line">
        <div className="container-page py-5">
          <p className="font-display text-sm text-accent-text">Learn &middot; Plan &middot; Journal &middot; Review &middot; Improve</p>
          <p className="mt-2 text-xs text-muted">
            Educational content only. Nothing here is financial advice or a recommendation to trade. Trading leveraged products such as forex and gold CFDs carries a high risk of losing money. Past performance and hypothetical examples do not indicate future results.
          </p>
        </div>
      </div>
      <ContactDock email={c.email} whatsapp={c.whatsapp} />
    </footer>
  );
}
