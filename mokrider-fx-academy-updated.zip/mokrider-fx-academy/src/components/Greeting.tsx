"use client";

import { useEffect, useState } from "react";
import { dayPart, firstName } from "@/lib/names";

/**
 * "Good morning, Amina". The time of day comes from the visitor's own device clock, so it is right
 * wherever they are. The first paint says "Welcome" so the server and browser agree, then it updates.
 */
export function Greeting({ name, className }: { name: string; className?: string }) {
  const [hello, setHello] = useState("Welcome");
  useEffect(() => setHello(`Good ${dayPart(new Date().getHours())}`), []);
  return <span className={className}>{hello}, {firstName(name)}</span>;
}
