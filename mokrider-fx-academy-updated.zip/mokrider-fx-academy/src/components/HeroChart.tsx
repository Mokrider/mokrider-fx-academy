// Hand-built teaching illustration. The candles are invented for the diagram. NOT market data.
type Candle = [open: number, high: number, low: number, close: number];

const candles: Candle[] = [
  [60, 62, 57, 58],
  [58, 59, 54, 55],
  [55, 57, 51, 52],
  [52, 54, 50, 53],
  [53, 54, 46, 52.5], // sweeps the equal lows, closes back above them
  [52.5, 64, 52, 63], // displacement
  [63, 66, 60, 65],   // its low sits above the high of the sweep candle, leaving a gap
  [65, 67, 61, 62],
  [62, 63, 57, 59],   // retests the gap
  [59, 66, 58, 65],
];

const X0 = 40, STEP = 50, W = 22, TOP = 24, BOTTOM = 340, PMIN = 44, PMAX = 68;
const y = (p: number) => BOTTOM - ((p - PMIN) / (PMAX - PMIN)) * (BOTTOM - TOP);
const x = (i: number) => X0 + i * STEP;

export function HeroChart() {
  const gapTop = candles[6][2]; // low of candle 7
  const gapBottom = candles[4][1]; // high of candle 5
  return (
    <figure className="w-full">
      <svg
        viewBox="0 0 560 380"
        role="img"
        aria-label="Illustrated candlestick chart showing equal lows being swept, a strong move up that leaves a fair value gap, a retest of the gap, and an invalidation level below the sweep low."
        className="h-auto w-full rounded-md border border-line bg-surface"
      >
        {[0, 1, 2, 3, 4].map((i) => (
          <line key={i} x1="0" x2="560" y1={TOP + i * 79} y2={TOP + i * 79} stroke="var(--border)" strokeWidth="1" />
        ))}

        {/* fair value gap zone */}
        <rect x={x(4) + W / 2} y={y(gapTop)} width={x(9) - x(4)} height={y(gapBottom) - y(gapTop)} fill="var(--amber)" opacity="0.18" />
        <line x1={x(4) + W / 2} x2={x(9) + W} y1={y(gapTop)} y2={y(gapTop)} stroke="var(--amber)" strokeWidth="1" />
        <line x1={x(4) + W / 2} x2={x(9) + W} y1={y(gapBottom)} y2={y(gapBottom)} stroke="var(--amber)" strokeWidth="1" />

        {/* equal lows (liquidity) */}
        <line x1={x(2) - 14} x2={x(5)} y1={y(50.5)} y2={y(50.5)} stroke="var(--amber)" strokeWidth="1.5" strokeDasharray="5 4" />

        {/* invalidation */}
        <line x1="16" x2="544" y1={y(46)} y2={y(46)} stroke="var(--down)" strokeWidth="1.5" strokeDasharray="2 5" />

        {candles.map(([o, h, l, c], i) => {
          const up = c >= o;
          const colour = up ? "var(--up)" : "var(--down)";
          return (
            <g key={i}>
              <line x1={x(i) + W / 2} x2={x(i) + W / 2} y1={y(h)} y2={y(l)} stroke={colour} strokeWidth="2" />
              <rect x={x(i)} y={y(Math.max(o, c))} width={W} height={Math.max(2, Math.abs(y(o) - y(c)))} fill={colour} rx="1" />
            </g>
          );
        })}

        <g fontSize="13" fill="var(--text)" fontFamily="var(--font-grotesk), sans-serif" paintOrder="stroke" stroke="var(--surface)" strokeWidth="4">
          <text x="544" y={y(gapBottom) + 18} textAnchor="end" fill="var(--amber)">Fair value gap</text>
          <text x={x(2) - 14} y={y(50.5) + 30} fill="var(--amber)">Equal lows (liquidity)</text>
          <text x={x(4) - 22} y={y(46) + 18} textAnchor="start" fill="var(--text)">Sweep of the lows</text>
          <text x="544" y={y(46) - 7} textAnchor="end" fill="var(--down)">Idea invalid below here</text>
        </g>
      </svg>
      <figcaption className="mt-2 text-xs text-muted">
        Teaching illustration with invented candles. Not live data and not a trade signal.
      </figcaption>
    </figure>
  );
}
