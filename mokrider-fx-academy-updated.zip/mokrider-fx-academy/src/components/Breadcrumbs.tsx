import Link from "next/link";

export function Breadcrumbs({ trail }: { trail: { label: string; href?: string }[] }) {
  const items = [{ label: "Home", href: "/" }, ...trail];
  return (
    <nav aria-label="Breadcrumb" className="mb-6 text-xs uppercase tracking-widest text-muted">
      <ol className="flex flex-wrap items-center gap-2">
        {items.map((c, i) => (
          <li key={c.label} className="flex items-center gap-2">
            {c.href && i < items.length - 1 ? <Link href={c.href} className="hover:text-fg">{c.label}</Link> : <span aria-current="page" className="text-fg">{c.label}</span>}
            {i < items.length - 1 && <span aria-hidden>&rsaquo;</span>}
          </li>
        ))}
      </ol>
    </nav>
  );
}
