import Link from "next/link";

/** The mark: an "M" built from two candlesticks. The right-hand candle is the red breakout candle. */
export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true" className="shrink-0">
      <line x1="14" y1="8" x2="14" y2="58" stroke="var(--text)" strokeWidth="3" strokeLinecap="round" />
      <rect x="9" y="16" width="10" height="34" rx="2.5" fill="var(--text)" />
      <path d="M19 20 L32 42 L45 16" fill="none" stroke="var(--text)" strokeWidth="6.5" strokeLinejoin="round" strokeLinecap="round" />
      <line x1="50" y1="3" x2="50" y2="54" stroke="var(--accent)" strokeWidth="3" strokeLinecap="round" />
      <rect x="45" y="10" width="10" height="36" rx="2.5" fill="var(--accent)" />
    </svg>
  );
}

export function Logo() {
  return (
    <Link href="/" className="inline-flex items-center gap-3" aria-label="MOKRIDER FX ACADEMY home">
      <LogoMark />
      <span className="flex flex-col leading-none">
        <span className="font-display text-xl font-black tracking-tight text-fg">MOKRIDER <span className="text-accent-text">FX</span></span>
        <span className="mt-1.5 text-[0.6rem] font-bold uppercase tracking-[0.55em] text-muted">Academy</span>
      </span>
    </Link>
  );
}
