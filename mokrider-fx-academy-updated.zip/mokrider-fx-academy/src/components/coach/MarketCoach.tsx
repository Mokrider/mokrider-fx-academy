"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { QUESTIONS, TOPICS, type Level, type Question, type Topic } from "@/content/coach/questions";
import { accuracy, pickNext, shuffleOptions, summarize, topicStats, type Attempt } from "@/lib/coach/engine";
import { CoachAI } from "@/components/coach/CoachAI";

const STORAGE_KEY = "mokrider-coach-v1";
const MAX_HISTORY = 400;

type Current = { q: Question; options: string[]; answerIndex: number };

function loadHistory(): Attempt[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? (parsed as Attempt[]).filter((a) => a && typeof a.id === "string" && typeof a.ok === "boolean") : [];
  } catch {
    return [];
  }
}
function saveHistory(h: Attempt[]) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(h.slice(-MAX_HISTORY)));
  } catch {
    /* private mode or full storage: the quiz still works, it just will not remember */
  }
}

export function MarketCoach({ signedIn, aiEnabled }: { signedIn: boolean; aiEnabled: boolean }) {
  const [tab, setTab] = useState<"quiz" | "ai">("quiz");
  const [history, setHistory] = useState<Attempt[]>([]);
  const [loaded, setLoaded] = useState(false);

  const [topic, setTopic] = useState<Topic | "adaptive">("adaptive");
  const [level, setLevel] = useState<Level | "adaptive">("adaptive");
  const [length, setLength] = useState(10);

  const [phase, setPhase] = useState<"setup" | "asking" | "done">("setup");
  const [current, setCurrent] = useState<Current | null>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const [asked, setAsked] = useState(0);
  const [right, setRight] = useState(0);
  const sessionIds = useRef<string[]>([]);
  const headingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    setHistory(loadHistory());
    setLoaded(true);
  }, []);

  function nextQuestion(h: Attempt[], opts: { topic: Topic | "adaptive"; level: Level | "adaptive" }, count: number, total: number) {
    if (count >= total) return setPhase("done");
    const q = pickNext(QUESTIONS, h, { topic: opts.topic, level: opts.level, skipIds: sessionIds.current });
    if (!q) return setPhase("done");
    sessionIds.current.push(q.id);
    const { options, answerIndex } = shuffleOptions(q);
    setCurrent({ q, options, answerIndex });
    setPicked(null);
    setPhase("asking");
  }

  function start(over?: { topic?: Topic | "adaptive" }) {
    const t = over?.topic ?? topic;
    if (over?.topic) setTopic(over.topic);
    sessionIds.current = [];
    setAsked(0);
    setRight(0);
    nextQuestion(history, { topic: t, level }, 0, length);
    requestAnimationFrame(() => headingRef.current?.focus());
  }

  function choose(i: number) {
    if (!current || picked !== null) return;
    const ok = i === current.answerIndex;
    setPicked(i);
    setAsked((n) => n + 1);
    if (ok) setRight((n) => n + 1);
    const next = [...history, { id: current.q.id, t: current.q.t, ok, at: Date.now() }];
    setHistory(next);
    saveHistory(next);
  }

  function advance() {
    nextQuestion(history, { topic, level }, asked, length);
  }

  function clearResults() {
    if (!window.confirm("Clear all your saved quiz results on this device?")) return;
    setHistory([]);
    saveHistory([]);
  }

  const stats = topicStats(history);
  const overall = summarize(history);
  const tabBtn = (id: "quiz" | "ai", label: string) => (
    <button type="button" role="tab" aria-selected={tab === id} className="chip" aria-pressed={tab === id} onClick={() => setTab(id)}>{label}</button>
  );

  return (
    <div>
      <div role="tablist" aria-label="Coach mode" className="mb-8 flex flex-wrap gap-2">
        {tabBtn("quiz", "Quick quiz")}
        {tabBtn("ai", "Explain it (AI coach)")}
      </div>

      {tab === "ai" ? (
        <CoachAI signedIn={signedIn} aiEnabled={aiEnabled} />
      ) : phase === "setup" ? (
        <div className="space-y-10">
          <div className="space-y-5">
            <p className="max-w-2xl text-muted">Short multiple-choice questions on the ideas every trader needs. You see why each answer is right straight away. It chooses questions you have not seen or got wrong, and gets harder as you improve.</p>
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <label htmlFor="q-topic" className="mb-1 block text-sm font-medium">Topic</label>
                <select id="q-topic" className="field" value={topic} onChange={(e) => setTopic(e.target.value as Topic | "adaptive")}>
                  <option value="adaptive">Mixed, focus on my weak spots</option>
                  {TOPICS.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="q-level" className="mb-1 block text-sm font-medium">Difficulty</label>
                <select id="q-level" className="field" value={String(level)} onChange={(e) => setLevel(e.target.value === "adaptive" ? "adaptive" : (Number(e.target.value) as Level))}>
                  <option value="adaptive">Adapts to me</option>
                  <option value="1">Beginner</option><option value="2">Intermediate</option><option value="3">Advanced</option>
                </select>
              </div>
              <div>
                <label htmlFor="q-length" className="mb-1 block text-sm font-medium">Questions</label>
                <select id="q-length" className="field" value={length} onChange={(e) => setLength(Number(e.target.value))}>
                  <option value={5}>5</option><option value={10}>10</option><option value={20}>20</option>
                </select>
              </div>
            </div>
            <button type="button" className="btn btn-primary" onClick={() => start()}>Start the quiz</button>
          </div>

          {loaded && overall.total > 0 && (
            <section aria-labelledby="progress-h">
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                <h2 id="progress-h" className="text-2xl">Your progress</h2>
                <button type="button" className="text-sm text-muted underline" onClick={clearResults}>Clear my results</button>
              </div>
              <p className="mt-2 text-sm text-muted">{overall.correct} correct out of {overall.total} answered ({overall.percent}%). Saved on this device only.</p>
              <ul className="mt-5 grid gap-x-8 gap-y-4 sm:grid-cols-2">
                {TOPICS.filter((t) => stats[t.id]).map((t) => {
                  const pct = Math.round(accuracy(stats[t.id]) * 100);
                  return (
                    <li key={t.id}>
                      <div className="flex justify-between text-sm"><span>{t.label}</span><span className="text-muted">{stats[t.id]!.correct}/{stats[t.id]!.asked}</span></div>
                      <div className="mt-1 h-2 rounded bg-surface ring-1 ring-inset ring-[var(--border)]" role="img" aria-label={`${t.label}: ${pct}% accuracy`}>
                        <div className="h-full rounded" style={{ width: `${pct}%`, background: "var(--accent)" }} />
                      </div>
                    </li>
                  );
                })}
              </ul>
            </section>
          )}
        </div>
      ) : phase === "asking" && current ? (
        <div className="max-w-3xl space-y-6">
          <div className="flex items-center justify-between text-sm text-muted">
            <span>Question {Math.min(asked + (picked === null ? 1 : 0), length)} of {length}</span>
            <span>{TOPICS.find((t) => t.id === current.q.t)?.label}</span>
          </div>
          <h2 ref={headingRef} tabIndex={-1} className="text-2xl outline-none md:text-3xl">{current.q.q}</h2>
          <ul className="space-y-3">
            {current.options.map((opt, i) => {
              const state = picked === null ? "" : i === current.answerIndex ? "border-up" : i === picked ? "border-down" : "opacity-60";
              return (
                <li key={opt}>
                  <button
                    type="button"
                    disabled={picked !== null}
                    onClick={() => choose(i)}
                    className={`w-full rounded-md border bg-card p-4 text-left transition hover:border-accent disabled:cursor-default ${state || "border-line"}`}
                  >
                    <span className="mr-3 font-bold text-accent-text">{String.fromCharCode(65 + i)}</span>{opt}
                    {picked !== null && i === current.answerIndex && <span className="ml-2 text-sm font-semibold text-up">Correct</span>}
                    {picked === i && i !== current.answerIndex && <span className="ml-2 text-sm font-semibold text-down">Your answer</span>}
                  </button>
                </li>
              );
            })}
          </ul>
          {picked !== null && (
            <div role="status" className="bg-card space-y-4 border border-line p-5">
              <p className={`font-display text-xl ${picked === current.answerIndex ? "text-up" : "text-down"}`}>{picked === current.answerIndex ? "Correct" : "Not quite"}</p>
              <p>{current.q.why}</p>
              <button type="button" className="btn btn-primary" onClick={advance}>{asked >= length ? "See my result" : "Next question"}</button>
            </div>
          )}
        </div>
      ) : (
        <div className="max-w-3xl space-y-8">
          <div>
            <h2 className="text-3xl">{right} out of {asked}</h2>
            <p className="mt-2 text-muted">
              {asked > 0 && right / asked >= 0.8 ? "Strong. You understand these ideas well." : asked > 0 && right / asked >= 0.5 ? "A solid start. Review the explanations you missed and try again." : "That is what practice is for. Read the explanations, revisit the lesson and try again."}
            </p>
          </div>
          {overall.weakest.length > 0 && (
            <section>
              <h3 className="text-xl">Worth practising</h3>
              <ul className="mt-3 space-y-3">
                {overall.weakest.map((id) => {
                  const t = TOPICS.find((x) => x.id === id)!;
                  return (
                    <li key={id} className="bg-card flex flex-wrap items-center justify-between gap-3 border border-line p-4">
                      <div><p className="font-semibold">{t.label}</p><p className="text-sm text-muted">{t.blurb}</p></div>
                      <div className="flex gap-2">
                        <button type="button" className="btn btn-primary" onClick={() => { setPhase("setup"); start({ topic: id }); }}>Practise</button>
                        <Link href={t.href} className="btn btn-ghost">Learn</Link>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </section>
          )}
          <div className="flex flex-wrap gap-3">
            <button type="button" className="btn btn-primary" onClick={() => start()}>Another round</button>
            <button type="button" className="btn btn-ghost" onClick={() => setPhase("setup")}>Change settings</button>
            {aiEnabled && <button type="button" className="btn btn-ghost" onClick={() => setTab("ai")}>Explain it to the AI coach</button>}
          </div>
        </div>
      )}
    </div>
  );
}
