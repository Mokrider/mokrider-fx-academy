"use client";

import { useState } from "react";
import Link from "next/link";
import { TOPICS, type Level, type Topic } from "@/content/coach/questions";

type Grade = { verdict: "clear" | "partly" | "not_yet"; feedback: string; missing: string[]; followUp?: string };

const VERDICT: Record<Grade["verdict"], { label: string; tone: string }> = {
  clear: { label: "Clear understanding", tone: "text-up" },
  partly: { label: "Partly there", tone: "text-accent-text" },
  not_yet: { label: "Not yet. Here is what to review", tone: "text-down" },
};

async function call(body: unknown): Promise<{ ok: true; data: unknown } | { ok: false; error: string }> {
  try {
    const res = await fetch("/api/coach", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { ok: false, error: (data as { error?: string }).error ?? "Something went wrong. Please try again." };
    return { ok: true, data };
  } catch {
    return { ok: false, error: "Could not reach the coach. Check your connection and try again." };
  }
}

/** The AI side: it asks an open question, the student explains in their own words, and the coach marks it. */
export function CoachAI({ signedIn, aiEnabled }: { signedIn: boolean; aiEnabled: boolean }) {
  const [topic, setTopic] = useState<Topic>("risk");
  const [level, setLevel] = useState<Level>(1);
  const [question, setQuestion] = useState<{ text: string; hint?: string } | null>(null);
  const [answer, setAnswer] = useState("");
  const [grade, setGrade] = useState<Grade | null>(null);
  const [busy, setBusy] = useState<"ask" | "grade" | null>(null);
  const [error, setError] = useState("");
  const [asked, setAsked] = useState<string[]>([]);

  if (!aiEnabled) {
    return (
      <div className="rounded-md border border-dashed border-line p-6">
        <p className="font-medium">The AI coach is not switched on yet.</p>
        <p className="mt-2 text-sm text-muted">Once the academy adds its AI key, this tab will ask you open questions and mark your explanations. Until then, the quiz tab works fully.</p>
      </div>
    );
  }
  if (!signedIn) {
    return (
      <div className="rounded-md border border-line bg-card p-6">
        <p className="font-medium">Sign in to talk to the AI coach.</p>
        <p className="mt-2 text-sm text-muted">It is free for students. Signing in keeps the coach from being overused.</p>
        <div className="mt-4 flex gap-3">
          <Link href="/login?next=/coach" className="btn btn-primary">Sign in</Link>
          <Link href="/register" className="btn btn-ghost">Create account</Link>
        </div>
      </div>
    );
  }

  async function ask() {
    setBusy("ask"); setError(""); setGrade(null); setAnswer("");
    const r = await call({ mode: "ask", topic, level, avoid: asked.slice(-5) });
    setBusy(null);
    if (!r.ok) return setError(r.error);
    const d = r.data as { question: string; hint?: string };
    setQuestion({ text: d.question, hint: d.hint });
    setAsked((a) => [...a, d.question]);
  }

  async function check() {
    if (!question) return;
    setBusy("grade"); setError("");
    const r = await call({ mode: "grade", topic, level, question: question.text, answer });
    setBusy(null);
    if (!r.ok) return setError(r.error);
    setGrade(r.data as Grade);
  }

  function takeFollowUp() {
    if (!grade?.followUp) return;
    setQuestion({ text: grade.followUp });
    setAsked((a) => [...a, grade.followUp as string]);
    setGrade(null);
    setAnswer("");
  }

  return (
    <div className="space-y-6">
      {!question ? (
        <div className="space-y-5">
          <p className="max-w-2xl text-muted">The coach asks you one open question. Explain it in your own words, 2 to 5 sentences, and it will tell you what you understand and what to fix. It never gives signals or predictions.</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="ai-topic" className="mb-1 block text-sm font-medium">Topic</label>
              <select id="ai-topic" className="field" value={topic} onChange={(e) => setTopic(e.target.value as Topic)}>
                {TOPICS.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="ai-level" className="mb-1 block text-sm font-medium">Level</label>
              <select id="ai-level" className="field" value={level} onChange={(e) => setLevel(Number(e.target.value) as Level)}>
                <option value={1}>Beginner</option><option value={2}>Intermediate</option><option value={3}>Advanced</option>
              </select>
            </div>
          </div>
          <button type="button" className="btn btn-primary" onClick={ask} disabled={busy !== null}>{busy === "ask" ? "Thinking of a question..." : "Ask me a question"}</button>
        </div>
      ) : (
        <div className="space-y-5">
          <div className="bg-card border border-line p-5">
            <p className="text-xs font-semibold uppercase tracking-widest text-accent-text">{TOPICS.find((t) => t.id === topic)?.label}</p>
            <p className="mt-2 text-xl">{question.text}</p>
            {question.hint && <p className="mt-2 text-sm text-muted">Hint: {question.hint}</p>}
          </div>

          {!grade && (
            <div className="space-y-3">
              <label htmlFor="ai-answer" className="block text-sm font-medium">Your answer, in your own words</label>
              <textarea id="ai-answer" className="field" rows={6} maxLength={1200} value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="Explain it as if teaching a friend." />
              <p className="text-xs text-muted">{answer.length}/1200. Please do not include passwords or personal details.</p>
              <div className="flex flex-wrap gap-3">
                <button type="button" className="btn btn-primary" onClick={check} disabled={busy !== null || answer.trim().length < 10}>{busy === "grade" ? "Marking..." : "Check my answer"}</button>
                <button type="button" className="btn btn-ghost" onClick={ask} disabled={busy !== null}>Different question</button>
              </div>
            </div>
          )}

          {grade && (
            <div className="bg-card space-y-4 border border-line p-5" role="status">
              <p className={`font-display text-xl ${VERDICT[grade.verdict].tone}`}>{VERDICT[grade.verdict].label}</p>
              <p>{grade.feedback}</p>
              {grade.missing.length > 0 && (
                <div>
                  <p className="text-sm font-semibold">To add or fix</p>
                  <ul className="mt-1 list-disc pl-5 text-sm text-muted">{grade.missing.map((m) => <li key={m}>{m}</li>)}</ul>
                </div>
              )}
              <div className="flex flex-wrap gap-3 pt-2">
                {grade.followUp && <button type="button" className="btn btn-primary" onClick={takeFollowUp}>Next: go a little deeper</button>}
                <button type="button" className="btn btn-ghost" onClick={ask} disabled={busy !== null}>{busy === "ask" ? "Thinking..." : "New question"}</button>
                <button type="button" className="btn btn-ghost" onClick={() => { setQuestion(null); setGrade(null); setAnswer(""); }}>Change topic</button>
              </div>
            </div>
          )}
        </div>
      )}
      {error && <p role="alert" className="text-sm text-down">{error}</p>}
      <p className="text-xs text-muted">The AI can make mistakes. Treat its marking as a study aid, and check anything important in the courses. It is not financial advice.</p>
    </div>
  );
}
