// Plain server-compatible form controls (no client state).
type Base = { label: string; name: string; id?: string; hint?: string; required?: boolean };

export function Field({ label, name, id, hint, required, defaultValue, type = "text", placeholder }: Base & { defaultValue?: string | number | null; type?: string; placeholder?: string }) {
  return (
    <div>
      <label htmlFor={id ?? name} className="mb-1 block text-sm font-medium">{label}</label>
      <input id={id ?? name} name={name} type={type} required={required} defaultValue={defaultValue ?? ""} placeholder={placeholder} className="field" />
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  );
}

export function TextArea({ label, name, id, hint, required, defaultValue, rows = 8 }: Base & { defaultValue?: string | null; rows?: number }) {
  return (
    <div>
      <label htmlFor={id ?? name} className="mb-1 block text-sm font-medium">{label}</label>
      <textarea id={id ?? name} name={name} rows={rows} required={required} defaultValue={defaultValue ?? ""} className="field font-mono text-sm" />
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  );
}

export function SelectField({ label, name, id, hint, defaultValue, options }: Base & { defaultValue?: string; options: [string, string][] }) {
  return (
    <div>
      <label htmlFor={id ?? name} className="mb-1 block text-sm font-medium">{label}</label>
      <select id={id ?? name} name={name} defaultValue={defaultValue} className="field">
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  );
}

export function Check({ label, name, defaultChecked }: { label: string; name: string; defaultChecked?: boolean }) {
  return (
    <label className="flex items-center gap-2 text-sm">
      <input type="checkbox" name={name} defaultChecked={defaultChecked} /> {label}
    </label>
  );
}

export const STATUS_OPTIONS: [string, string][] = [
  ["DRAFT", "Draft (not public)"],
  ["SCHEDULED", "Scheduled (goes live at the publish time)"],
  ["PUBLISHED", "Published"],
  ["ARCHIVED", "Archived (hidden)"],
];
