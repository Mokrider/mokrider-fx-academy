import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export function ComingSoon({ title, description, phase }: { title: string; description: string; phase: string }) {
  return (
    <>
      <SiteHeader />
      <main className="container-page py-20">
        <h1 className="text-4xl md:text-5xl">{title}</h1>
        <p className="mt-4 max-w-xl text-muted">{description}</p>
        <p className="mt-6 max-w-xl rounded-md border border-line bg-surface p-4 text-sm">
          This section is not built yet. It is planned for {phase}.
        </p>
        <Link href="/" className="btn btn-ghost mt-8">Back to home</Link>
      </main>
      <SiteFooter />
    </>
  );
}
