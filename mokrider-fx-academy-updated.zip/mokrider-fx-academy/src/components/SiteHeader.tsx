import Link from "next/link";
import { Logo } from "@/components/Logo";
import { MobileMenu } from "@/components/MobileMenu";
import { firstName } from "@/lib/names";
import { ThemeToggle } from "@/components/ThemeToggle";
import { getCurrentUser } from "@/lib/session";
import { hasRoleAtLeast } from "@/lib/permissions";
import { readCart } from "@/lib/commerce/cartStore";

export const navLinks = [
  { href: "/learn", label: "Learn" },
  { href: "/market-analysis", label: "Market analysis" },
  { href: "/shop", label: "Shop" },
  { href: "/mentorship", label: "Mentorship" },
  { href: "/tools", label: "Tools" },
  { href: "/blog", label: "Blog" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

// Shown in the mobile menu only: the desktop bar is already full.
const extraMobileLinks = [{ href: "/coach", label: "Market Coach" }, { href: "/tools/session-clock", label: "Session timer" }, { href: "/sponsor", label: "Sponsor a student" }, { href: "/stories", label: "Student stories" }];

export async function SiteHeader() {
  const user = await getCurrentUser();
  const cartCount = (await readCart()).length;
  const accountHref = user && hasRoleAtLeast(user.role, "ADMIN") ? "/admin" : "/dashboard";

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-bg/95 backdrop-blur-sm">
      <div className="glow-line" aria-hidden />
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <Logo />
        <nav aria-label="Main" className="hidden items-center gap-6 text-xs font-semibold uppercase tracking-widest lg:flex">
          {navLinks.map((l) => (
            <Link key={l.href} href={l.href} className="text-muted hover:text-fg">{l.label}</Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link href="/cart" className="btn btn-ghost !px-3" aria-label={`Cart, ${cartCount} item${cartCount === 1 ? "" : "s"}`}>Cart{cartCount > 0 ? ` (${cartCount})` : ""}</Link>
          <ThemeToggle />
          {user ? (
            <>
              <span className="hidden max-w-32 truncate text-sm text-muted xl:inline" title={user.name}>Hi, <strong className="text-fg">{firstName(user.name)}</strong></span>
              <Link href={accountHref} className="btn btn-primary hidden sm:inline-flex">{accountHref === "/admin" ? "Admin" : "Dashboard"}</Link>
            </>
          ) : (
            <>
              <Link href="/login" className="btn btn-ghost hidden sm:inline-flex">Sign in</Link>
              <Link href="/register" className="btn btn-primary hidden sm:inline-flex">Create account</Link>
            </>
          )}
          <MobileMenu
            links={[...navLinks, ...extraMobileLinks]}
            accountLink={user ? { href: accountHref, label: `${accountHref === "/admin" ? "Admin" : "Dashboard"} (${firstName(user.name)})` } : null}
            guest={!user}
          />
        </div>
      </div>
    </header>
  );
}
