"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { audit } from "@/lib/audit";
import type { FormState } from "@/components/ActionForm";

export async function saveIntake(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/applications");
  const note = z.string().max(200, "Keep the note under 200 characters.").safeParse(String(fd.get("note") ?? "").trim());
  if (!note.success) return { error: note.error.issues[0].message };
  const value = { open: fd.get("open") === "on", note: note.data };
  await prisma.siteSetting.upsert({ where: { key: "intake" }, create: { key: "intake", value }, update: { value } });
  await audit(admin.id, "intake.update", "SiteSetting", "intake", { open: value.open });
  revalidatePath("/mentorship/apply");
  return { ok: "Saved." };
}

export async function updateApplication(id: string, _prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/applications");
  const parsed = z.object({ status: z.enum(["NEW", "CONTACTED", "ACCEPTED", "DECLINED"]), note: z.string().max(1000) }).safeParse({ status: fd.get("status"), note: String(fd.get("note") ?? "").trim() });
  if (!parsed.success) return { error: "Choose a status and keep the note under 1000 characters." };
  await prisma.mentorshipApplication.update({ where: { id }, data: { status: parsed.data.status, adminNote: parsed.data.note || null } });
  await audit(admin.id, "application.update", "MentorshipApplication", id, { status: parsed.data.status });
  revalidatePath("/admin/applications");
  return { ok: "Saved." };
}

export async function deleteApplication(id: string) {
  const admin = await requireRole("ADMIN", "/admin/applications");
  await prisma.mentorshipApplication.deleteMany({ where: { id } });
  await audit(admin.id, "application.delete", "MentorshipApplication", id);
  revalidatePath("/admin/applications");
}
