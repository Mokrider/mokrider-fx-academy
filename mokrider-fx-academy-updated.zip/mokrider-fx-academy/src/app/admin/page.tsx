import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { formatMoney, sumByCurrency } from "@/lib/money";

export default async function AdminOverview() {
  await requireRole("ADMIN", "/admin");

  const [users, publishedCourses, paid, refunded, confirmedBookings, activeSubs, recentOrders, recentUsers, recentEvents] = await Promise.all([
    prisma.user.count(),
    prisma.course.count({ where: { status: "PUBLISHED" } }),
    prisma.order.groupBy({ by: ["currency"], where: { status: "PAID" }, _sum: { totalMinor: true }, _count: true }),
    prisma.refund.groupBy({ by: ["currency"], where: { status: "PROCESSED" }, _sum: { amountMinor: true } }),
    prisma.booking.count({ where: { status: "CONFIRMED" } }),
    prisma.subscription.count({ where: { status: "ACTIVE" } }),
    prisma.order.findMany({ orderBy: { createdAt: "desc" }, take: 8, select: { id: true, reference: true, status: true, totalMinor: true, currency: true, createdAt: true } }),
    prisma.user.findMany({ orderBy: { createdAt: "desc" }, take: 8, select: { id: true, name: true, email: true, createdAt: true } }),
    prisma.paymentEvent.findMany({ orderBy: { receivedAt: "desc" }, take: 8, select: { id: true, provider: true, eventKey: true, receivedAt: true } }),
  ]);

  const gross = sumByCurrency(paid.map((p) => ({ currency: p.currency, amountMinor: p._sum.totalMinor ?? 0 })));
  const refunds = sumByCurrency(refunded.map((r) => ({ currency: r.currency, amountMinor: r._sum.amountMinor ?? 0 })));
  const paidCount = paid.reduce((n, p) => n + p._count, 0);
  const fmt = new Intl.DateTimeFormat("en-KE", { dateStyle: "medium", timeStyle: "short", timeZone: "Africa/Nairobi" });
  const money = (t: Record<string, number>) => (Object.keys(t).length ? Object.entries(t).map(([c, m]) => formatMoney(m, c)).join(" / ") : "None yet");

  const metrics: [string, string, string][] = [
    ["Registered users", String(users), "All accounts, all time"],
    ["Published courses", String(publishedCourses), "Courses with status Published"],
    ["Paid orders", String(paidCount), "Orders with a verified payment. Pending and failed are excluded"],
    ["Gross recorded sales", money(gross), "Sum of Paid orders, per currency, all time"],
    ["Refunds processed", money(refunds), "Only refunds the provider confirmed"],
    ["Confirmed bookings", String(confirmedBookings), "Bookings with status Confirmed"],
    ["Active subscriptions", String(activeSubs), "Subscriptions with status Active"],
  ];

  return (
    <div className="space-y-12">
      <h1 className="text-4xl">Overview</h1>
      <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {metrics.map(([label, value, note]) => (
          <div key={label} className="rounded-md border border-line bg-card p-5">
            <dt className="text-sm text-muted">{label}</dt>
            <dd className="mt-1 font-display text-3xl">{value}</dd>
            <p className="mt-2 text-xs text-muted">{note}</p>
          </div>
        ))}
      </dl>

      <div className="grid gap-10 lg:grid-cols-3">
        <section>
          <h2 className="mb-3 text-xl">Recent orders</h2>
          {recentOrders.length === 0 ? <p className="text-sm text-muted">No orders yet.</p> : (
            <ul className="space-y-2 text-sm">{recentOrders.map((o) => (
              <li key={o.id} className="border-b border-line pb-2"><span className="font-medium">{o.reference}</span> &middot; {o.status}<br /><span className="text-muted">{formatMoney(o.totalMinor, o.currency)} &middot; {fmt.format(o.createdAt)}</span></li>
            ))}</ul>
          )}
        </section>
        <section>
          <h2 className="mb-3 text-xl">Recent registrations</h2>
          <ul className="space-y-2 text-sm">{recentUsers.map((u) => (
            <li key={u.id} className="border-b border-line pb-2"><span className="font-medium">{u.name}</span><br /><span className="text-muted">{u.email} &middot; {fmt.format(u.createdAt)}</span></li>
          ))}</ul>
        </section>
        <section>
          <h2 className="mb-3 text-xl">Recent payment events</h2>
          {recentEvents.length === 0 ? <p className="text-sm text-muted">No payment events yet.</p> : (
            <ul className="space-y-2 text-sm">{recentEvents.map((e) => (
              <li key={e.id} className="border-b border-line pb-2"><span className="font-medium">{e.provider}</span><br /><span className="text-muted">{fmt.format(e.receivedAt)}</span></li>
            ))}</ul>
          )}
        </section>
      </div>
    </div>
  );
}
