import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Check, TextArea } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { formatEat } from "@/lib/time";
import { getIntake } from "@/lib/intake";
import { BOTTLENECKS, EXPERIENCE, FOCUS, labelFor } from "@/content/application";
import { deleteApplication, saveIntake, updateApplication } from "@/app/admin/application-actions";

const STATUSES = ["NEW", "CONTACTED", "ACCEPTED", "DECLINED"] as const;

export default async function ApplicationsAdmin({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  await requireRole("ADMIN", "/admin/applications");
  const { status } = await searchParams;
  const active = STATUSES.find((s) => s === status);
  const [intake, apps] = await Promise.all([
    getIntake(),
    prisma.mentorshipApplication.findMany({ where: active ? { status: active } : {}, orderBy: { createdAt: "desc" }, take: 200 }),
  ]);

  return (
    <>
      <AdminHeader title="Mentorship applications" />
      <section aria-label="Intake" className="mb-12 max-w-xl">
        <h2 className="mb-2 text-xl">Accepting applications?</h2>
        <ActionForm action={saveIntake} submitLabel="Save">
          <Check label="Applications are open" name="open" defaultChecked={intake.open} />
          <TextArea label="Optional note shown on the public page" name="note" rows={2} defaultValue={intake.note} hint="For example: I am taking a small number of clients at a time. Only write what is true." />
        </ActionForm>
      </section>

      <nav aria-label="Status filter" className="mb-6 flex flex-wrap gap-2 text-sm">
        <Link href="/admin/applications" className={`btn ${!active ? "btn-primary" : "btn-ghost"}`}>All</Link>
        {STATUSES.map((s) => <Link key={s} href={`/admin/applications?status=${s}`} className={`btn ${active === s ? "btn-primary" : "btn-ghost"}`}>{s.toLowerCase()}</Link>)}
      </nav>

      {apps.length === 0 ? <p className="text-muted">No applications.</p> : (
        <ul className="space-y-6">
          {apps.map((a) => {
            const wa = a.phone ? a.phone.replace(/^\+/, "").replace(/^0/, "254") : null;
            return (
              <li key={a.id} className="bg-card border border-line p-5">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <p className="text-lg font-semibold">{a.name} <span className="ml-2 rounded border border-line px-2 py-0.5 text-xs font-normal text-muted">{a.status.toLowerCase()}</span></p>
                  <p className="text-xs text-muted">{formatEat(a.createdAt)}</p>
                </div>
                <p className="mt-1 text-sm"><a className="link-accent" href={`mailto:${a.email}`}>{a.email}</a>{a.phone && <> &middot; <a className="link-accent" href={`tel:${a.phone}`}>{a.phone}</a>{wa && <> &middot; <a className="link-accent" href={`https://wa.me/${wa}`} rel="noopener noreferrer">WhatsApp</a></>}</>}{a.userId && <span className="text-muted"> &middot; has an account</span>}</p>
                <dl className="mt-3 grid gap-1 text-sm sm:grid-cols-[10rem_1fr]">
                  <dt className="text-muted">Experience</dt><dd>{labelFor(EXPERIENCE, a.experience)}</dd>
                  <dt className="text-muted">Biggest challenge</dt><dd>{labelFor(BOTTLENECKS, a.bottleneck)}</dd>
                  <dt className="text-muted">Working towards</dt><dd>{labelFor(FOCUS, a.focus)}</dd>
                  {a.goals && <><dt className="text-muted">Message</dt><dd className="whitespace-pre-wrap">{a.goals}</dd></>}
                </dl>
                <div className="mt-4 max-w-xl">
                  <ActionForm action={updateApplication.bind(null, a.id)} submitLabel="Save status">
                    <div>
                      <label htmlFor={`st-${a.id}`} className="mb-1 block text-sm font-medium">Status</label>
                      <select id={`st-${a.id}`} name="status" defaultValue={a.status} className="field">{STATUSES.map((s) => <option key={s} value={s}>{s.toLowerCase()}</option>)}</select>
                    </div>
                    <TextArea label="Private note" name="note" id={`nt-${a.id}`} rows={2} defaultValue={a.adminNote} />
                  </ActionForm>
                  <form action={deleteApplication.bind(null, a.id)} className="mt-2"><button type="submit" className="text-sm text-down underline">Delete this application</button></form>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
