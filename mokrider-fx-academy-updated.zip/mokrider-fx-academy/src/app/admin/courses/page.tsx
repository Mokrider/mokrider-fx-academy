import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { AdminHeader } from "@/components/AdminHeader";
import { formatMoney } from "@/lib/money";

export default async function CoursesAdmin({ searchParams }: { searchParams: Promise<{ saved?: string }> }) {
  await requireRole("ADMIN", "/admin/courses");
  const { saved } = await searchParams;
  const items = await prisma.course.findMany({ orderBy: { createdAt: "asc" }, include: { _count: { select: { enrollments: true } } } });
  return (
    <>
      <AdminHeader title="Courses" newHref="/admin/courses/new" saved={saved === "1"} />
      <p className="mb-6 max-w-2xl text-sm text-muted">Courses start as drafts with outline-only lessons. Lesson content editing arrives in the next phase; publish a course only when you are ready for people to see its outline.</p>
      <ul className="divide-y divide-line border-y border-line">
        {items.map((c) => (
          <li key={c.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
            <div>
              <p className="font-medium">{c.title}</p>
              <p className="text-sm text-muted">{c.status} · {c.isFree ? "Free" : formatMoney(c.priceMinor, c.currency)} · {c._count.enrollments} enrolled{c.outlineOnly ? " · outline only" : ""}</p>
            </div>
            <Link className="link-accent text-sm" href={`/admin/courses/${c.id}`}>Edit</Link>
          </li>
        ))}
      </ul>
    </>
  );
}
