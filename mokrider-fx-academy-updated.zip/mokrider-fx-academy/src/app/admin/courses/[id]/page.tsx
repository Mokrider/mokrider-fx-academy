import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Check, Field, SelectField, TextArea } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { saveCourse } from "@/app/admin/actions";

export default async function EditCourse({ params }: { params: Promise<{ id: string }> }) {
  await requireRole("ADMIN", "/admin/courses");
  const { id } = await params;
  const c = id === "new" ? null : await prisma.course.findUnique({ where: { id } });
  if (id !== "new" && !c) notFound();
  const price = c ? (c.priceMinor / 100).toFixed(2) : "";
  return (
    <div className="max-w-3xl">
      <AdminHeader title={c ? "Edit course" : "New course"} />
      {c && <p className="-mt-4 mb-6"><Link href={`/admin/courses/${c.id}/lessons`} className="btn btn-ghost">Edit modules and lessons</Link></p>}
      <ActionForm action={saveCourse}>
        <input type="hidden" name="id" value={c?.id ?? ""} />
        <Field label="Title" name="title" required defaultValue={c?.title} />
        <Field label="URL slug" name="slug" defaultValue={c?.slug} hint="Leave blank to create it from the title." />
        <TextArea label="Summary" name="summary" rows={3} required defaultValue={c?.summary} />
        <TextArea label="Full description" name="description" rows={8} defaultValue={c?.description} hint="Markdown." />
        <SelectField label="Level" name="level" defaultValue={c?.level ?? "BEGINNER"} options={[["BEGINNER", "Beginner"], ["INTERMEDIATE", "Intermediate"], ["ADVANCED", "Advanced"]]} />
        <Check label="Free course" name="isFree" defaultChecked={c?.isFree} />
        <Field label="Price (KES), ignored for free courses" name="price" defaultValue={price} />
        <Check label="Outline only (lesson content not written yet)" name="outlineOnly" defaultChecked={c?.outlineOnly ?? true} />
        <Check label="Offer a certificate of completion" name="certificateEnabled" defaultChecked={c?.certificateEnabled} />
        <SelectField label="Status" name="status" defaultValue={c?.status ?? "DRAFT"} options={[["DRAFT", "Draft (not public)"], ["PUBLISHED", "Published"], ["ARCHIVED", "Archived (hidden)"]]} />
      </ActionForm>
    </div>
  );
}
