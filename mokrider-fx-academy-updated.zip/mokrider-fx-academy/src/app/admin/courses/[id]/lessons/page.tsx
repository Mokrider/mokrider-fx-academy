import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Field, SelectField } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { addLesson, addModule, deleteModule, moveLesson, moveModule } from "@/app/admin/lesson-actions";

const KINDS: [string, string][] = [["TEXT", "Text"], ["VIDEO", "Video"], ["PDF", "PDF"], ["QUIZ", "Quiz (not available to students yet)"], ["ASSIGNMENT", "Assignment"]];

export default async function CourseLessons({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ saved?: string }> }) {
  await requireRole("ADMIN", "/admin/courses");
  const { id } = await params;
  const { saved } = await searchParams;
  const course = await prisma.course.findUnique({
    where: { id },
    include: { modules: { orderBy: { position: "asc" }, include: { lessons: { orderBy: { position: "asc" }, select: { id: true, title: true, kind: true, isFreePreview: true, content: true, videoUrl: true } } } } },
  });
  if (!course) notFound();

  return (
    <div className="max-w-3xl">
      <Link href={`/admin/courses/${course.id}`} className="link-accent text-sm">Back to course settings</Link>
      <div className="mt-3"><AdminHeader title={`Lessons: ${course.title}`} saved={saved === "1"} /></div>
      <p className="mb-8 text-sm text-muted">Open a lesson to write its content. When the lessons are ready, untick &quot;Outline only&quot; in the course settings so students are not told it is an outline.</p>

      <div className="space-y-10">
        {course.modules.map((m, mi) => (
          <section key={m.id} aria-label={m.title}>
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-2">
              <h2 className="text-2xl">{m.title}</h2>
              <div className="flex gap-2 text-sm">
                <form action={moveModule.bind(null, m.id, "up")}><button className="btn btn-ghost !min-h-8 !px-2" disabled={mi === 0} aria-label={`Move module ${m.title} up`}>Up</button></form>
                <form action={moveModule.bind(null, m.id, "down")}><button className="btn btn-ghost !min-h-8 !px-2" disabled={mi === course.modules.length - 1} aria-label={`Move module ${m.title} down`}>Down</button></form>
                {m.lessons.length === 0 && <form action={deleteModule.bind(null, m.id)}><button className="btn btn-ghost !min-h-8 !px-2 !text-down">Delete</button></form>}
              </div>
            </div>
            <ul className="divide-y divide-line">
              {m.lessons.map((l, li) => {
                const written = Boolean(l.content && !l.content.startsWith("Outline only")) || Boolean(l.videoUrl);
                return (
                  <li key={l.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                    <div>
                      <Link href={`/admin/lessons/${l.id}`} className="font-medium hover:text-accent-text">{l.title}</Link>
                      <p className="text-xs text-muted">{l.kind}{l.isFreePreview ? " · free preview" : ""} · {written ? "content written" : "outline only"}</p>
                    </div>
                    <div className="flex gap-2 text-sm">
                      <form action={moveLesson.bind(null, l.id, "up")}><button className="btn btn-ghost !min-h-8 !px-2" disabled={li === 0} aria-label={`Move ${l.title} up`}>Up</button></form>
                      <form action={moveLesson.bind(null, l.id, "down")}><button className="btn btn-ghost !min-h-8 !px-2" disabled={li === m.lessons.length - 1} aria-label={`Move ${l.title} down`}>Down</button></form>
                      <Link href={`/admin/lessons/${l.id}`} className="btn btn-ghost !min-h-8 !px-3">Edit</Link>
                    </div>
                  </li>
                );
              })}
            </ul>
            <details className="mt-3">
              <summary className="cursor-pointer text-sm text-accent-text">Add a lesson to this module</summary>
              <div className="mt-3">
                <ActionForm action={addLesson} submitLabel="Add lesson">
                  <input type="hidden" name="moduleId" value={m.id} />
                  <Field label="Lesson title" name="title" id={`title-${m.id}`} required />
                  <SelectField label="Type" name="kind" id={`kind-${m.id}`} defaultValue="TEXT" options={KINDS} />
                </ActionForm>
              </div>
            </details>
          </section>
        ))}
      </div>

      <section className="mt-12 border-t border-line pt-6">
        <h2 className="mb-3 text-xl">Add a module</h2>
        <ActionForm action={addModule} submitLabel="Add module">
          <input type="hidden" name="courseId" value={course.id} />
          <Field label="Module title" name="title" required />
        </ActionForm>
      </section>
    </div>
  );
}
