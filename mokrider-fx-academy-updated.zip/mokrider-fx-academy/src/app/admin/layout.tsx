import type { Metadata } from "next";
import Link from "next/link";
import { Logo } from "@/components/Logo";
import { SignOutButton } from "@/components/SignOutButton";
import { requireRole } from "@/lib/session";

export const metadata: Metadata = { title: "Admin", robots: { index: false, follow: false } };

const links = [
  ["/admin", "Overview"],
  ["/admin/courses", "Courses"],
  ["/admin/articles", "Articles"],
  ["/admin/analyses", "Market analysis"],
  ["/admin/products", "Products"],
  ["/admin/orders", "Orders"],
  ["/admin/access", "Grant access"],
  ["/admin/mentorship", "Mentorship"],
  ["/admin/bookings", "Bookings"],
  ["/admin/applications", "Applications"],
  ["/admin/about", "About page"],
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await requireRole("ADMIN", "/admin");
  return (
    <div className="min-h-screen">
      <header className="border-b border-line bg-surface">
        <div className="container-page flex h-16 items-center justify-between">
          <div className="flex items-center gap-4">
            <Logo />
            <span className="rounded border border-accent px-2 py-0.5 text-xs text-accent-text">Admin</span>
          </div>
          <div className="flex items-center gap-3 text-sm text-muted">
            <span className="hidden sm:inline">{user.email}</span>
            <SignOutButton />
          </div>
        </div>
        <nav aria-label="Admin" className="container-page flex gap-5 overflow-x-auto pb-3 text-sm">
          {links.map(([href, label]) => (
            <Link key={href} href={href} className="whitespace-nowrap text-muted hover:text-fg">{label}</Link>
          ))}
        </nav>
      </header>
      <main className="container-page py-10">{children}</main>
    </div>
  );
}
