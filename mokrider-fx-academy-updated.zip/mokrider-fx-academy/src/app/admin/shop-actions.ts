"use server";

import { createHash, randomBytes } from "node:crypto";
import { Prisma } from "@prisma/client";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { audit } from "@/lib/audit";
import { parseMajorToMinor } from "@/lib/money";
import { parseEatInput } from "@/lib/time";
import { slugify } from "@/lib/text";
import { isWholeShillings } from "@/lib/commerce/pricing";
import { MAX_UPLOAD_BYTES, detectFileType } from "@/lib/commerce/fileType";
import { isSafeKey, objectInfo, storageConfigured, uploadObject } from "@/lib/storage";
import { reconcilePayment } from "@/lib/commerce/payments";
import type { FormState } from "@/components/ActionForm";

function text(fd: FormData, key: string) { return String(fd.get(key) ?? "").trim(); }

const productSchema = z.object({
  name: z.string().min(3).max(120),
  slug: z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use lowercase letters, numbers and hyphens only"),
  description: z.string().min(10),
  format: z.enum(["PDF", "EBOOK", "CHECKLIST", "WORKBOOK", "VIDEO", "TEMPLATE", "JOURNAL", "TOOL"]),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]),
  coverImage: z.string().url("Enter a full URL starting with https://").optional(),
  downloadLimit: z.coerce.number().int().min(1).max(100).optional(),
});

export async function saveProduct(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/products");
  const id = text(fd, "id");
  const name = text(fd, "name");
  const parsed = productSchema.safeParse({
    name, slug: text(fd, "slug").toLowerCase() || slugify(name), description: text(fd, "description"), format: text(fd, "format"), status: text(fd, "status"),
    coverImage: text(fd, "coverImage") || undefined, downloadLimit: text(fd, "downloadLimit") || undefined,
  });
  if (!parsed.success) return { error: `${parsed.error.issues[0].path.join(".")}: ${parsed.error.issues[0].message}` };

  const price = parseMajorToMinor(text(fd, "price") || "0", "KES");
  if (price === null || !isWholeShillings(price)) return { error: "price: enter a whole number of shillings, for example 1500. M-Pesa cannot charge cents." };
  let sale: number | null = null;
  if (text(fd, "salePrice")) {
    sale = parseMajorToMinor(text(fd, "salePrice"), "KES");
    if (sale === null || !isWholeShillings(sale)) return { error: "salePrice: enter a whole number of shillings." };
    if (sale >= price) return { error: "salePrice: the sale price must be lower than the normal price." };
  }

  if (id && parsed.data.status === "PUBLISHED") {
    const current = await prisma.productVersion.count({ where: { productId: id, isCurrent: true } });
    if (current === 0) return { error: "status: add a file version before publishing this product." };
  }
  if (!id && parsed.data.status === "PUBLISHED") return { error: "status: save it as a draft first, add a file version, then publish." };

  try {
    const d = parsed.data;
    const data = {
      name: d.name, slug: d.slug, description: d.description, format: d.format, status: d.status, coverImage: d.coverImage ?? null,
      downloadLimit: d.downloadLimit ?? null, priceMinor: price, currency: "KES", discountMinor: sale, discountEndsAt: sale === null ? null : parseEatInput(text(fd, "discountEndsAt")),
    };
    const saved = id ? await prisma.product.update({ where: { id }, data }) : await prisma.product.create({ data });
    await audit(admin.id, id ? "product.update" : "product.create", "Product", saved.id, { status: d.status });
    revalidatePath("/shop");
    if (!id) redirect(`/admin/products/${saved.id}?created=1`);
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") return { error: "That slug is already used. Choose a different one." };
    throw e;
  }
  redirect("/admin/products?saved=1");
}

const versionSchema = z.object({ version: z.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]{0,19}$/, "Use letters, numbers, dots and hyphens (max 20)") });

/** New file version. Existing buyers keep access and receive the current version. Prices and orders are untouched. */
export async function addProductVersion(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/products");
  const productId = text(fd, "productId");
  const v = versionSchema.safeParse({ version: text(fd, "version") });
  if (!v.success) return { error: `version: ${v.error.issues[0].message}` };
  if (!storageConfigured()) return { error: "File storage is not configured. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY first." };
  const product = await prisma.product.findUnique({ where: { id: productId }, select: { id: true } });
  if (!product) return { error: "Product not found." };

  const file = fd.get("file");
  const path = text(fd, "storagePath");
  let key: string, mimeType: string, sizeBytes: number, checksum: string | null = null;

  if (file instanceof File && file.size > 0) {
    if (file.size > MAX_UPLOAD_BYTES) return { error: "file: uploads are limited to 4 MB here. For larger files, upload to your private Supabase bucket and enter its path instead." };
    const bytes = new Uint8Array(await file.arrayBuffer());
    const type = detectFileType(bytes);
    if (!type) return { error: "file: only PDF and ZIP-based files (EPUB, XLSX, DOCX, ZIP) are accepted. The file content did not match." };
    key = `products/${product.id}/${v.data.version}-${randomBytes(4).toString("hex")}.${type.ext}`;
    try { await uploadObject(key, bytes, type.mime); } catch { return { error: "The upload to storage failed. Check the bucket exists and is private." }; }
    mimeType = type.mime; sizeBytes = bytes.length; checksum = createHash("sha256").update(bytes).digest("hex");
  } else if (path) {
    if (!isSafeKey(path)) return { error: "storagePath: use only letters, numbers, slashes, dots, hyphens and underscores." };
    const info = await objectInfo(path);
    if (!info) return { error: "storagePath: no file was found at that path in your private bucket." };
    key = path; mimeType = info.contentType ?? "application/octet-stream"; sizeBytes = info.size;
  } else {
    return { error: "Choose a file to upload, or enter the path of a file already in your private bucket." };
  }

  try {
    await prisma.$transaction(async (tx) => {
      if (fd.get("makeCurrent") === "on") await tx.productVersion.updateMany({ where: { productId: product.id }, data: { isCurrent: false } });
      await tx.productVersion.create({ data: { productId: product.id, version: v.data.version, storageKey: key, mimeType, sizeBytes, checksumSha256: checksum, isCurrent: fd.get("makeCurrent") === "on" } });
    });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") return { error: "version: that version label already exists for this product." };
    throw e;
  }
  await audit(admin.id, "product.version.add", "Product", product.id, { version: v.data.version });
  revalidatePath(`/admin/products/${product.id}`);
  return null;
}

export async function setCurrentVersion(versionId: string) {
  const admin = await requireRole("ADMIN", "/admin/products");
  const v = await prisma.productVersion.findUnique({ where: { id: versionId }, select: { id: true, productId: true } });
  if (!v) return;
  await prisma.$transaction([
    prisma.productVersion.updateMany({ where: { productId: v.productId }, data: { isCurrent: false } }),
    prisma.productVersion.update({ where: { id: v.id }, data: { isCurrent: true } }),
  ]);
  await audit(admin.id, "product.version.current", "ProductVersion", v.id);
  revalidatePath(`/admin/products/${v.productId}`);
}

// ---------- Orders ----------
export async function adminCheckPayment(orderId: string) {
  const admin = await requireRole("ADMIN", "/admin/orders");
  const pay = await prisma.payment.findFirst({ where: { orderId, status: { in: ["INITIATED", "PENDING"] } }, orderBy: { createdAt: "desc" } });
  if (pay) await reconcilePayment(pay.id); // asks Safaricom; there is no way to mark an order paid by hand
  await audit(admin.id, "payment.recheck", "Order", orderId);
  revalidatePath(`/admin/orders/${orderId}`);
}

export async function requestRefund(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/orders");
  const orderId = text(fd, "orderId");
  const reason = z.string().min(5, "Give a reason (at least 5 characters)").max(500).safeParse(text(fd, "reason"));
  if (!reason.success) return { error: reason.error.issues[0].message };
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { refunds: true } });
  if (!order || order.status !== "PAID") return { error: "Only paid orders can be refunded." };
  if (order.refunds.some((r) => r.status === "REQUESTED" || r.status === "PROCESSED")) return { error: "This order already has a refund request." };
  const r = await prisma.refund.create({ data: { orderId, amountMinor: order.totalMinor, currency: order.currency, reason: reason.data, status: "REQUESTED", requestedById: admin.id } });
  await audit(admin.id, "refund.request", "Order", orderId, { refundId: r.id });
  revalidatePath(`/admin/orders/${orderId}`);
  return null;
}

/** Records that YOU refunded the customer outside this system. This app does not move money for refunds. */
export async function markRefundProcessed(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/orders");
  if (fd.get("confirm") !== "on") return { error: "Tick the box to confirm you have already refunded the customer." };
  const refund = await prisma.refund.findUnique({ where: { id: text(fd, "refundId") }, include: { order: { include: { items: { include: { entitlement: true } } } } } });
  if (!refund || refund.status !== "REQUESTED") return { error: "Refund not found or already handled." };
  const providerRef = text(fd, "providerRef").slice(0, 40) || null;

  await prisma.$transaction(async (tx) => {
    await tx.refund.update({ where: { id: refund.id }, data: { status: "PROCESSED", processedAt: new Date(), providerRef } });
    await tx.order.update({ where: { id: refund.orderId }, data: { status: "REFUNDED" } });
    for (const item of refund.order.items) {
      if (!item.entitlement) continue;
      await tx.entitlement.update({ where: { id: item.entitlement.id }, data: { status: "REVOKED" } });
      if (item.kind === "COURSE" && item.courseId && refund.order.userId) {
        await tx.enrollment.deleteMany({ where: { userId: refund.order.userId, courseId: item.courseId } });
      }
    }
  });
  await audit(admin.id, "refund.processed", "Order", refund.orderId, { refundId: refund.id });
  revalidatePath(`/admin/orders/${refund.orderId}`);
  return null;
}
