import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { TextArea } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { formatMoney } from "@/lib/money";
import { formatEat } from "@/lib/time";
import { adminCheckPayment, markRefundProcessed, requestRefund } from "@/app/admin/shop-actions";

export default async function AdminOrder({ params }: { params: Promise<{ id: string }> }) {
  await requireRole("ADMIN", "/admin/orders");
  const { id } = await params;
  const o = await prisma.order.findUnique({
    where: { id },
    include: { user: { select: { email: true, name: true } }, items: true, refunds: { orderBy: { createdAt: "desc" } }, payments: { orderBy: { createdAt: "desc" }, include: { events: { orderBy: { receivedAt: "desc" } } } } },
  });
  if (!o) notFound();
  const hasPending = o.payments.some((p) => p.status === "INITIATED" || p.status === "PENDING");
  const openRefund = o.refunds.find((r) => r.status === "REQUESTED");

  return (
    <div className="max-w-3xl">
      <Link href="/admin/orders" className="link-accent text-sm">All orders</Link>
      <div className="mt-3"><AdminHeader title={`Order ${o.reference}`} /></div>
      <p className="-mt-4 mb-8 text-muted">{o.user?.name} ({o.user?.email}) · {formatEat(o.createdAt)} · <strong className="text-fg">{o.status}</strong> · {formatMoney(o.totalMinor, o.currency)}</p>

      <section className="mb-10" aria-label="Items">
        <h2 className="mb-2 text-xl">Items</h2>
        <ul className="divide-y divide-line border-y border-line text-sm">{o.items.map((i) => <li key={i.id} className="flex justify-between py-2"><span>{i.titleSnapshot} ({i.kind.toLowerCase()})</span><span>{formatMoney(i.unitPriceMinor, i.currency)}</span></li>)}</ul>
      </section>

      <section className="mb-10" aria-label="Payments">
        <h2 className="mb-2 text-xl">Payments</h2>
        {o.payments.length === 0 && <p className="text-sm text-muted">No payment records (free order).</p>}
        {o.payments.map((p) => (
          <div key={p.id} className="mb-4 rounded-md border border-line p-4 text-sm">
            <p><strong>{p.provider}</strong> · {p.status} · {formatMoney(p.amountMinor, p.currency)} · {formatEat(p.createdAt)}</p>
            <p className="text-muted">Checkout ID: {p.providerRef ?? "none"} · Receipt: {p.providerReceipt ?? "none"} · Phone ending {p.phoneLast4 ?? "n/a"}</p>
            {p.failureReason && <p className="text-muted">Reason: {p.failureReason}</p>}
            {p.events.length > 0 && <p className="mt-1 text-xs text-muted">Events: {p.events.map((e) => e.eventKey).join(", ")}</p>}
          </div>
        ))}
        {hasPending && (
          <form action={adminCheckPayment.bind(null, o.id)}>
            <button type="submit" className="btn btn-ghost">Re-check payment with M-Pesa</button>
            <p className="mt-2 text-xs text-muted">This asks Safaricom for the real result. Orders cannot be marked paid by hand.</p>
          </form>
        )}
      </section>

      <section aria-label="Refunds">
        <h2 className="mb-2 text-xl">Refunds</h2>
        {o.refunds.map((r) => <p key={r.id} className="mb-2 text-sm">{formatMoney(r.amountMinor, r.currency)} · {r.status}{r.processedAt ? ` · ${formatEat(r.processedAt)}` : ""} · {r.reason}</p>)}
        {o.status === "PAID" && !o.refunds.some((r) => r.status !== "REJECTED") && (
          <ActionForm action={requestRefund} submitLabel="Record refund request">
            <input type="hidden" name="orderId" value={o.id} />
            <TextArea label="Reason for the refund" name="reason" rows={3} required />
          </ActionForm>
        )}
        {openRefund && (
          <div className="mt-4 rounded-md border border-line p-4">
            <p className="mb-3 text-sm text-muted">This app does not send money back. Refund the customer yourself (for example from the M-Pesa portal), then record it here. Recording it ends the customer&apos;s access to this order.</p>
            <ActionForm action={markRefundProcessed} submitLabel="Record refund as done">
              <input type="hidden" name="refundId" value={openRefund.id} />
              <div>
                <label htmlFor="providerRef" className="mb-1 block text-sm font-medium">M-Pesa reference of the refund (optional)</label>
                <input id="providerRef" name="providerRef" className="field" />
              </div>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="confirm" /> I have already refunded this customer outside this system.</label>
            </ActionForm>
          </div>
        )}
      </section>
    </div>
  );
}
