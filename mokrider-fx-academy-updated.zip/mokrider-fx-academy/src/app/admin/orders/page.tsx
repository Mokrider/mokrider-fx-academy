import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { AdminHeader } from "@/components/AdminHeader";
import { formatMoney } from "@/lib/money";
import { formatEat } from "@/lib/time";

const STATUSES = ["PENDING", "AWAITING_PAYMENT", "PAID", "FAILED", "CANCELLED", "REFUNDED"];

export default async function OrdersAdmin({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  await requireRole("ADMIN", "/admin/orders");
  const { status } = await searchParams;
  const active = status && STATUSES.includes(status) ? status : undefined;
  const orders = await prisma.order.findMany({
    where: active ? { status: active as never } : {}, orderBy: { createdAt: "desc" }, take: 100,
    include: { user: { select: { email: true } }, payments: { orderBy: { createdAt: "desc" }, take: 1, select: { status: true, providerReceipt: true } } },
  });
  return (
    <>
      <AdminHeader title="Orders" />
      <nav aria-label="Status filter" className="mb-6 flex flex-wrap gap-2 text-sm">
        <Link href="/admin/orders" className={`btn ${!active ? "btn-primary" : "btn-ghost"}`}>All</Link>
        {STATUSES.map((s) => <Link key={s} href={`/admin/orders?status=${s}`} className={`btn ${active === s ? "btn-primary" : "btn-ghost"}`}>{s.replace("_", " ").toLowerCase()}</Link>)}
      </nav>
      {orders.length === 0 ? <p className="text-muted">No orders.</p> : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-muted"><tr><th className="py-2 pr-4">Reference</th><th className="pr-4">Customer</th><th className="pr-4">Total</th><th className="pr-4">Order</th><th className="pr-4">Payment</th><th>Date</th></tr></thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-t border-line">
                  <td className="py-2 pr-4"><Link href={`/admin/orders/${o.id}`} className="link-accent">{o.reference}</Link></td>
                  <td className="pr-4">{o.user?.email ?? "Guest"}</td>
                  <td className="pr-4">{formatMoney(o.totalMinor, o.currency)}</td>
                  <td className="pr-4">{o.status}</td>
                  <td className="pr-4">{o.payments[0]?.status ?? "none"}{o.payments[0]?.providerReceipt ? ` · ${o.payments[0].providerReceipt}` : ""}</td>
                  <td>{formatEat(o.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
