"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { audit } from "@/lib/audit";
import { parseEatInput } from "@/lib/time";
import { cancelBookingFor, rescheduleBooking as moveBooking } from "@/lib/booking/engine";
import { isBlackout, parseBlackoutDates, weeklySlots } from "@/lib/booking/rules";
import { blackoutDates } from "@/lib/booking/slots";
import { sendBookingMovedEmail } from "@/lib/commerce/notify";
import type { FormState } from "@/components/ActionForm";

function text(fd: FormData, key: string) { return String(fd.get(key) ?? "").trim(); }
const meetingUrl = z.string().url().refine((u) => u.startsWith("https://"), "The meeting link must start with https://");

export async function addSlots(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/mentorship");
  const packageId = text(fd, "packageId");
  const pkg = await prisma.mentorshipPackage.findUnique({ where: { id: packageId }, select: { durationMinutes: true } });
  if (!pkg) return { error: "Package not found." };
  const start = parseEatInput(text(fd, "start"));
  if (!start) return { error: "start: choose the first session date and time (East Africa Time)." };
  if (start.getTime() <= Date.now()) return { error: "start: choose a time in the future." };
  const cap = z.coerce.number().int().min(1).max(50).safeParse(text(fd, "capacity") || "1");
  const weeks = z.coerce.number().int().min(1).max(12).safeParse(text(fd, "weeks") || "1");
  if (!cap.success) return { error: "capacity: enter a whole number from 1 to 50." };
  if (!weeks.success) return { error: "weeks: enter a whole number from 1 to 12." };
  let url: string | null = null;
  if (text(fd, "meetingUrl")) {
    const u = meetingUrl.safeParse(text(fd, "meetingUrl"));
    if (!u.success) return { error: `meetingUrl: ${u.error.issues[0].message}` };
    url = u.data;
  }

  const blackout = await blackoutDates();
  const planned = weeklySlots(start, weeks.data, pkg.durationMinutes);
  const allowed = planned.filter((s) => !isBlackout(s.startsAt, blackout));
  const res = await prisma.availabilitySlot.createMany({
    data: allowed.map((s) => ({ packageId, startsAt: s.startsAt, endsAt: s.endsAt, capacity: cap.data, meetingUrl: url })),
    skipDuplicates: true,
  });
  await audit(admin.id, "slots.add", "MentorshipPackage", packageId, { created: res.count });
  revalidatePath("/mentorship");
  revalidatePath(`/admin/mentorship/${packageId}/slots`);
  const skipped = planned.length - res.count;
  return { ok: `Added ${res.count} session${res.count === 1 ? "" : "s"}.${skipped > 0 ? ` ${skipped} skipped (blackout date or already exists).` : ""}` };
}

export async function updateSlot(slotId: string, _prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/mentorship");
  const cap = z.coerce.number().int().min(0).max(50).safeParse(text(fd, "capacity"));
  if (!cap.success) return { error: "capacity: enter a whole number from 0 to 50 (0 closes the session)." };
  let url: string | null = null;
  if (text(fd, "meetingUrl")) {
    const u = meetingUrl.safeParse(text(fd, "meetingUrl"));
    if (!u.success) return { error: u.error.issues[0].message };
    url = u.data;
  }
  const slot = await prisma.availabilitySlot.update({ where: { id: slotId }, data: { capacity: cap.data, meetingUrl: url }, select: { packageId: true } });
  await audit(admin.id, "slot.update", "AvailabilitySlot", slotId);
  revalidatePath("/mentorship");
  revalidatePath(`/admin/mentorship/${slot.packageId}/slots`);
  return { ok: "Saved." };
}

export async function deleteSlot(slotId: string) {
  const admin = await requireRole("ADMIN", "/admin/mentorship");
  const slot = await prisma.availabilitySlot.findUnique({ where: { id: slotId }, select: { packageId: true, _count: { select: { bookings: true } } } });
  if (!slot) redirect("/admin/mentorship");
  if (slot._count.bookings === 0) {
    await prisma.availabilitySlot.delete({ where: { id: slotId } });
    await audit(admin.id, "slot.delete", "AvailabilitySlot", slotId);
  }
  revalidatePath("/mentorship");
  redirect(`/admin/mentorship/${slot.packageId}/slots`);
}

export async function saveBlackouts(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/bookings");
  const { dates, invalid } = parseBlackoutDates(String(fd.get("dates") ?? ""));
  if (invalid.length) return { error: `Not valid dates (use YYYY-MM-DD): ${invalid.slice(0, 3).join(", ")}` };
  await prisma.siteSetting.upsert({ where: { key: "booking" }, create: { key: "booking", value: { blackoutDates: dates } }, update: { value: { blackoutDates: dates } } });
  await audit(admin.id, "blackouts.update", "SiteSetting", "booking", { count: dates.length });
  revalidatePath("/mentorship");
  revalidatePath("/admin/bookings");
  return { ok: "Saved. Sessions on these dates are hidden from booking. Existing bookings are not changed." };
}

export async function setBookingStatus(bookingId: string, status: "COMPLETED" | "NO_SHOW") {
  const admin = await requireRole("ADMIN", "/admin/bookings");
  await prisma.booking.updateMany({ where: { id: bookingId, status: "CONFIRMED" }, data: { status, attended: status === "COMPLETED" } });
  await audit(admin.id, `booking.${status.toLowerCase()}`, "Booking", bookingId);
  revalidatePath("/admin/bookings");
}

export async function adminCancelBooking(bookingId: string) {
  const admin = await requireRole("ADMIN", "/admin/bookings");
  await cancelBookingFor({ id: admin.id, admin: true }, bookingId);
  await audit(admin.id, "booking.cancel", "Booking", bookingId);
  revalidatePath("/admin/bookings");
}

export async function rescheduleBooking(bookingId: string, _prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/bookings");
  const slotId = text(fd, "slotId");
  if (!slotId) return { error: "Choose a session to move this booking to." };
  const r = await moveBooking(bookingId, slotId);
  if (!r.ok) return { error: r.message };
  await audit(admin.id, "booking.reschedule", "Booking", bookingId, { slotId });
  await sendBookingMovedEmail(bookingId);
  revalidatePath("/admin/bookings");
  return { ok: "Moved. The student was emailed." };
}
