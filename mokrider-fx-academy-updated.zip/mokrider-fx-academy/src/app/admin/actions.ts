"use server";

import { Prisma } from "@prisma/client";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { audit } from "@/lib/audit";
import { parseMajorToMinor } from "@/lib/money";
import { isWholeShillings } from "@/lib/commerce/pricing";
import { parseEatInput } from "@/lib/time";
import { parseLines, parseTags, readingMinutes, slugify } from "@/lib/text";
import { resolvePublishedAt } from "@/lib/publishing";
import type { FormState } from "@/components/ActionForm";

const SLUG = z.string().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use lowercase letters, numbers and hyphens only");
const STATUS = z.enum(["DRAFT", "SCHEDULED", "PUBLISHED", "ARCHIVED"]);
const OPT_URL = z.string().url("Enter a full URL starting with https://").optional();

function text(fd: FormData, key: string) { return String(fd.get(key) ?? "").trim(); }
function opt(fd: FormData, key: string) { return text(fd, key) || undefined; }
function checked(fd: FormData, key: string) { return fd.get(key) === "on"; }
function firstError(e: z.ZodError): FormState {
  const i = e.issues[0];
  return { error: `${i.path.join(".") || "Form"}: ${i.message}` };
}
function dbError(e: unknown): FormState {
  if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") return { error: "That slug is already used. Choose a different one." };
  console.error(e);
  return { error: "Could not save. Please try again." };
}

// ---------------- Articles ----------------
const articleSchema = z.object({
  title: z.string().min(3).max(160),
  slug: SLUG,
  excerpt: z.string().min(10).max(300),
  body: z.string().min(20, "Write at least a few sentences"),
  status: STATUS,
  coverImage: OPT_URL,
  seoTitle: z.string().max(70).optional(),
  seoDescription: z.string().max(170).optional(),
});

export async function saveArticle(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin");
  const id = text(fd, "id");
  const title = text(fd, "title");
  const parsed = articleSchema.safeParse({
    title, slug: text(fd, "slug").toLowerCase() || slugify(title), excerpt: text(fd, "excerpt"), body: text(fd, "body"),
    status: text(fd, "status"), coverImage: opt(fd, "coverImage"), seoTitle: opt(fd, "seoTitle"), seoDescription: opt(fd, "seoDescription"),
  });
  if (!parsed.success) return firstError(parsed.error);
  const d = parsed.data;
  const publishAt = parseEatInput(text(fd, "publishAt"));
  if (d.status === "SCHEDULED" && !publishAt) return { error: "publishAt: choose a publish time for a scheduled article" };

  try {
    const existing = id ? await prisma.article.findUnique({ where: { id }, select: { publishedAt: true } }) : null;
    const publishedAt = resolvePublishedAt(d.status, publishAt, existing?.publishedAt ?? null);
    const data = {
      title: d.title, slug: d.slug, excerpt: d.excerpt, body: d.body, status: d.status, coverImage: d.coverImage ?? null,
      seoTitle: d.seoTitle ?? null, seoDescription: d.seoDescription ?? null, tags: parseTags(text(fd, "tags")),
      readingMinutes: readingMinutes(d.body), publishedAt, scheduledFor: d.status === "SCHEDULED" ? publishedAt : null,
    };
    const saved = id
      ? await prisma.article.update({ where: { id }, data })
      : await prisma.article.create({ data: { ...data, authorId: admin.id } });
    await audit(admin.id, id ? "article.update" : "article.create", "Article", saved.id, { status: d.status });
  } catch (e) { return dbError(e); }

  revalidatePath("/blog"); revalidatePath("/");
  redirect("/admin/articles?saved=1");
}

// ---------------- Market analysis ----------------
const analysisSchema = z.object({
  instrument: z.string().regex(/^[A-Z0-9]{3,12}$/, "Use capital letters, e.g. XAUUSD"),
  timeframe: z.string().min(1).max(20),
  title: z.string().min(3).max(160),
  slug: SLUG,
  body: z.string().min(20, "Write the market context"),
  status: STATUS,
  chartImage: OPT_URL,
});

export async function saveAnalysis(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin");
  const id = text(fd, "id");
  const title = text(fd, "title");
  const parsed = analysisSchema.safeParse({
    instrument: text(fd, "instrument").toUpperCase(), timeframe: text(fd, "timeframe"), title,
    slug: text(fd, "slug").toLowerCase() || slugify(title), body: text(fd, "body"), status: text(fd, "status"), chartImage: opt(fd, "chartImage"),
  });
  if (!parsed.success) return firstError(parsed.error);
  const d = parsed.data;
  const publishAt = parseEatInput(text(fd, "publishAt"));
  if (d.status === "SCHEDULED" && !publishAt) return { error: "publishAt: choose a publish time for a scheduled analysis" };

  try {
    const existing = id ? await prisma.marketAnalysis.findUnique({ where: { id }, select: { publishedAt: true } }) : null;
    const data = {
      instrument: d.instrument, timeframe: d.timeframe, title: d.title, slug: d.slug, body: d.body, status: d.status,
      marketSession: opt(fd, "marketSession") ?? null, bullishScenario: opt(fd, "bullishScenario") ?? null,
      bearishScenario: opt(fd, "bearishScenario") ?? null, invalidation: opt(fd, "invalidation") ?? null,
      riskNotes: opt(fd, "riskNotes") ?? null, chartImage: d.chartImage ?? null,
      dataTimestamp: parseEatInput(text(fd, "dataTimestamp")), isHistorical: checked(fd, "isHistorical"),
      publishedAt: resolvePublishedAt(d.status, publishAt, existing?.publishedAt ?? null),
    };
    const saved = id
      ? await prisma.marketAnalysis.update({ where: { id }, data })
      : await prisma.marketAnalysis.create({ data: { ...data, authorId: admin.id } });
    await audit(admin.id, id ? "analysis.update" : "analysis.create", "MarketAnalysis", saved.id, { status: d.status });
  } catch (e) { return dbError(e); }

  revalidatePath("/market-analysis"); revalidatePath("/");
  redirect("/admin/analyses?saved=1");
}

// ---------------- Mentorship packages ----------------
const packageSchema = z.object({
  title: z.string().min(3).max(120),
  slug: SLUG,
  description: z.string().min(10),
  kind: z.enum(["INDIVIDUAL", "GROUP", "LIVE_LESSON", "BEGINNER_PROGRAM", "GOLD", "EURUSD", "CHART_REVIEW", "WORKSHOP"]),
  durationMinutes: z.coerce.number().int().min(15).max(600),
  sessionCount: z.coerce.number().int().min(1).max(100),
  deliveryMethod: z.string().min(2).max(120),
  status: STATUS,
});

export async function savePackage(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin");
  const id = text(fd, "id");
  const title = text(fd, "title");
  const parsed = packageSchema.safeParse({
    title, slug: text(fd, "slug").toLowerCase() || slugify(title), description: text(fd, "description"), kind: text(fd, "kind"),
    durationMinutes: text(fd, "durationMinutes"), sessionCount: text(fd, "sessionCount"), deliveryMethod: text(fd, "deliveryMethod"), status: text(fd, "status"),
  });
  if (!parsed.success) return firstError(parsed.error);
  const priceMinor = parseMajorToMinor(text(fd, "price"), "KES");
  if (priceMinor === null || !isWholeShillings(priceMinor)) return { error: "price: enter a whole number of shillings, for example 2500. M-Pesa cannot charge cents." };
  const limitRaw = text(fd, "enrollmentLimit");
  const enrollmentLimit = limitRaw ? Number.parseInt(limitRaw, 10) : null;
  if (limitRaw && (!Number.isInteger(enrollmentLimit) || (enrollmentLimit ?? 0) < 1)) return { error: "enrollmentLimit: enter a whole number or leave blank" };

  try {
    const data = {
      ...parsed.data, priceMinor, currency: "KES", objectives: parseLines(text(fd, "objectives")),
      enrollmentLimit, cancellationPolicy: text(fd, "cancellationPolicy"),
    };
    const saved = id ? await prisma.mentorshipPackage.update({ where: { id }, data }) : await prisma.mentorshipPackage.create({ data });
    await audit(admin.id, id ? "package.update" : "package.create", "MentorshipPackage", saved.id, { status: data.status });
  } catch (e) { return dbError(e); }

  revalidatePath("/mentorship");
  redirect("/admin/mentorship?saved=1");
}

// ---------------- Courses ----------------
const courseSchema = z.object({
  title: z.string().min(3).max(120),
  slug: SLUG,
  summary: z.string().min(10).max(300),
  level: z.enum(["BEGINNER", "INTERMEDIATE", "ADVANCED"]),
  status: STATUS,
});

export async function saveCourse(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin");
  const id = text(fd, "id");
  const title = text(fd, "title");
  const parsed = courseSchema.safeParse({
    title, slug: text(fd, "slug").toLowerCase() || slugify(title), summary: text(fd, "summary"), level: text(fd, "level"), status: text(fd, "status"),
  });
  if (!parsed.success) return firstError(parsed.error);
  const isFree = checked(fd, "isFree");
  const priceMinor = isFree ? 0 : parseMajorToMinor(text(fd, "price") || "0", "KES");
  if (priceMinor === null) return { error: "price: enter an amount in KES, for example 4500" };

  try {
    const data = {
      ...parsed.data, description: text(fd, "description"), isFree, priceMinor, currency: "KES",
      outlineOnly: checked(fd, "outlineOnly"), certificateEnabled: checked(fd, "certificateEnabled"),
    };
    const saved = id ? await prisma.course.update({ where: { id }, data }) : await prisma.course.create({ data });
    await audit(admin.id, id ? "course.update" : "course.create", "Course", saved.id, { status: data.status });
  } catch (e) { return dbError(e); }

  revalidatePath("/learn"); revalidatePath("/");
  redirect("/admin/courses?saved=1");
}

// ---------------- About page ----------------
const aboutSchema = z.object({
  name: z.string().min(2).max(80),
  headline: z.string().min(3).max(160),
  body: z.string().min(20),
});

export async function saveAbout(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin");
  const parsed = aboutSchema.safeParse({ name: text(fd, "name"), headline: text(fd, "headline"), body: text(fd, "body") });
  if (!parsed.success) return firstError(parsed.error);
  const value = { ...parsed.data, topics: parseLines(text(fd, "topics")) };
  await prisma.siteSetting.upsert({ where: { key: "about" }, create: { key: "about", value }, update: { value } });
  await audit(admin.id, "about.update", "SiteSetting", "about");
  revalidatePath("/about");
  redirect("/admin/about?saved=1");
}
