import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Field } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { formatEat } from "@/lib/time";
import { seatsTaken } from "@/lib/booking/rules";
import { addSlots, deleteSlot, updateSlot } from "@/app/admin/booking-actions";

export default async function PackageSlots({ params }: { params: Promise<{ id: string }> }) {
  await requireRole("ADMIN", "/admin/mentorship");
  const { id } = await params;
  const pkg = await prisma.mentorshipPackage.findUnique({ where: { id } });
  if (!pkg) notFound();
  const now = new Date();
  const slots = await prisma.availabilitySlot.findMany({
    where: { packageId: id, startsAt: { gte: now } }, orderBy: { startsAt: "asc" }, take: 100,
    include: { bookings: { select: { status: true, createdAt: true } } },
  });

  return (
    <div className="max-w-3xl">
      <Link href={`/admin/mentorship/${pkg.id}`} className="link-accent text-sm">Back to package</Link>
      <div className="mt-3"><AdminHeader title={`Sessions: ${pkg.title}`} /></div>
      <p className="-mt-4 mb-8 text-sm text-muted">Each session is {pkg.durationMinutes} minutes (set on the package). All times are East Africa Time. Students can book until 2 hours before a session starts.</p>

      <section aria-label="Add sessions" className="mb-12">
        <h2 className="mb-3 text-xl">Add sessions</h2>
        <ActionForm action={addSlots} submitLabel="Add sessions">
          <input type="hidden" name="packageId" value={pkg.id} />
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="First session starts (EAT)" name="start" type="datetime-local" required />
            <Field label="Seats per session" name="capacity" type="number" defaultValue={1} hint="1 for one-to-one. More for group classes." />
            <Field label="Repeat weekly for" name="weeks" type="number" defaultValue={1} hint="Number of weeks, 1 to 12." />
          </div>
          <Field label="Meeting link (optional)" name="meetingUrl" type="url" hint="Zoom, Google Meet or similar. You can also add it later, per session." />
        </ActionForm>
      </section>

      <section aria-label="Upcoming sessions">
        <h2 className="mb-3 text-xl">Upcoming sessions</h2>
        {slots.length === 0 ? <p className="text-sm text-muted">No upcoming sessions.</p> : (
          <ul className="divide-y divide-line border-y border-line">
            {slots.map((s) => {
              const taken = seatsTaken(s.bookings, now);
              return (
                <li key={s.id} className="py-4">
                  <p className="font-medium">{formatEat(s.startsAt)}</p>
                  <p className="text-xs text-muted">{taken} of {s.capacity} seats taken{s.capacity === 0 ? " (closed)" : ""}</p>
                  <div className="mt-3">
                    <ActionForm action={updateSlot.bind(null, s.id)} submitLabel="Save session">
                      <div className="grid gap-4 sm:grid-cols-[8rem_1fr]">
                        <Field label="Seats" name="capacity" id={`cap-${s.id}`} type="number" defaultValue={s.capacity} />
                        <Field label="Meeting link" name="meetingUrl" id={`url-${s.id}`} type="url" defaultValue={s.meetingUrl} />
                      </div>
                    </ActionForm>
                    {s.bookings.length === 0 ? (
                      <form action={deleteSlot.bind(null, s.id)} className="mt-2"><button type="submit" className="btn btn-ghost !min-h-8 !text-down">Delete this session</button></form>
                    ) : <p className="mt-2 text-xs text-muted">Has bookings, so it cannot be deleted. Set seats to 0 to close it.</p>}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
