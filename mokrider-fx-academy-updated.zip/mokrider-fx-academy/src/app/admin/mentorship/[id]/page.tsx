import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Field, SelectField, TextArea, STATUS_OPTIONS } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { savePackage } from "@/app/admin/actions";

const KINDS: [string, string][] = [
  ["INDIVIDUAL", "Individual mentorship"], ["GROUP", "Group class"], ["LIVE_LESSON", "Live online lesson"],
  ["BEGINNER_PROGRAM", "Beginner program"], ["GOLD", "Gold-focused training"], ["EURUSD", "EURUSD-focused training"],
  ["CHART_REVIEW", "Chart review"], ["WORKSHOP", "Workshop"],
];

export default async function EditPackage({ params }: { params: Promise<{ id: string }> }) {
  await requireRole("ADMIN", "/admin/mentorship");
  const { id } = await params;
  const p = id === "new" ? null : await prisma.mentorshipPackage.findUnique({ where: { id } });
  if (id !== "new" && !p) notFound();
  const price = p ? (p.priceMinor / 100).toFixed(2) : "";
  return (
    <div className="max-w-3xl">
      <AdminHeader title={p ? "Edit package" : "New package"} />
      {p && <p className="-mt-4 mb-6"><Link href={`/admin/mentorship/${p.id}/slots`} className="btn btn-ghost">Manage sessions</Link></p>}
      <ActionForm action={savePackage}>
        <input type="hidden" name="id" value={p?.id ?? ""} />
        <Field label="Title" name="title" required defaultValue={p?.title} />
        <Field label="URL slug" name="slug" defaultValue={p?.slug} hint="Leave blank to create it from the title." />
        <SelectField label="Type" name="kind" defaultValue={p?.kind ?? "INDIVIDUAL"} options={KINDS} />
        <TextArea label="Description" name="description" rows={5} required defaultValue={p?.description} />
        <TextArea label="Learning objectives" name="objectives" rows={5} defaultValue={p?.objectives.join("\n")} hint="One per line." />
        <div className="grid gap-5 sm:grid-cols-3">
          <Field label="Price (KES)" name="price" required defaultValue={price} />
          <Field label="Session length (minutes)" name="durationMinutes" type="number" required defaultValue={p?.durationMinutes ?? 60} />
          <Field label="Number of sessions" name="sessionCount" type="number" required defaultValue={p?.sessionCount ?? 1} />
        </div>
        <Field label="Delivery method" name="deliveryMethod" required defaultValue={p?.deliveryMethod ?? "Live online"} />
        <Field label="Enrollment limit" name="enrollmentLimit" type="number" defaultValue={p?.enrollmentLimit} hint="Leave blank for no limit." />
        <TextArea label="Cancellation and refund policy" name="cancellationPolicy" rows={4} defaultValue={p?.cancellationPolicy} />
        <SelectField label="Status" name="status" defaultValue={p?.status ?? "DRAFT"} options={STATUS_OPTIONS.filter(([v]) => v !== "SCHEDULED")} />
      </ActionForm>
    </div>
  );
}
