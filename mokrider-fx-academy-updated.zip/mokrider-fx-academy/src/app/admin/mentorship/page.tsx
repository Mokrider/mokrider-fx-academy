import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { AdminHeader } from "@/components/AdminHeader";
import { formatMoney } from "@/lib/money";

export default async function PackagesAdmin({ searchParams }: { searchParams: Promise<{ saved?: string }> }) {
  await requireRole("ADMIN", "/admin/mentorship");
  const { saved } = await searchParams;
  const items = await prisma.mentorshipPackage.findMany({ orderBy: { title: "asc" } });
  return (
    <>
      <AdminHeader title="Mentorship packages" newHref="/admin/mentorship/new" saved={saved === "1"} />
      {items.length === 0 ? <p className="text-muted">No packages yet.</p> : (
        <ul className="divide-y divide-line border-y border-line">
          {items.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div>
                <p className="font-medium">{p.title}</p>
                <p className="text-sm text-muted">{p.status} · {formatMoney(p.priceMinor, p.currency)} · {p.durationMinutes} min</p>
              </div>
              <Link className="link-accent text-sm" href={`/admin/mentorship/${p.id}`}>Edit</Link>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
