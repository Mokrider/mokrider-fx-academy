import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { TextArea } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { formatEat } from "@/lib/time";
import { blackoutDates, openSlots } from "@/lib/booking/slots";
import { adminCancelBooking, rescheduleBooking, saveBlackouts, setBookingStatus } from "@/app/admin/booking-actions";

export default async function BookingsAdmin() {
  await requireRole("ADMIN", "/admin/bookings");
  const now = new Date();
  const [blackout, bookings] = await Promise.all([
    blackoutDates(),
    prisma.booking.findMany({
      where: { status: { not: "CANCELLED" }, slot: { startsAt: { gte: new Date(now.getTime() - 14 * 24 * 3600 * 1000) } } },
      orderBy: { slot: { startsAt: "asc" } }, take: 200,
      include: { user: { select: { email: true, name: true } }, package: { select: { title: true } }, slot: { select: { startsAt: true } }, order: { select: { reference: true, status: true } } },
    }),
  ]);
  const open = await openSlots([...new Set(bookings.map((b) => b.packageId))]);

  return (
    <>
      <AdminHeader title="Bookings" />
      <section aria-label="Blackout dates" className="mb-12 max-w-xl">
        <h2 className="mb-2 text-xl">Blackout dates</h2>
        <ActionForm action={saveBlackouts} submitLabel="Save blackout dates">
          <TextArea label="Dates when no sessions can be booked" name="dates" rows={4} defaultValue={blackout.join("\n")} hint="One per line, as YYYY-MM-DD (East Africa date), for example 2026-12-25." />
        </ActionForm>
      </section>

      <h2 className="mb-3 text-xl">Bookings (from two weeks ago onward)</h2>
      {bookings.length === 0 ? <p className="text-muted">No bookings.</p> : (
        <ul className="divide-y divide-line border-y border-line">
          {bookings.map((b) => {
            const upcoming = b.slot.startsAt > now;
            const choices = open.filter((s) => s.packageId === b.packageId);
            return (
              <li key={b.id} className="py-4">
                <p className="font-medium">{b.package.title} &middot; {formatEat(b.slot.startsAt)}</p>
                <p className="text-sm text-muted">{b.user.name} ({b.user.email}) &middot; <strong className="text-fg">{b.status.replace("_", " ")}</strong>{b.order ? ` · order ${b.order.reference} (${b.order.status})` : " · free"}</p>
                <div className="mt-3 flex flex-wrap items-start gap-3">
                  {b.status === "CONFIRMED" && !upcoming && (
                    <>
                      <form action={setBookingStatus.bind(null, b.id, "COMPLETED")}><button className="btn btn-ghost !min-h-8">Attended</button></form>
                      <form action={setBookingStatus.bind(null, b.id, "NO_SHOW")}><button className="btn btn-ghost !min-h-8">No-show</button></form>
                    </>
                  )}
                  {(b.status === "CONFIRMED" || b.status === "AWAITING_PAYMENT") && (
                    <form action={adminCancelBooking.bind(null, b.id)}><button className="btn btn-ghost !min-h-8 !text-down">Cancel{b.order?.status === "PAID" ? " and request refund" : ""}</button></form>
                  )}
                </div>
                {(b.status === "CONFIRMED" || b.status === "AWAITING_PAYMENT") && upcoming && choices.length > 0 && (
                  <details className="mt-3">
                    <summary className="cursor-pointer text-sm text-accent-text">Move to another session</summary>
                    <div className="mt-3 max-w-md">
                      <ActionForm action={rescheduleBooking.bind(null, b.id)} submitLabel="Move booking">
                        <div>
                          <label htmlFor={`slot-${b.id}`} className="mb-1 block text-sm font-medium">New session</label>
                          <select id={`slot-${b.id}`} name="slotId" className="field" defaultValue="">
                            <option value="" disabled>Choose a session</option>
                            {choices.map((s) => <option key={s.id} value={s.id}>{formatEat(s.startsAt)} ({s.seatsLeft} seat{s.seatsLeft === 1 ? "" : "s"} left)</option>)}
                          </select>
                        </div>
                      </ActionForm>
                    </div>
                  </details>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
