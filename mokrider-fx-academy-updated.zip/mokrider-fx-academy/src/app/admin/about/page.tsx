import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Field, TextArea } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { saveAbout } from "@/app/admin/actions";

type About = { name: string; headline: string; body: string; topics: string[] };

export default async function AboutAdmin({ searchParams }: { searchParams: Promise<{ saved?: string }> }) {
  await requireRole("ADMIN", "/admin/about");
  const { saved } = await searchParams;
  const row = await prisma.siteSetting.findUnique({ where: { key: "about" } });
  const a = (row?.value ?? null) as About | null;
  return (
    <div className="max-w-3xl">
      <AdminHeader title="About page" saved={saved === "1"} />
      <p className="mb-6 text-sm text-muted">Write only what is true. Do not state qualifications, years of experience or results you cannot document.</p>
      <ActionForm action={saveAbout}>
        <Field label="Mentor name" name="name" required defaultValue={a?.name} />
        <Field label="Headline" name="headline" required defaultValue={a?.headline} />
        <TextArea label="About text" name="body" rows={14} required defaultValue={a?.body} hint="Markdown." />
        <TextArea label="Topics taught" name="topics" rows={6} defaultValue={a?.topics?.join("\n")} hint="One per line." />
      </ActionForm>
    </div>
  );
}
