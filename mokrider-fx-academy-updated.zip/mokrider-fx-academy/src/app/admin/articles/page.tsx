import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { AdminHeader } from "@/components/AdminHeader";
import { formatEat } from "@/lib/time";

export default async function ArticlesAdmin({ searchParams }: { searchParams: Promise<{ saved?: string }> }) {
  await requireRole("ADMIN", "/admin/articles");
  const { saved } = await searchParams;
  const items = await prisma.article.findMany({ orderBy: { updatedAt: "desc" }, select: { id: true, title: true, status: true, publishedAt: true, slug: true } });
  return (
    <>
      <AdminHeader title="Articles" newHref="/admin/articles/new" saved={saved === "1"} />
      {items.length === 0 ? <p className="text-muted">No articles yet. Create the first one.</p> : (
        <ul className="divide-y divide-line border-y border-line">
          {items.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div>
                <p className="font-medium">{a.title}</p>
                <p className="text-sm text-muted">{a.status}{a.publishedAt ? ` · ${formatEat(a.publishedAt)}` : ""}</p>
              </div>
              <div className="flex gap-4 text-sm">
                <Link className="link-accent" href={`/blog/${a.slug}?preview=1`}>Preview</Link>
                <Link className="link-accent" href={`/admin/articles/${a.id}`}>Edit</Link>
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
