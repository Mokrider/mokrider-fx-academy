import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Field, SelectField, TextArea, STATUS_OPTIONS } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { toEatInput } from "@/lib/time";
import { saveArticle } from "@/app/admin/actions";

export default async function EditArticle({ params }: { params: Promise<{ id: string }> }) {
  await requireRole("ADMIN", "/admin/articles");
  const { id } = await params;
  const a = id === "new" ? null : await prisma.article.findUnique({ where: { id } });
  if (id !== "new" && !a) notFound();
  return (
    <div className="max-w-3xl">
      <AdminHeader title={a ? "Edit article" : "New article"} />
      <ActionForm action={saveArticle}>
        <input type="hidden" name="id" value={a?.id ?? ""} />
        <Field label="Title" name="title" required defaultValue={a?.title} />
        <Field label="URL slug" name="slug" defaultValue={a?.slug} hint="Leave blank to create it from the title." />
        <TextArea label="Excerpt" name="excerpt" rows={3} required defaultValue={a?.excerpt} hint="Shown in lists and search results (10 to 300 characters)." />
        <TextArea label="Body" name="body" rows={18} required defaultValue={a?.body} hint="Markdown: ## headings, - lists, **bold**, *italic*, [link](https://...). Blank line between paragraphs." />
        <Field label="Tags" name="tags" defaultValue={a?.tags.join(", ")} hint="Comma separated, for example gold, risk-management." />
        <Field label="Cover image URL" name="coverImage" type="url" defaultValue={a?.coverImage} />
        <SelectField label="Status" name="status" defaultValue={a?.status ?? "DRAFT"} options={STATUS_OPTIONS} />
        <Field label="Publish time (East Africa Time)" name="publishAt" type="datetime-local" defaultValue={toEatInput(a?.publishedAt)} hint="Required for Scheduled. For Published, leave blank to publish now." />
        <Field label="SEO title" name="seoTitle" defaultValue={a?.seoTitle} />
        <Field label="SEO description" name="seoDescription" defaultValue={a?.seoDescription} />
      </ActionForm>
    </div>
  );
}
