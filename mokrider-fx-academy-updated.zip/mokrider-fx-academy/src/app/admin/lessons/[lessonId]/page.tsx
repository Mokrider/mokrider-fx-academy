import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Check, Field, SelectField, TextArea } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { deleteLesson, saveLesson } from "@/app/admin/lesson-actions";

export default async function EditLesson({ params }: { params: Promise<{ lessonId: string }> }) {
  await requireRole("ADMIN", "/admin/courses");
  const { lessonId } = await params;
  const l = await prisma.lesson.findUnique({ where: { id: lessonId }, include: { module: { include: { course: { select: { id: true, slug: true, title: true } } } } } });
  if (!l) notFound();
  const course = l.module.course;

  return (
    <div className="max-w-3xl">
      <Link href={`/admin/courses/${course.id}/lessons`} className="link-accent text-sm">Back to lessons</Link>
      <div className="mt-3"><AdminHeader title="Edit lesson" /></div>
      <p className="-mt-4 mb-6 text-sm text-muted">{course.title} &middot; {l.module.title} &middot; <Link className="link-accent" href={`/learn/${course.slug}/lessons/${l.id}`}>View as student</Link> (the course must be published, or you must be an admin)</p>
      <ActionForm action={saveLesson}>
        <input type="hidden" name="id" value={l.id} />
        <Field label="Title" name="title" required defaultValue={l.title} />
        <SelectField label="Type" name="kind" defaultValue={l.kind} options={[["TEXT", "Text"], ["VIDEO", "Video"], ["PDF", "PDF"], ["QUIZ", "Quiz (not available to students yet)"], ["ASSIGNMENT", "Assignment"]]} />
        <TextArea label="Lesson content" name="content" rows={20} defaultValue={l.content} hint="Markdown: ## headings, - lists, **bold**, *italic*, [link](https://...). Blank line between paragraphs." />
        <Field label="Video link (optional)" name="videoUrl" type="url" defaultValue={l.videoUrl} hint="A full https link from YouTube or Vimeo. Only these two providers can be embedded." />
        <Field label="Estimated minutes" name="durationMinutes" type="number" defaultValue={l.durationMinutes} />
        <Check label="Free preview (anyone can read this lesson without enrolling)" name="isFreePreview" defaultChecked={l.isFreePreview} />
      </ActionForm>
      <form action={deleteLesson.bind(null, l.id)} className="mt-10 border-t border-line pt-6">
        <p className="mb-3 text-sm text-muted">Deleting a lesson also removes students&apos; completion records for it. This cannot be undone.</p>
        <button type="submit" className="btn btn-ghost !text-down">Delete this lesson</button>
      </form>
    </div>
  );
}
