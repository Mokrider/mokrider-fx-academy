"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { audit } from "@/lib/audit";
import type { FormState } from "@/components/ActionForm";

const schema = z.object({
  email: z.string().email("Enter the student's email address"),
  courseId: z.string().min(1, "Choose a course"),
});

/** Gives a student access to a course by hand: a sponsored seat, or a payment you confirmed yourself. */
export async function grantCourseAccess(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/access");
  const parsed = schema.safeParse({
    email: String(fd.get("email") ?? "").trim().toLowerCase(),
    courseId: String(fd.get("courseId") ?? "").trim(),
  });
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const user = await prisma.user.findFirst({ where: { email: { equals: parsed.data.email, mode: "insensitive" } }, select: { id: true, name: true } });
  if (!user) return { error: "No account uses that email yet. Ask the student to create an account first, then try again." };
  const course = await prisma.course.findUnique({ where: { id: parsed.data.courseId }, select: { id: true, title: true } });
  if (!course) return { error: "That course no longer exists." };

  const enrollment = await prisma.enrollment.upsert({
    where: { userId_courseId: { userId: user.id, courseId: course.id } },
    create: { userId: user.id, courseId: course.id },
    update: {},
  });
  await audit(admin.id, "enrollment.grant", "Enrollment", enrollment.id, { courseId: course.id });
  revalidatePath("/admin/access");
  revalidatePath("/dashboard");
  return { ok: `${user.name} now has access to "${course.title}".` };
}

/** Takes a course away again. The student's lesson progress is kept in case access is restored. */
export async function revokeCourseAccess(enrollmentId: string): Promise<void> {
  const admin = await requireRole("ADMIN", "/admin/access");
  await prisma.enrollment.delete({ where: { id: enrollmentId } }).catch(() => undefined);
  await audit(admin.id, "enrollment.revoke", "Enrollment", enrollmentId);
  revalidatePath("/admin/access");
  revalidatePath("/dashboard");
}
