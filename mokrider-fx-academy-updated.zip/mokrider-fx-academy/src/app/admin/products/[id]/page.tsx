import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Check, Field, SelectField, TextArea } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { toEatInput } from "@/lib/time";
import { storageConfigured } from "@/lib/storage";
import { addProductVersion, saveProduct, setCurrentVersion } from "@/app/admin/shop-actions";

const FORMATS: [string, string][] = [["PDF", "PDF"], ["EBOOK", "E-book"], ["CHECKLIST", "Checklist"], ["WORKBOOK", "Workbook"], ["VIDEO", "Video"], ["TEMPLATE", "Template"], ["JOURNAL", "Journal"], ["TOOL", "Tool"]];

export default async function EditProduct({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ created?: string }> }) {
  await requireRole("ADMIN", "/admin/products");
  const { id } = await params;
  const { created } = await searchParams;
  const p = id === "new" ? null : await prisma.product.findUnique({ where: { id }, include: { versions: { orderBy: { createdAt: "desc" } } } });
  if (id !== "new" && !p) notFound();
  const shillings = (m: number | null | undefined) => (m == null ? "" : String(m / 100));

  return (
    <div className="max-w-3xl">
      <AdminHeader title={p ? "Edit product" : "New product"} saved={created === "1"} />
      <ActionForm action={saveProduct}>
        <input type="hidden" name="id" value={p?.id ?? ""} />
        <Field label="Name" name="name" required defaultValue={p?.name} />
        <Field label="URL slug" name="slug" defaultValue={p?.slug} hint="Leave blank to create it from the name." />
        <TextArea label="Description" name="description" rows={8} required defaultValue={p?.description} hint="Markdown." />
        <SelectField label="Format" name="format" defaultValue={p?.format ?? "PDF"} options={FORMATS} />
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Price (KES, whole shillings)" name="price" defaultValue={shillings(p?.priceMinor)} hint="0 makes it free." />
          <Field label="Sale price (KES, optional)" name="salePrice" defaultValue={shillings(p?.discountMinor)} hint="Lower than the price." />
          <Field label="Sale ends (EAT, optional)" name="discountEndsAt" type="datetime-local" defaultValue={toEatInput(p?.discountEndsAt)} />
        </div>
        <Field label="Download limit per buyer (optional)" name="downloadLimit" type="number" defaultValue={p?.downloadLimit} hint="Leave blank for no limit." />
        <Field label="Cover image URL (optional)" name="coverImage" type="url" defaultValue={p?.coverImage} />
        <SelectField label="Status" name="status" defaultValue={p?.status ?? "DRAFT"} options={[["DRAFT", "Draft (not public)"], ["PUBLISHED", "Published (needs a current file version)"], ["ARCHIVED", "Archived (hidden)"]]} />
      </ActionForm>

      {p && (
        <section className="mt-14 border-t border-line pt-8" aria-labelledby="versions-h">
          <h2 id="versions-h" className="text-2xl">File versions</h2>
          <p className="mt-1 text-sm text-muted">Files live in a private bucket and are only ever served through short-lived signed links to people who bought the product. Buyers always get the current version.</p>
          {!storageConfigured() && <p className="mt-4 rounded-md border border-line bg-surface p-3 text-sm">File storage is not configured yet. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in your environment.</p>}
          <ul className="mt-4 divide-y divide-line border-y border-line text-sm">
            {p.versions.length === 0 && <li className="py-3 text-muted">No versions yet.</li>}
            {p.versions.map((v) => (
              <li key={v.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                <span>v{v.version} · {(v.sizeBytes / (1024 * 1024)).toFixed(2)} MB · {v.mimeType}{v.isCurrent ? " · CURRENT" : ""}</span>
                {!v.isCurrent && <form action={setCurrentVersion.bind(null, v.id)}><button type="submit" className="btn btn-ghost !min-h-8 !px-3">Make current</button></form>}
              </li>
            ))}
          </ul>
          <div className="mt-6">
            <h3 className="mb-3 text-lg">Add a version</h3>
            <ActionForm action={addProductVersion} submitLabel="Add version">
              <input type="hidden" name="productId" value={p.id} />
              <Field label="Version label" name="version" required placeholder="1.0" />
              <div>
                <label htmlFor="file" className="mb-1 block text-sm font-medium">Upload a file (PDF or ZIP-based, up to 4 MB)</label>
                <input id="file" name="file" type="file" accept=".pdf,.zip,.epub,.xlsx,.docx" className="field" />
              </div>
              <Field label="Or the path of a file already in your private bucket" name="storagePath" hint="For larger files: upload in the Supabase dashboard, then enter the path, for example products/guide/v1.pdf." />
              <Check label="Make this the current version" name="makeCurrent" defaultChecked />
            </ActionForm>
          </div>
        </section>
      )}
    </div>
  );
}
