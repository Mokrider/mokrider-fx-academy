import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { AdminHeader } from "@/components/AdminHeader";
import { formatMoney } from "@/lib/money";

export default async function ProductsAdmin({ searchParams }: { searchParams: Promise<{ saved?: string }> }) {
  await requireRole("ADMIN", "/admin/products");
  const { saved } = await searchParams;
  const items = await prisma.product.findMany({ orderBy: { createdAt: "desc" }, include: { versions: { where: { isCurrent: true }, select: { version: true } }, _count: { select: { entitlements: true } } } });
  return (
    <>
      <AdminHeader title="Products" newHref="/admin/products/new" saved={saved === "1"} />
      {items.length === 0 ? <p className="text-muted">No products yet.</p> : (
        <ul className="divide-y divide-line border-y border-line">
          {items.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div>
                <p className="font-medium">{p.name}</p>
                <p className="text-sm text-muted">{p.status} · {p.priceMinor === 0 ? "Free" : formatMoney(p.priceMinor, p.currency)} · {p.versions[0] ? `file v${p.versions[0].version}` : "no file yet"} · {p._count.entitlements} owners</p>
              </div>
              <Link className="link-accent text-sm" href={`/admin/products/${p.id}`}>Edit</Link>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
