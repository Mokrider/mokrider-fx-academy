import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Field, SelectField } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { formatEat } from "@/lib/time";
import { grantCourseAccess, revokeCourseAccess } from "@/app/admin/access-actions";

export default async function AccessAdmin() {
  await requireRole("ADMIN", "/admin/access");
  const [courses, recent] = await Promise.all([
    prisma.course.findMany({ orderBy: { title: "asc" }, select: { id: true, title: true, status: true } }),
    prisma.enrollment.findMany({
      orderBy: { createdAt: "desc" },
      take: 20,
      include: { user: { select: { email: true, name: true } }, course: { select: { title: true } } },
    }),
  ]);

  return (
    <div className="max-w-3xl">
      <AdminHeader title="Grant course access" />
      <p className="mb-6 text-sm text-muted">
        Use this for sponsored seats and for payments you have confirmed yourself (cash, M-Pesa to your till, bank). The student must already have an account.
      </p>
      {courses.length === 0 ? (
        <p className="text-muted">There are no courses yet. Add one under Courses first.</p>
      ) : (
        <ActionForm action={grantCourseAccess} submitLabel="Grant access">
          <Field label="Student's email" name="email" type="email" required placeholder="student@example.com" />
          <SelectField
            label="Course"
            name="courseId"
            options={courses.map((c) => [c.id, `${c.title}${c.status === "PUBLISHED" ? "" : ` (${c.status.toLowerCase()})`}`] as [string, string])}
          />
        </ActionForm>
      )}

      <h2 className="mt-14 text-2xl">Latest enrolments</h2>
      {recent.length === 0 ? (
        <p className="mt-4 text-muted">No enrolments yet.</p>
      ) : (
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-muted"><tr><th className="py-2 pr-4">Student</th><th className="pr-4">Course</th><th className="pr-4">Date</th><th /></tr></thead>
            <tbody>
              {recent.map((e) => (
                <tr key={e.id} className="border-t border-line">
                  <td className="py-2 pr-4">{e.user.name}<br /><span className="text-xs text-muted">{e.user.email}</span></td>
                  <td className="pr-4">{e.course.title}</td>
                  <td className="pr-4">{formatEat(e.createdAt)}</td>
                  <td>
                    <form action={revokeCourseAccess.bind(null, e.id)}><button type="submit" className="text-sm text-down underline">Remove access</button></form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
