"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { audit } from "@/lib/audit";
import { slugify } from "@/lib/text";
import { toEmbedUrl } from "@/lib/learning/video";
import type { FormState } from "@/components/ActionForm";

const KIND = z.enum(["TEXT", "VIDEO", "PDF", "QUIZ", "ASSIGNMENT"]);
function text(fd: FormData, key: string) { return String(fd.get(key) ?? "").trim(); }

async function courseIdOfModule(moduleId: string) {
  return (await prisma.module.findUnique({ where: { id: moduleId }, select: { courseId: true } }))?.courseId;
}

export async function addModule(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/courses");
  const courseId = text(fd, "courseId");
  const title = z.string().min(2).max(120).safeParse(text(fd, "title"));
  if (!title.success) return { error: "Enter a module title (2 to 120 characters)." };
  const last = await prisma.module.findFirst({ where: { courseId }, orderBy: { position: "desc" }, select: { position: true } });
  const m = await prisma.module.create({ data: { courseId, title: title.data, position: (last?.position ?? 0) + 1 } });
  await audit(admin.id, "module.create", "Module", m.id);
  revalidatePath(`/admin/courses/${courseId}/lessons`);
  return null;
}

export async function addLesson(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/courses");
  const moduleId = text(fd, "moduleId");
  const title = z.string().min(2).max(160).safeParse(text(fd, "title"));
  const kind = KIND.safeParse(text(fd, "kind"));
  if (!title.success) return { error: "Enter a lesson title (2 to 160 characters)." };
  if (!kind.success) return { error: "Choose a lesson type." };
  const courseId = await courseIdOfModule(moduleId);
  if (!courseId) return { error: "Module not found." };

  const last = await prisma.lesson.findFirst({ where: { moduleId }, orderBy: { position: "desc" }, select: { position: true } });
  const position = (last?.position ?? 0) + 1;
  let slug = slugify(title.data) || `lesson-${position}`;
  if (await prisma.lesson.findUnique({ where: { moduleId_slug: { moduleId, slug } }, select: { id: true } })) slug = `${slug}-${position}`;
  const l = await prisma.lesson.create({ data: { moduleId, title: title.data, slug, kind: kind.data, position } });
  await audit(admin.id, "lesson.create", "Lesson", l.id);
  revalidatePath(`/admin/courses/${courseId}/lessons`);
  return null;
}

const lessonSchema = z.object({
  title: z.string().min(2).max(160),
  kind: KIND,
  content: z.string().max(100_000),
  durationMinutes: z.coerce.number().int().min(1).max(600).optional(),
});

export async function saveLesson(_prev: FormState, fd: FormData): Promise<FormState> {
  const admin = await requireRole("ADMIN", "/admin/courses");
  const id = text(fd, "id");
  const parsed = lessonSchema.safeParse({
    title: text(fd, "title"), kind: text(fd, "kind"), content: String(fd.get("content") ?? ""),
    durationMinutes: text(fd, "durationMinutes") || undefined,
  });
  if (!parsed.success) return { error: `${parsed.error.issues[0].path.join(".")}: ${parsed.error.issues[0].message}` };
  const videoUrl = text(fd, "videoUrl");
  if (videoUrl && !toEmbedUrl(videoUrl)) return { error: "videoUrl: use a full https link from YouTube or Vimeo." };

  const lesson = await prisma.lesson.findUnique({ where: { id }, select: { module: { select: { courseId: true } } } });
  if (!lesson) return { error: "Lesson not found." };
  await prisma.lesson.update({
    where: { id },
    data: {
      title: parsed.data.title, kind: parsed.data.kind, content: parsed.data.content.trim() || null,
      videoUrl: videoUrl || null, durationMinutes: parsed.data.durationMinutes ?? null, isFreePreview: fd.get("isFreePreview") === "on",
    },
  });
  await audit(admin.id, "lesson.update", "Lesson", id);
  revalidatePath("/learn");
  redirect(`/admin/courses/${lesson.module.courseId}/lessons?saved=1`);
}

export async function moveLesson(lessonId: string, direction: "up" | "down") {
  await requireRole("ADMIN", "/admin/courses");
  const l = await prisma.lesson.findUnique({ where: { id: lessonId }, select: { id: true, moduleId: true, position: true } });
  if (!l) return;
  const other = await prisma.lesson.findFirst({
    where: { moduleId: l.moduleId, position: direction === "up" ? { lt: l.position } : { gt: l.position } },
    orderBy: { position: direction === "up" ? "desc" : "asc" },
    select: { id: true, position: true },
  });
  if (!other) return;
  // Positions are unique per module, so park one row at -1 while swapping.
  await prisma.$transaction([
    prisma.lesson.update({ where: { id: l.id }, data: { position: -1 } }),
    prisma.lesson.update({ where: { id: other.id }, data: { position: l.position } }),
    prisma.lesson.update({ where: { id: l.id }, data: { position: other.position } }),
  ]);
  const courseId = await courseIdOfModule(l.moduleId);
  revalidatePath(`/admin/courses/${courseId}/lessons`);
}

export async function moveModule(moduleId: string, direction: "up" | "down") {
  await requireRole("ADMIN", "/admin/courses");
  const m = await prisma.module.findUnique({ where: { id: moduleId }, select: { id: true, courseId: true, position: true } });
  if (!m) return;
  const other = await prisma.module.findFirst({
    where: { courseId: m.courseId, position: direction === "up" ? { lt: m.position } : { gt: m.position } },
    orderBy: { position: direction === "up" ? "desc" : "asc" },
    select: { id: true, position: true },
  });
  if (!other) return;
  await prisma.$transaction([
    prisma.module.update({ where: { id: m.id }, data: { position: -1 } }),
    prisma.module.update({ where: { id: other.id }, data: { position: m.position } }),
    prisma.module.update({ where: { id: m.id }, data: { position: other.position } }),
  ]);
  revalidatePath(`/admin/courses/${m.courseId}/lessons`);
}

export async function deleteLesson(lessonId: string) {
  const admin = await requireRole("ADMIN", "/admin/courses");
  const l = await prisma.lesson.findUnique({ where: { id: lessonId }, select: { module: { select: { courseId: true } } } });
  if (!l) redirect("/admin/courses");
  await prisma.lesson.delete({ where: { id: lessonId } }); // also removes students' progress rows for it
  await audit(admin.id, "lesson.delete", "Lesson", lessonId);
  revalidatePath("/learn");
  redirect(`/admin/courses/${l.module.courseId}/lessons?saved=1`);
}

export async function deleteModule(moduleId: string) {
  const admin = await requireRole("ADMIN", "/admin/courses");
  const m = await prisma.module.findUnique({ where: { id: moduleId }, select: { courseId: true, _count: { select: { lessons: true } } } });
  if (!m) redirect("/admin/courses");
  if (m._count.lessons === 0) {
    await prisma.module.delete({ where: { id: moduleId } });
    await audit(admin.id, "module.delete", "Module", moduleId);
  }
  revalidatePath(`/admin/courses/${m.courseId}/lessons`);
  redirect(`/admin/courses/${m.courseId}/lessons`);
}
