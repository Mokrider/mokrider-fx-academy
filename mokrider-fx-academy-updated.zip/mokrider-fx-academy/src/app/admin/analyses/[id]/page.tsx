import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { ActionForm } from "@/components/ActionForm";
import { Check, Field, SelectField, TextArea, STATUS_OPTIONS } from "@/components/formFields";
import { AdminHeader } from "@/components/AdminHeader";
import { toEatInput } from "@/lib/time";
import { saveAnalysis } from "@/app/admin/actions";

export default async function EditAnalysis({ params }: { params: Promise<{ id: string }> }) {
  await requireRole("ADMIN", "/admin/analyses");
  const { id } = await params;
  const a = id === "new" ? null : await prisma.marketAnalysis.findUnique({ where: { id } });
  if (id !== "new" && !a) notFound();
  return (
    <div className="max-w-3xl">
      <AdminHeader title={a ? "Edit analysis" : "New analysis"} />
      <ActionForm action={saveAnalysis}>
        <input type="hidden" name="id" value={a?.id ?? ""} />
        <div className="grid gap-5 sm:grid-cols-3">
          <SelectField label="Instrument" name="instrument" defaultValue={a?.instrument ?? "XAUUSD"} options={[["XAUUSD", "XAUUSD (Gold)"], ["EURUSD", "EURUSD"]]} />
          <Field label="Timeframe" name="timeframe" required defaultValue={a?.timeframe ?? "H4"} hint="For example M15, H1, H4, D1." />
          <Field label="Market session" name="marketSession" defaultValue={a?.marketSession} hint="For example London." />
        </div>
        <Field label="Title" name="title" required defaultValue={a?.title} />
        <Field label="URL slug" name="slug" defaultValue={a?.slug} hint="Leave blank to create it from the title." />
        <TextArea label="Market context" name="body" rows={10} required defaultValue={a?.body} hint="Markdown. Describe structure, key zones, liquidity and imbalances." />
        <TextArea label="Bullish scenario" name="bullishScenario" rows={4} defaultValue={a?.bullishScenario} />
        <TextArea label="Bearish scenario" name="bearishScenario" rows={4} defaultValue={a?.bearishScenario} />
        <TextArea label="What would invalidate it" name="invalidation" rows={3} defaultValue={a?.invalidation} />
        <TextArea label="Risk considerations" name="riskNotes" rows={3} defaultValue={a?.riskNotes} />
        <Field label="Chart image URL" name="chartImage" type="url" defaultValue={a?.chartImage} hint="Use your own chart screenshot. Do not copy images you do not have rights to." />
        <Field label="Chart data captured at (East Africa Time)" name="dataTimestamp" type="datetime-local" defaultValue={toEatInput(a?.dataTimestamp)} />
        <Check label="Historical example (not current analysis)" name="isHistorical" defaultChecked={a?.isHistorical} />
        <SelectField label="Status" name="status" defaultValue={a?.status ?? "DRAFT"} options={STATUS_OPTIONS} />
        <Field label="Publish time (East Africa Time)" name="publishAt" type="datetime-local" defaultValue={toEatInput(a?.publishedAt)} hint="Required for Scheduled. For Published, leave blank to publish now." />
      </ActionForm>
    </div>
  );
}
