import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/session";
import { AdminHeader } from "@/components/AdminHeader";
import { formatEat } from "@/lib/time";

export default async function AnalysesAdmin({ searchParams }: { searchParams: Promise<{ saved?: string }> }) {
  await requireRole("ADMIN", "/admin/analyses");
  const { saved } = await searchParams;
  const items = await prisma.marketAnalysis.findMany({ orderBy: { updatedAt: "desc" }, select: { id: true, title: true, instrument: true, timeframe: true, status: true, publishedAt: true, slug: true } });
  return (
    <>
      <AdminHeader title="Market analysis" newHref="/admin/analyses/new" saved={saved === "1"} />
      {items.length === 0 ? <p className="text-muted">No analyses yet.</p> : (
        <ul className="divide-y divide-line border-y border-line">
          {items.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div>
                <p className="font-medium">{a.instrument} {a.timeframe}: {a.title}</p>
                <p className="text-sm text-muted">{a.status}{a.publishedAt ? ` · ${formatEat(a.publishedAt)}` : ""}</p>
              </div>
              <div className="flex gap-4 text-sm">
                <Link className="link-accent" href={`/market-analysis/${a.slug}?preview=1`}>Preview</Link>
                <Link className="link-accent" href={`/admin/analyses/${a.id}`}>Edit</Link>
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
