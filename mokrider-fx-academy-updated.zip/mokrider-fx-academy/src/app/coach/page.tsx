import type { Metadata } from "next";
import { PublicShell } from "@/components/PublicShell";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { Greeting } from "@/components/Greeting";
import { MarketCoach } from "@/components/coach/MarketCoach";
import { getCurrentUser } from "@/lib/session";

export const metadata: Metadata = {
  title: "Market Coach",
  description: "Test your understanding of Gold and EURUSD trading with quick quizzes and an AI coach that asks you questions and marks your explanations.",
  alternates: { canonical: "/coach" },
};

export default async function CoachPage() {
  const user = await getCurrentUser();
  const aiEnabled = Boolean(process.env.ANTHROPIC_API_KEY);

  return (
    <PublicShell>
      <Breadcrumbs trail={[{ label: "Market Coach" }]} />
      {user && <p className="eyebrow mb-3"><Greeting name={user.name} /></p>}
      <h1 className="text-4xl md:text-5xl">Do you really understand <span className="text-accent-text">the market?</span></h1>
      <p className="mt-4 mb-10 max-w-2xl text-muted">
        Answering questions is the quickest way to find the gaps in what you know. Take a quick quiz, or explain an idea in your own words and let the AI coach mark it.
      </p>
      <MarketCoach signedIn={Boolean(user)} aiEnabled={aiEnabled} />
      <p className="mt-12 max-w-2xl text-xs text-muted">
        For learning only. Questions test understanding of concepts. They are not signals, predictions or financial advice, and doing well here does not mean you will trade profitably. Trading carries a high risk of loss.
      </p>
    </PublicShell>
  );
}
