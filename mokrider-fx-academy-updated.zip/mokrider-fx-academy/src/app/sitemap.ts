import type { MetadataRoute } from "next";
import { prisma } from "@/lib/db";
import { visibleWhere } from "@/lib/publishing";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  const fixed = ["", "/learn", "/shop", "/market-analysis", "/mentorship", "/mentorship/apply", "/tools", "/tools/position-size", "/tools/risk-reward", "/tools/compounding", "/tools/pip-calculator", "/tools/session-clock", "/coach", "/blog", "/about", "/contact", "/sponsor", "/stories", "/risk-disclosure"].map((p) => ({ url: `${base}${p}` }));
  try {
    const [courses, articles, analyses, products, packages] = await Promise.all([
      prisma.course.findMany({ where: { status: "PUBLISHED" }, select: { slug: true, updatedAt: true } }),
      prisma.article.findMany({ where: visibleWhere(), select: { slug: true, updatedAt: true } }),
      prisma.marketAnalysis.findMany({ where: visibleWhere(), select: { slug: true, updatedAt: true } }),
      prisma.product.findMany({ where: { status: "PUBLISHED", versions: { some: { isCurrent: true } } }, select: { slug: true, updatedAt: true } }),
      prisma.mentorshipPackage.findMany({ where: { status: "PUBLISHED" }, select: { slug: true } }),
    ]);
    return [
      ...fixed,
      ...courses.map((c) => ({ url: `${base}/learn/${c.slug}`, lastModified: c.updatedAt })),
      ...articles.map((a) => ({ url: `${base}/blog/${a.slug}`, lastModified: a.updatedAt })),
      ...products.map((p) => ({ url: `${base}/shop/${p.slug}`, lastModified: p.updatedAt })),
      ...packages.map((p) => ({ url: `${base}/mentorship/${p.slug}` })),
      ...analyses.map((a) => ({ url: `${base}/market-analysis/${a.slug}`, lastModified: a.updatedAt })),
    ];
  } catch {
    return fixed;
  }
}
