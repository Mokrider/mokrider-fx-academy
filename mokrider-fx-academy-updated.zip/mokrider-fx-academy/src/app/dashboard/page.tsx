import Link from "next/link";
import { Greeting } from "@/components/Greeting";
import { firstName } from "@/lib/names";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { courseProgressFor } from "@/lib/progress";
import { formatMoney } from "@/lib/money";
import { canStudentCancel } from "@/lib/booking/rules";
import { cancelBooking } from "@/app/actions/booking";

function Empty({ text, href, cta }: { text: string; href: string; cta: string }) {
  return (
    <div className="rounded-md border border-dashed border-line p-6">
      <p className="text-sm text-muted">{text}</p>
      <Link href={href} className="btn btn-ghost mt-4">{cta}</Link>
    </div>
  );
}

const CANCEL_ERRORS: Record<string, string> = {
  window: "Cancellations close 24 hours before a session. Please contact us.",
  payment: "A payment for this booking is still being processed. Please wait a few minutes.",
  state: "This booking can no longer be cancelled.",
  notfound: "Booking not found.",
};

export default async function DashboardPage({ searchParams }: { searchParams: Promise<{ booked?: string; cancelled?: string; cancelError?: string }> }) {
  const sp = await searchParams;
  const user = await requireUser("/dashboard");

  // Every query is scoped to the signed-in user's id taken from the server session.
  const [enrollments, productAccess, bookings, orders] = await Promise.all([
    prisma.enrollment.findMany({ where: { userId: user.id }, include: { course: { select: { id: true, title: true, slug: true } } }, orderBy: { createdAt: "desc" } }),
    prisma.entitlement.findMany({ where: { userId: user.id, kind: "PRODUCT", status: "ACTIVE" }, include: { product: { select: { name: true } } } }),
    prisma.booking.findMany({
      where: { userId: user.id, status: { in: ["CONFIRMED", "AWAITING_PAYMENT"] }, slot: { startsAt: { gte: new Date() } } },
      include: { package: { select: { title: true } }, slot: { select: { startsAt: true, meetingUrl: true } }, order: { select: { reference: true } } },
      orderBy: { slot: { startsAt: "asc" } },
      take: 10,
    }),
    prisma.order.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 5 }),
  ]);
  const progress = await courseProgressFor(user.id, enrollments.map((e) => e.courseId));
  const fmtDate = new Intl.DateTimeFormat("en-KE", { dateStyle: "medium", timeStyle: "short", timeZone: "Africa/Nairobi" });

  return (
    <div className="max-w-4xl space-y-12">
      <header>
        <h1 className="text-4xl"><Greeting name={firstName(user.name)} /></h1>
        <p className="mt-2 text-muted">Your courses, purchases and bookings are listed here.</p>
        <div className="mt-5 flex flex-wrap gap-3">
          <Link href="/coach" className="btn btn-ghost">Test your understanding</Link>
          <Link href="/tools/session-clock" className="btn btn-ghost">Which session is open?</Link>
        </div>
      </header>

      <section aria-labelledby="courses-h">
        <h2 id="courses-h" className="mb-4 text-2xl">Your courses</h2>
        {enrollments.length === 0 ? (
          <Empty text="You are not enrolled in any course yet." href="/learn" cta="Browse courses" />
        ) : (
          <ul className="space-y-3">
            {enrollments.map((e) => {
              const p = progress[e.courseId];
              return (
                <li key={e.id} className="rounded-md border border-line bg-card p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="font-semibold">{e.course.title}</p>
                    {p?.nextLessonId ? (
                      <Link href={`/learn/${e.course.slug}/lessons/${p.nextLessonId}`} className="link-accent text-sm">{p.completed > 0 ? "Continue" : "Start"}</Link>
                    ) : (
                      <Link href={`/learn/${e.course.slug}`} className="link-accent text-sm">View course</Link>
                    )}
                  </div>
                  <div className="mt-2 h-2 overflow-hidden rounded bg-surface" role="progressbar" aria-valuenow={p?.percent ?? 0} aria-valuemin={0} aria-valuemax={100} aria-label={`${e.course.title} progress`}>
                    <div className="h-full bg-accent" style={{ width: `${p?.percent ?? 0}%` }} />
                  </div>
                  <p className="mt-1 text-xs text-muted">{p?.completed ?? 0} of {p?.total ?? 0} lessons complete</p>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <section aria-labelledby="products-h">
        <h2 id="products-h" className="mb-4 text-2xl">Your downloads</h2>
        {productAccess.length === 0 ? (
          <Empty text="Products you buy will appear here." href="/shop" cta="Visit the shop" />
        ) : (
          <ul className="space-y-2">{productAccess.map((p) => (
            <li key={p.id} className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-line bg-card p-4">
              <span>{p.product?.name}</span>
              <a href={`/api/downloads/${p.id}`} className="link-accent text-sm">Download</a>
            </li>
          ))}</ul>
        )}
      </section>

      <section aria-labelledby="bookings-h">
        <h2 id="bookings-h" className="mb-4 text-2xl">Upcoming sessions</h2>
        {sp.booked && <p role="status" className="mb-3 rounded-md border border-line bg-surface p-3 text-sm text-up">Your session is booked. A confirmation email is on its way.</p>}
        {sp.cancelled && <p role="status" className="mb-3 rounded-md border border-line bg-surface p-3 text-sm">{sp.cancelled === "refund" ? "Your booking is cancelled. A refund request has been recorded and we will be in touch about it." : "Your booking is cancelled."}</p>}
        {sp.cancelError && <p role="alert" className="mb-3 rounded-md border border-line bg-surface p-3 text-sm text-down">{CANCEL_ERRORS[sp.cancelError] ?? "Could not cancel this booking."}</p>}
        {bookings.length === 0 ? (
          <Empty text="You have no upcoming sessions. Times display in East Africa Time." href="/mentorship" cta="See mentorship" />
        ) : (
          <ul className="space-y-2">
            {bookings.map((b) => {
              const awaiting = b.status === "AWAITING_PAYMENT";
              return (
                <li key={b.id} className="rounded-md border border-line bg-card p-4">
                  <p className="font-semibold">{b.package.title}</p>
                  <p className="text-sm text-muted">{fmtDate.format(b.slot.startsAt)} (EAT) &middot; {awaiting ? "Waiting for payment" : "Confirmed"}</p>
                  {!awaiting && b.slot.meetingUrl && b.slot.meetingUrl.startsWith("https://") && <p className="mt-1 text-sm"><a href={b.slot.meetingUrl} rel="noopener noreferrer" className="link-accent">Join the session</a></p>}
                  <div className="mt-3 flex flex-wrap items-center gap-4 text-sm">
                    {awaiting && b.order && <Link href={`/orders/${b.order.reference}`} className="btn btn-primary !min-h-9">Complete payment</Link>}
                    {awaiting || canStudentCancel(b.slot.startsAt, new Date()) ? (
                      <form action={cancelBooking.bind(null, b.id)}><button type="submit" className="underline">Cancel booking</button></form>
                    ) : <span className="text-xs text-muted">Cancellations closed (less than 24 hours away)</span>}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <section aria-labelledby="orders-h">
        <h2 id="orders-h" className="mb-4 text-2xl">Recent orders</h2>
        <p className="mb-3 text-sm"><Link href="/orders" className="link-accent">See all orders</Link></p>
        {orders.length === 0 ? (
          <p className="text-sm text-muted">No orders yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-muted"><tr><th className="py-2 pr-4">Reference</th><th className="pr-4">Status</th><th className="pr-4">Total</th><th>Date</th></tr></thead>
              <tbody>
                {orders.map((o) => (
                  <tr key={o.id} className="border-t border-line">
                    <td className="py-2 pr-4">{o.reference}</td><td className="pr-4">{o.status}</td>
                    <td className="pr-4">{formatMoney(o.totalMinor, o.currency)}</td><td>{fmtDate.format(o.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
