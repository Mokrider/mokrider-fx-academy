import type { Metadata } from "next";
import Link from "next/link";
import { Logo } from "@/components/Logo";
import { ThemeToggle } from "@/components/ThemeToggle";
import { SignOutButton } from "@/components/SignOutButton";
import { requireUser } from "@/lib/session";

export const metadata: Metadata = { title: "Dashboard", robots: { index: false, follow: false } };

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser("/dashboard");
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[16rem_1fr]">
      <aside className="border-b border-line bg-surface p-4 lg:border-b-0 lg:border-r lg:p-6">
        <div className="flex items-center justify-between lg:block">
          <Logo />
          <div className="lg:hidden"><ThemeToggle /></div>
        </div>
        <nav aria-label="Dashboard" className="mt-4 flex gap-2 overflow-x-auto text-sm lg:mt-8 lg:flex-col">
          <Link href="/dashboard" className="rounded px-3 py-2 bg-card text-fg" aria-current="page">Overview</Link>
          <Link href="/learn" className="rounded px-3 py-2 text-muted hover:text-fg">Browse courses</Link>
          <Link href="/tools/journal" className="rounded px-3 py-2 text-muted hover:text-fg">Trading journal</Link>
          <Link href="/tools" className="rounded px-3 py-2 text-muted hover:text-fg">Trading tools</Link>
          <Link href="/" className="rounded px-3 py-2 text-muted hover:text-fg">Public site</Link>
        </nav>
        <div className="mt-6 hidden space-y-3 lg:block">
          <p className="truncate text-sm text-muted">{user.email}</p>
          <ThemeToggle />
          <SignOutButton className="btn btn-ghost w-full" />
        </div>
        <div className="mt-4 lg:hidden"><SignOutButton /></div>
      </aside>
      <main className="p-5 lg:p-10">{children}</main>
    </div>
  );
}
