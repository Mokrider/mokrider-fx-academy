import type { Metadata } from "next";
import { Clock, Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { PublicShell } from "@/components/PublicShell";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { ContactTrigger } from "@/components/ContactTrigger";
import { getContact, whatsappUrl } from "@/lib/contact";

export const metadata: Metadata = {
  title: "Contact",
  description: "Email or WhatsApp MOKRIDER FX ACADEMY about courses, mentorship and the shop.",
  alternates: { canonical: "/contact" },
};

const topics = [
  { label: "A course", subject: "Question about a course", body: "Hello,\n\nI would like to know more about:\n\nCourse I am interested in:\nMy trading experience (none is fine):\n\nMy name:\n\nThank you." },
  { label: "Mentorship", subject: "Question about mentorship", body: "Hello,\n\nI would like to ask about mentorship.\n\nWhat I want to work on:\nMy trading experience (none is fine):\nWhen I am free (East Africa Time):\n\nMy name:\n\nThank you." },
  { label: "An order or payment", subject: "Help with an order", body: "Hello,\n\nI need help with an order.\n\nOrder reference:\nPhone number used for M-Pesa:\nWhat went wrong:\n\nThank you." },
];

const faqs = [
  ["How quickly do you reply?", "We reply during the hours shown here. Messages sent outside them are answered on the next working day."],
  ["Can I ask before I sign up?", "Yes. Ask anything about the courses, the mentorship or how payment works. No account is needed to send a message."],
  ["Do you give trade signals?", "Not as a standalone product. A fully sponsored seat includes the academy\u2019s signals channel. Signals are educational trade ideas, not personal advice, and never a promise of profit. You make every trade decision and carry its risk."],
];

export default function ContactPage() {
  const c = getContact();
  const wa = whatsappUrl(c.whatsapp, "Hello, I would like to ask about MOKRIDER FX ACADEMY.");
  const hasAny = c.email || c.phone || wa;

  return (
    <PublicShell>
      <Breadcrumbs trail={[{ label: "Contact" }]} />
      <h1 className="text-4xl md:text-5xl">Talk to <span className="text-accent-text">a person.</span></h1>
      <p className="mt-4 max-w-2xl text-muted">Choose how you would like to reach us. Email and WhatsApp open with the first lines already written, so you only need to fill in the blanks.</p>

      {!hasAny && <p className="mt-8 rounded-md border border-dashed border-line p-6 text-muted">Contact details have not been set up yet.</p>}

      <div className="mt-10 grid gap-10 md:grid-cols-[1.2fr_1fr]">
        <section aria-labelledby="topics-heading">
          <h2 id="topics-heading" className="text-2xl">What is it about?</h2>
          <ul className="mt-5 grid gap-3 sm:grid-cols-3 md:grid-cols-1 lg:grid-cols-3">
            {topics.map((t) => (
              <li key={t.label}>
                {c.email ? (
                  <ContactTrigger message={{ subject: t.subject, body: t.body }} className="btn btn-ghost w-full">{t.label}</ContactTrigger>
                ) : (
                  <span className="btn btn-ghost w-full opacity-60">{t.label}</span>
                )}
              </li>
            ))}
          </ul>
          <div className="mt-6 flex flex-wrap gap-3">
            {c.email && <ContactTrigger className="btn btn-primary"><Mail size={16} aria-hidden /> Email us</ContactTrigger>}
            {wa && <a className="btn btn-ghost" href={wa} target="_blank" rel="noopener noreferrer"><MessageCircle size={16} aria-hidden /> WhatsApp</a>}
          </div>
        </section>

        <aside aria-label="Contact details" className="bg-card space-y-4 border border-line p-6 text-sm">
          {c.email && <p className="flex items-center gap-3"><Mail size={18} className="text-accent-text" aria-hidden /> <a className="link-accent" href={`mailto:${c.email}`}>{c.email}</a></p>}
          {c.phone && <p className="flex items-center gap-3"><Phone size={18} className="text-accent-text" aria-hidden /> <a className="link-accent" href={`tel:${c.phone}`}>{c.phone}</a></p>}
          {c.location && <p className="flex items-center gap-3"><MapPin size={18} className="text-accent-text" aria-hidden /> {c.location}</p>}
          {c.hours && <p className="flex items-center gap-3"><Clock size={18} className="text-accent-text" aria-hidden /> {c.hours}</p>}
          <p className="border-t border-line pt-4 text-xs text-muted">Times are East Africa Time (Africa/Nairobi). We never ask for your M-Pesa PIN, password or broker login.</p>
        </aside>
      </div>

      <section className="mt-16" aria-labelledby="contact-faq">
        <h2 id="contact-faq" className="text-2xl">Before you write</h2>
        <div className="faq mt-6 divide-y divide-line border-y border-line">
          {faqs.map(([q, a]) => (
            <details key={q} className="py-4">
              <summary className="cursor-pointer list-none text-lg font-semibold">{q}</summary>
              <p className="mt-2 max-w-2xl text-muted">{a}</p>
            </details>
          ))}
        </div>
      </section>
    </PublicShell>
  );
}
