import { createHash, timingSafeEqual } from "node:crypto";
import { prisma } from "@/lib/db";
import { cancelBookingFor } from "@/lib/booking/engine";
import { REMINDER_WINDOW_MS } from "@/lib/booking/rules";
import { sendBookingReminderEmail } from "@/lib/commerce/notify";

export const dynamic = "force-dynamic";
const digest = (s: string) => createHash("sha256").update(s).digest();

/**
 * Daily job (see vercel.json). Vercel sends "Authorization: Bearer <CRON_SECRET>".
 * 1. Emails a reminder for confirmed sessions starting within 36 hours.
 * 2. Cancels unpaid bookings left waiting for more than 24 hours (never ones with a payment in progress).
 */
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return new Response("CRON_SECRET is not set", { status: 503 });
  const given = (req.headers.get("authorization") ?? "").replace(/^Bearer /, "");
  if (!timingSafeEqual(digest(given), digest(secret))) return new Response("Not found", { status: 404 });

  const now = new Date();
  const due = await prisma.booking.findMany({
    where: { status: "CONFIRMED", reminderSentAt: null, slot: { startsAt: { gt: now, lte: new Date(now.getTime() + REMINDER_WINDOW_MS) } } },
    select: { id: true }, take: 100,
  });
  let reminders = 0;
  for (const b of due) {
    const r = await sendBookingReminderEmail(b.id);
    if (r.status !== "failed") {
      await prisma.booking.update({ where: { id: b.id }, data: { reminderSentAt: new Date() } });
      reminders++;
    }
  }

  const stale = await prisma.booking.findMany({
    where: { status: "AWAITING_PAYMENT", createdAt: { lt: new Date(now.getTime() - 24 * 3600 * 1000) } },
    select: { id: true }, take: 100,
  });
  let expired = 0;
  for (const b of stale) {
    const r = await cancelBookingFor({ id: "system", admin: true }, b.id);
    if (r.ok) expired++;
  }
  await prisma.rateLimitHit.deleteMany({ where: { createdAt: { lt: new Date(now.getTime() - 24 * 3600 * 1000) } } });
  return Response.json({ reminders, expired });
}
