import { prisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { reconcilePayment } from "@/lib/commerce/payments";

export const dynamic = "force-dynamic";

const lastCheck = new Map<string, number>(); // soft per-instance throttle so polling cannot hammer Safaricom

export async function GET(_req: Request, { params }: { params: Promise<{ reference: string }> }) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "Sign in required" }, { status: 401 });
  const { reference } = await params;

  const load = () => prisma.order.findFirst({ where: { reference, userId: user.id }, include: { payments: { orderBy: { createdAt: "desc" }, take: 1 } } });
  let order = await load();
  if (!order) return Response.json({ error: "Not found" }, { status: 404 });

  const pay = order.payments[0];
  if (pay && (pay.status === "INITIATED" || pay.status === "PENDING") && Date.now() - (lastCheck.get(pay.id) ?? 0) > 5000) {
    lastCheck.set(pay.id, Date.now());
    await reconcilePayment(pay.id);
    order = (await load()) ?? order;
  }
  const latest = order.payments[0];
  return Response.json({ status: order.status, paymentStatus: latest?.status ?? null, receipt: latest?.providerReceipt ?? null }, { headers: { "Cache-Control": "no-store" } });
}
