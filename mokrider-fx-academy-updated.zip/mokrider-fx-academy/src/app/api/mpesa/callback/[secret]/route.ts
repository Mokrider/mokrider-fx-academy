import { createHash, timingSafeEqual } from "node:crypto";
import { prisma } from "@/lib/db";
import { parseStkCallback } from "@/lib/mpesa/parse";
import { reconcilePayment } from "@/lib/commerce/payments";

export const dynamic = "force-dynamic";

const accepted = () => Response.json({ ResultCode: 0, ResultDesc: "Accepted" });
const digest = (s: string) => createHash("sha256").update(s).digest();

/**
 * Safaricom does not sign callbacks, so this endpoint has two protections:
 * 1. The URL contains a long secret; anything else gets a 404.
 * 2. The callback only triggers a check. Access is granted only after Safaricom's own
 *    STK Query API confirms the result (see reconcilePayment).
 */
export async function POST(req: Request, { params }: { params: Promise<{ secret: string }> }) {
  const { secret } = await params;
  const expected = process.env.MPESA_CALLBACK_SECRET ?? "";
  if (!expected || !timingSafeEqual(digest(secret), digest(expected))) return new Response("Not found", { status: 404 });

  let body: unknown;
  try { body = await req.json(); } catch { return accepted(); }
  const cb = parseStkCallback(body);
  if (!cb) return accepted();

  const payment = await prisma.payment.findUnique({ where: { provider_providerRef: { provider: "MPESA", providerRef: cb.checkoutRequestId } } });
  if (!payment) return accepted();

  try {
    await prisma.paymentEvent.create({
      data: {
        paymentId: payment.id, provider: "MPESA", eventKey: `${cb.checkoutRequestId}:${cb.resultCode}`,
        payload: { resultCode: cb.resultCode, resultDesc: cb.resultDesc, amount: cb.amount, receipt: cb.receipt, transactionDate: cb.transactionDate },
      },
    });
  } catch {
    // Duplicate delivery of the same event. Safe to continue: settling is idempotent.
  }
  try {
    await reconcilePayment(payment.id, { receipt: cb.receipt, amountShillings: cb.amount });
  } catch (e) {
    console.error("mpesa callback reconcile failed", e instanceof Error ? e.message : "unknown");
  }
  return accepted();
}
