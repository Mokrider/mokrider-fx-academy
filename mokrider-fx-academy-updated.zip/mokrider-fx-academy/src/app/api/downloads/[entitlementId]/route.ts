import { prisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { signedDownloadUrl } from "@/lib/storage";

export const dynamic = "force-dynamic";

/**
 * Secure download. The entitlement must belong to the signed-in user (the user id comes from the
 * server session), be active and unexpired. The file is never public: we redirect to a signed
 * storage URL that expires in about a minute.
 */
export async function GET(req: Request, { params }: { params: Promise<{ entitlementId: string }> }) {
  const { entitlementId } = await params;
  const user = await getCurrentUser();
  if (!user) return new Response(null, { status: 302, headers: { Location: new URL("/login?next=/orders", req.url).toString() } });

  const ent = await prisma.entitlement.findFirst({
    where: { id: entitlementId, userId: user.id, kind: "PRODUCT", status: "ACTIVE", OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] },
    include: { product: { include: { versions: { where: { isCurrent: true }, take: 1 } } } },
  });
  const product = ent?.product;
  const version = product?.versions[0];
  if (!ent || !product || !version) return new Response("Not found", { status: 404 });

  const ext = version.mimeType === "application/pdf" ? "pdf" : (version.storageKey.split(".").pop() ?? "bin");
  const url = await signedDownloadUrl(version.storageKey, `${product.slug}-v${version.version}.${ext}`, 60);
  if (!url) return new Response("Downloads are temporarily unavailable. Please try again soon.", { status: 503 });

  const allowed = await prisma.$transaction(async (tx) => {
    if (product.downloadLimit !== null) {
      const used = await tx.downloadRecord.count({ where: { entitlementId: ent.id } });
      if (used >= product.downloadLimit) return false;
    }
    await tx.downloadRecord.create({ data: { userId: user.id, entitlementId: ent.id, productVersionId: version.id } });
    return true;
  });
  if (!allowed) return new Response("You have reached the download limit for this product. Contact support if you need another copy.", { status: 403 });

  return new Response(null, { status: 302, headers: { Location: url, "Cache-Control": "no-store" } });
}
