import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/session";
import { allow } from "@/lib/security/rateLimit";
import { TOPICS } from "@/content/coach/questions";
import { SYSTEM_PROMPT, buildAskPrompt, buildGradePrompt, parseAsk, parseGrade, requestSchema } from "@/lib/coach/ai";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const HOURLY_LIMIT = 30;

function fail(status: number, error: string) {
  return NextResponse.json({ error }, { status, headers: { "Cache-Control": "no-store" } });
}

async function callClaude(prompt: string): Promise<string | null> {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return null;
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
        max_tokens: 700,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: prompt }],
      }),
      signal: AbortSignal.timeout(25_000),
    });
    if (!res.ok) {
      console.error("coach: model request failed with status", res.status);
      return null;
    }
    const data = (await res.json()) as { content?: { type: string; text?: string }[] };
    return data.content?.find((b) => b.type === "text")?.text ?? null;
  } catch (e) {
    console.error("coach: model request error", e instanceof Error ? e.message : e);
    return null;
  }
}

export async function POST(req: Request) {
  if (!process.env.ANTHROPIC_API_KEY) return fail(503, "The AI coach is not switched on yet.");

  // Only signed-in students can use it, so the key cannot be drained by strangers.
  const user = await getCurrentUser();
  if (!user) return fail(401, "Please sign in to use the AI coach.");

  const raw = await req.text();
  if (raw.length > 6000) return fail(413, "That request is too large.");
  let json: unknown;
  try {
    json = JSON.parse(raw);
  } catch {
    return fail(400, "That request could not be read.");
  }
  const parsed = requestSchema.safeParse(json);
  if (!parsed.success) return fail(400, parsed.error.issues[0]?.message ?? "That request could not be read.");
  const body = parsed.data;

  const topicLabel = TOPICS.find((t) => t.id === body.topic)?.label;
  if (!topicLabel) return fail(400, "Unknown topic.");

  if (!(await allow(`coach-ai:${user.id}`, HOURLY_LIMIT, 3600))) {
    return fail(429, "You have used the AI coach a lot this hour. Take a short break, or practise with the quiz.");
  }

  if (body.mode === "ask") {
    const text = await callClaude(buildAskPrompt(topicLabel, body.level, body.avoid));
    const reply = text ? parseAsk(text) : null;
    if (!reply) return fail(502, "The coach could not write a question just now. Please try again.");
    return NextResponse.json(reply, { headers: { "Cache-Control": "no-store" } });
  }

  const text = await callClaude(buildGradePrompt(topicLabel, body.level, body.question, body.answer));
  const reply = text ? parseGrade(text) : null;
  if (!reply) return fail(502, "The coach could not mark that just now. Please try again.");
  return NextResponse.json(reply, { headers: { "Cache-Control": "no-store" } });
}
