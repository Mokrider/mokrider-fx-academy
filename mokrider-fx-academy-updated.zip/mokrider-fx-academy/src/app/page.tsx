import Link from "next/link";
import { BarChart3, BookOpen, ChevronRight, CirclePlay, ClipboardList, GraduationCap, LineChart, ShieldCheck, ShoppingBag, TrendingUp, Users } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { HeroVisual } from "@/components/HeroVisual";
import { NewsletterForm } from "@/components/NewsletterForm";
import { ContactTrigger } from "@/components/ContactTrigger";
import { NEWSLETTER_CONSENT_TEXT } from "@/content/consent";
import { curriculum } from "@/content/curriculum";
import { LatestContent } from "@/components/LatestContent";
import { StatusPanel } from "@/components/StatusPanel";
import { SessionClock } from "@/components/calc/SessionClock";
import { FactsStrip } from "@/components/FactsStrip";
import { SessionGallery } from "@/components/SessionGallery";
import { getContact, whatsappUrl } from "@/lib/contact";
import { getCurrentUser } from "@/lib/session";
import { Greeting } from "@/components/Greeting";
import { firstName } from "@/lib/names";

const levelLabel = { BEGINNER: "Beginner", INTERMEDIATE: "Intermediate", ADVANCED: "Advanced" } as const;

// Three doors into the academy, shown straight under the hero.
const doors = [
  { icon: GraduationCap, title: "Courses", text: "Self-paced lessons that start with risk, then structure, then trade planning. Your progress is saved.", badges: ["Self-paced", "Progress saved"], href: "/learn", cta: "See the courses" },
  { icon: ClipboardList, title: "Journal and tools", text: "Calculators that show their formula, plus a private journal that turns your trades into your own statistics.", badges: ["Private journal", "Formulas shown"], href: "/tools", cta: "Open the tools" },
  { icon: Users, title: "Mentorship", text: "One-to-one sessions built around your plan and your journal. Session times shown in East Africa Time.", badges: ["1-on-1", "Group classes"], href: "/mentorship", cta: "Find a mentor" },
];

const services = [
  { icon: GraduationCap, title: "Courses", text: "Seven courses mapped from first chart to a repeatable routine." },
  { icon: Users, title: "Mentorship", text: "Individual sessions, group classes and chart reviews, with your own journal as the starting point." },
  { icon: LineChart, title: "Market analysis", text: "Time-stamped, educational write-ups with scenarios and invalidation. Never a signal, never live." },
  { icon: BarChart3, title: "Trading tools", text: "Position size, risk/reward, pips, compounding and a session clock, each showing its working." },
  { icon: BookOpen, title: "Trading journal", text: "Record trades privately and review per-currency statistics. Your data stays yours." },
  { icon: ShoppingBag, title: "Shop", text: "Digital study resources with secure downloads, paid for by M-Pesa once checkout opens." },
];

const steps = [
  ["Learn it", "Start with how markets and quotes work, then structure and liquidity, always with their limits."],
  ["Plan it", "Decide how much you can lose and where the idea is wrong before you look at an entry."],
  ["Journal it", "Log each trade with your reasons, your risk and the result. Wins and losses go in the same book."],
  ["Review it", "Read your own statistics, find the habit that costs you, and bring it to a mentor."],
];

const tools = [
  ["Position-size calculator", "Turn a risk percentage and a stop distance into a position size, with the assumptions shown."],
  ["Risk/reward calculator", "See risk, reward and ratio for a planned trade before you take it."],
  ["Compounding calculator", "Explore a hypothetical growth scenario. It is arithmetic, not a forecast."],
  ["Trading journal", "Record trades privately and review your own statistics."],
  ["Session clock", "London, New York and Nairobi times with daylight-saving handled correctly."],
  ["Economic calendar", "Scheduled releases. Not connected yet: it needs a licensed data source, and nothing is invented in the meantime."],
];

const packages = [
  ["Individual mentorship", "One-to-one sessions built around your trading plan, journal and risk rules."],
  ["Group classes", "Live lessons on structure, liquidity and trade planning with questions answered."],
  ["Chart review", "Bring your own charts and trades for a focused written or live review."],
];

const faqs = [
  ["Who can join?", "Anyone. There is no qualification to show and no experience needed. Introduction to Trading starts from how markets and quotes work."],
  ["Do you promise profits?", "No. Trading carries a high risk of loss, and nothing on this site guarantees results. We teach process, analysis and risk management."],
  ["Which markets do you teach?", "XAUUSD (Gold) and EURUSD to begin with. The platform is built so more instruments can be added later."],
  ["Is it online or in person?", "Courses are online and self-paced. Mentorship sessions are booked as time slots shown in East Africa Time."],
  ["Can I pay with M-Pesa?", "M-Pesa is the first payment method being built for the shop and bookings. It is not live yet, so purchases are not open."],
  ["Is the market analysis live?", "No. Published analysis is educational, shows its publication time, and is never presented as a live feed or a signal."],
  ["Do I need to open a broker account?", "Not to learn. The lessons and calculators work without one. We do not tell you which broker to use."],
  ["How do I reach you?", "Use the email or WhatsApp buttons on this page. Both open with the first lines already written."],
];

export default async function HomePage() {
  const user = await getCurrentUser();
  const c = getContact();
  const wa = whatsappUrl(c.whatsapp, "Hello, I would like to ask about MOKRIDER FX ACADEMY.");

  return (
    <>
      <SiteHeader />
      <main id="main">
        {user && (
          <section className="border-b border-line bg-surface" aria-label="Welcome back">
            <div className="container-page flex flex-wrap items-center justify-between gap-4 py-4">
              <p className="font-display text-xl"><Greeting name={firstName(user.name)} /> <span aria-hidden>&#128075;</span></p>
              <div className="flex flex-wrap gap-2">
                <Link href="/dashboard" className="btn btn-primary">Continue learning</Link>
                <Link href="/coach" className="btn btn-ghost">Test yourself</Link>
                <Link href="/tools/session-clock" className="btn btn-ghost">Session timer</Link>
              </div>
            </div>
          </section>
        )}
        <section className="hero-bg">
          <div className="container-page grid items-center gap-12 py-16 md:py-24 lg:grid-cols-[1fr_1.05fr]">
            <div>
              <p className="eyebrow mb-5">Gold &middot; EURUSD &middot; Nairobi</p>
              <h1 className="text-4xl sm:text-5xl md:text-6xl">
                <span className="chrome">Learn the</span> <span className="text-accent-text">Market.</span>
                <span className="font-script mt-3 block text-4xl text-fg sm:text-5xl md:text-6xl">Master your process.</span>
              </h1>
              <p className="mt-6 max-w-lg text-lg text-muted">
                Structured Gold and EURUSD education that starts with risk. Learn it, journal it, then prove it to yourself with your own record, without promises of profit.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/learn" className="btn btn-primary">Become a student <ChevronRight size={18} aria-hidden /></Link>
                <Link href="/mentorship" className="btn btn-ghost">Find a mentor</Link>
                <Link href="/mentorship/apply" className="btn btn-ghost">Apply for 1-on-1</Link>
              </div>
              <ul className="mt-8 flex flex-wrap gap-2" aria-label="Our three pillars">
                {["Risk", "Structure", "Process"].map((p) => <li key={p}><span className="chip">{p}</span></li>)}
              </ul>
            </div>
            <HeroVisual />
          </div>
        </section>

        <section className="border-y border-line bg-surface" aria-label="What you get">
          <ul className="container-page grid gap-4 py-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              [TrendingUp, "Expert mentorship"],
              [BookOpen, "Trading strategies"],
              [CirclePlay, "Market analysis"],
              [ShieldCheck, "Risk management"],
            ].map(([Icon, label]) => {
              const I = Icon as typeof TrendingUp;
              return (
                <li key={label as string} className="flex items-center gap-3 text-sm font-semibold">
                  <I size={26} className="shrink-0 text-accent-text" aria-hidden />
                  <span>{label as string}</span>
                </li>
              );
            })}
          </ul>
        </section>

        <section className="border-b border-line bg-surface">
          <p className="container-page py-4 text-sm text-muted">
            Educational content only, not financial advice. Trading carries a high risk of loss.{" "}
            <Link href="/risk-disclosure" className="link-accent">Read the risk disclosure</Link>.
          </p>
        </section>

        <FactsStrip />

        <section className="container-page py-16" aria-label="Where to start">
          <ul className="grid gap-6 md:grid-cols-3">
            {doors.map((d) => {
              const I = d.icon;
              return (
                <li key={d.title} className="bg-card flex flex-col border border-line p-6">
                  <I size={28} className="text-accent-text" aria-hidden />
                  <h2 className="mt-4 text-2xl">{d.title}</h2>
                  <p className="mt-2 flex-1 text-sm text-muted">{d.text}</p>
                  <ul className="mt-4 flex flex-wrap gap-2">{d.badges.map((b) => <li key={b}><span className="chip !min-h-7 !px-3 !text-xs">{b}</span></li>)}</ul>
                  <Link href={d.href} className="btn btn-ghost mt-5 self-start">{d.cta}</Link>
                </li>
              );
            })}
          </ul>
        </section>

        <section className="bg-surface py-20" aria-labelledby="do-heading">
          <div className="container-page">
            <h2 id="do-heading" className="text-3xl md:text-4xl">What we do</h2>
            <p className="mt-3 max-w-2xl text-muted">Everything is built around one idea: your decisions should leave a record you can check.</p>
            <ul className="mt-10 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
              {services.map((s) => {
                const I = s.icon;
                return (
                  <li key={s.title} className="border-t-2 border-accent pt-4">
                    <I size={24} className="text-accent-text" aria-hidden />
                    <h3 className="mt-3 text-xl">{s.title}</h3>
                    <p className="mt-2 text-sm text-muted">{s.text}</p>
                  </li>
                );
              })}
            </ul>
          </div>
        </section>

        <StatusPanel />

        <section className="bg-surface py-20" aria-labelledby="works-heading">
          <div className="container-page grid gap-12 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <h2 id="works-heading" className="text-3xl md:text-4xl">How learning works</h2>
              <p className="mt-3 max-w-xl text-muted">Four steps, repeated. The record you build is the proof that you are improving, to you and to your mentor.</p>
              <ol className="mt-10 space-y-6">
                {steps.map(([title, text], i) => (
                  <li key={title} className="flex gap-4">
                    <span className="step-num" aria-hidden>{i + 1}</span>
                    <div>
                      <h3 className="text-xl">{title}</h3>
                      <p className="mt-1 text-sm text-muted">{text}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>
            <figure className="bg-card self-start border border-line p-6" aria-label="Sample journal preview">
              <figcaption className="text-xs font-semibold uppercase tracking-widest text-muted">Journal preview &middot; sample data only</figcaption>
              <dl className="mt-5 grid grid-cols-3 gap-4 text-center">
                <div><dt className="text-xs text-muted">Trades logged</dt><dd className="font-display text-2xl">24</dd></div>
                <div><dt className="text-xs text-muted">Followed plan</dt><dd className="font-display text-2xl">79%</dd></div>
                <div><dt className="text-xs text-muted">Avg risk</dt><dd className="font-display text-2xl">1.0%</dd></div>
              </dl>
              <svg viewBox="0 0 300 90" className="mt-6 w-full" role="img" aria-label="Sample chart of plan adherence over six weeks, rising">
                {[28, 40, 36, 52, 61, 70].map((h, i) => (
                  <rect key={i} x={12 + i * 48} y={80 - h} width="30" height={h} rx="3" fill={i === 5 ? "var(--accent)" : "var(--border)"} />
                ))}
              </svg>
              <p className="mt-3 text-xs text-muted">Made-up numbers to show the layout. They are not results, and your journal only ever shows your own trades.</p>
            </figure>
          </div>
        </section>

        <section className="container-page py-20" aria-labelledby="learn-heading">
          <h2 id="learn-heading" className="text-3xl md:text-4xl">Seven courses, from first chart to repeatable routine</h2>
          <p className="mt-3 max-w-2xl text-muted">
            The curriculum below is an outline. Lessons are still being written, and a course goes on sale only once its content is ready.
          </p>
          <ul className="mt-10 divide-y divide-line border-y border-line">
            {curriculum.map((c2) => (
              <li key={c2.slug} className="grid gap-2 py-5 md:grid-cols-[1.1fr_1.6fr_auto] md:items-baseline md:gap-8">
                <h3 className="text-xl">{c2.title}</h3>
                <p className="text-sm text-muted">{c2.summary}</p>
                <p className="text-sm text-accent-text">{levelLabel[c2.level]} &middot; outline</p>
              </li>
            ))}
          </ul>
        </section>

        <section className="bg-surface py-20" aria-labelledby="tools-heading">
          <div className="container-page">
            <h2 id="tools-heading" className="text-3xl md:text-4xl">Tools that show their working</h2>
            <p className="mt-3 max-w-2xl text-muted">Each calculator states its formula and its limits. The calculators, session clock and journal are ready to use.</p>
            <Link href="/tools" className="btn btn-ghost mt-6">Open the tools</Link>
            <dl className="mt-10 grid gap-x-12 gap-y-8 md:grid-cols-2">
              {tools.map(([name, text]) => (
                <div key={name}>
                  <dt className="text-lg font-semibold">{name}</dt>
                  <dd className="mt-1 text-sm text-muted">{text}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>

        <section className="bg-surface py-20" aria-labelledby="coach-heading">
          <div className="container-page grid items-start gap-12 lg:grid-cols-[1fr_1.15fr]">
            <div>
              <h2 id="coach-heading" className="text-3xl md:text-4xl">Do you really understand the market?</h2>
              <p className="mt-3 max-w-lg text-muted">Answer quick questions on risk, structure, liquidity, Gold and EURUSD and see why each answer is right. Or explain an idea in your own words and let the AI coach mark it.</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link href="/coach" className="btn btn-primary">Test yourself</Link>
                <Link href="/tools/session-clock" className="btn btn-ghost">Session timer</Link>
              </div>
              <p className="mt-6 max-w-lg text-sm text-muted">The timer shows your own local time and counts down to the next session open or close, with a note on what each session is usually like.</p>
            </div>
            <div className="bg-card border border-line p-5 sm:p-6"><SessionClock compact /></div>
          </div>
        </section>

        <LatestContent />

        <section className="container-page py-20" aria-labelledby="mentor-heading">
          <h2 id="mentor-heading" className="text-3xl md:text-4xl">Learn with a mentor</h2>
          <p className="mt-3 max-w-2xl text-muted">Booking opens once schedules and payments are configured. Session times will display in East Africa Time.</p>
          <div className="mt-10 grid gap-8 md:grid-cols-3">
            {packages.map(([name, text]) => (
              <div key={name} className="border-t-2 border-accent pt-4">
                <h3 className="text-xl">{name}</h3>
                <p className="mt-2 text-sm text-muted">{text}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 flex flex-wrap items-center gap-3">
            <Link href="/mentorship" className="btn btn-ghost">See mentorship plans</Link>
            <p className="text-sm text-muted">Not sure which route fits? <Link href="/contact" className="link-accent">Tell us where you are and we will point you to one.</Link></p>
          </div>
        </section>

        <section className="bg-surface py-20" aria-labelledby="approach-heading">
          <div className="container-page grid gap-10 md:grid-cols-[1fr_1.4fr]">
            <h2 id="approach-heading" className="text-3xl md:text-4xl">How we teach</h2>
            <div className="space-y-4 text-muted">
              <p>Every lesson starts with what can go wrong. You decide how much you can lose, where an idea is wrong and when not to trade, then you learn to read the chart.</p>
              <p>Concepts such as liquidity, fair value gaps and order blocks are taught as ways to describe price, with their limits, not as rules that always work.</p>
              <p>The mentor&apos;s profile, background and teaching approach are added from the admin dashboard once supplied.</p>
              <Link href="/about" className="link-accent inline-block">About the mentor</Link>
            </div>
          </div>
        </section>

        <SessionGallery />

        <section className="bg-surface py-20" aria-labelledby="sponsor-heading">
          <div className="container-page grid items-center gap-8 md:grid-cols-[1.4fr_1fr]">
            <div>
              <h2 id="sponsor-heading" className="text-3xl md:text-4xl">Sponsor a student</h2>
              <p className="mt-3 max-w-xl text-muted">USD 100 pays for one student to learn everything the academy teaches. Graduates, friends and businesses can all help, and sponsored seats go to students who have earned them.</p>
            </div>
            <div className="flex flex-wrap gap-3 md:justify-end">
              <Link href="/sponsor" className="btn btn-primary">See how it works</Link>
            </div>
          </div>
        </section>

        <section className="container-page py-20" aria-labelledby="stories-heading">
          <h2 id="stories-heading" className="text-3xl md:text-4xl">Honest stories, not testimonials we wrote</h2>
          <p className="mt-3 max-w-2xl text-muted">
            We publish a student&apos;s account only with their written permission, and we include what could have been better. If you have studied with us, your account helps the next person decide.
          </p>
          <Link href="/stories" className="btn btn-ghost mt-6">Read and share stories</Link>
        </section>

        <section className="container-page pb-20" aria-labelledby="news-heading">
          <h2 id="news-heading" className="text-3xl md:text-4xl">Get new lessons by email</h2>
          <p className="mb-6 mt-3 max-w-xl text-muted">Occasional educational emails. No spam, and you can unsubscribe whenever you like.</p>
          <NewsletterForm consentText={NEWSLETTER_CONSENT_TEXT} />
        </section>

        <section className="container-page pb-4" aria-labelledby="faq-heading">
          <h2 id="faq-heading" className="text-3xl md:text-4xl">Questions</h2>
          <div className="faq mt-8 divide-y divide-line border-y border-line">
            {faqs.map(([q, a]) => (
              <details key={q} className="py-4">
                <summary className="cursor-pointer list-none text-lg font-semibold">{q}</summary>
                <p className="mt-2 max-w-2xl text-muted">{a}</p>
              </details>
            ))}
          </div>
        </section>

        <section className="hero-bg mt-20" aria-labelledby="cta-heading">
          <div className="container-page py-16 text-center">
            <h2 id="cta-heading" className="text-3xl md:text-4xl">Ready to start learning?</h2>
            <p className="mx-auto mt-3 max-w-xl text-muted">Begin with the first course, or send us a message first. No account is needed to ask a question.</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link href="/learn" className="btn btn-primary">See the courses</Link>
              {c.email && (
                <ContactTrigger
                  className="btn btn-ghost"
                  message={{ subject: "Question about courses", body: "Hello,\n\nI would like to know more about:\n\nMy trading experience (none is fine):\n\nMy name:\n\nThank you." }}
                >
                  Email us
                </ContactTrigger>
              )}
              {wa && <a className="btn btn-ghost" href={wa} target="_blank" rel="noopener noreferrer">WhatsApp us</a>}
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
