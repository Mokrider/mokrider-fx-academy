import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { formatMoney } from "@/lib/money";
import { formatEat } from "@/lib/time";
import { getCurrentUser } from "@/lib/session";
import { openSlots } from "@/lib/booking/slots";
import { BOOKING_ERRORS, type BookingErrorCode } from "@/lib/booking/rules";
import { bookSlot } from "@/app/actions/booking";

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ e?: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const p = await prisma.mentorshipPackage.findFirst({ where: { slug, status: "PUBLISHED" }, select: { title: true, description: true } });
  if (!p) return { title: "Mentorship" };
  return { title: p.title, description: p.description.slice(0, 160), alternates: { canonical: `/mentorship/${slug}` } };
}

const dayFmt = new Intl.DateTimeFormat("en-GB", { timeZone: "Africa/Nairobi", weekday: "long", day: "numeric", month: "long", year: "numeric" });
const timeFmt = new Intl.DateTimeFormat("en-GB", { timeZone: "Africa/Nairobi", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });

export default async function PackagePage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { e } = await searchParams;
  const p = await prisma.mentorshipPackage.findFirst({ where: { slug, status: "PUBLISHED" } });
  if (!p) notFound();
  const user = await getCurrentUser();
  const slots = await openSlots([p.id]);
  const error = e && e in BOOKING_ERRORS ? BOOKING_ERRORS[e as BookingErrorCode] : null;

  const days = new Map<string, typeof slots>();
  for (const s of slots) {
    const key = dayFmt.format(s.startsAt);
    days.set(key, [...(days.get(key) ?? []), s]);
  }

  return (
    <PublicShell>
      <Link href="/mentorship" className="link-accent text-sm">All packages</Link>
      <h1 className="mt-4 text-4xl md:text-5xl">{p.title}</h1>
      <p className="mt-2 text-sm text-accent-text">{p.durationMinutes} min &middot; {p.deliveryMethod} &middot; {p.priceMinor === 0 ? "Free" : formatMoney(p.priceMinor, p.currency)}</p>
      <p className="mt-4 max-w-2xl text-muted">{p.description}</p>
      {p.sessionCount > 1 && <p className="mt-4 max-w-2xl rounded-md border border-line bg-surface p-4 text-sm">This package includes {p.sessionCount} sessions. Booking here reserves the first one, and the remaining sessions are scheduled with your mentor.</p>}
      {p.cancellationPolicy && <p className="mt-4 max-w-2xl text-sm text-muted">Cancellation and refunds: {p.cancellationPolicy}</p>}
      <p className="mt-2 max-w-2xl text-xs text-muted">You can cancel up to 24 hours before a session. Bookings close 2 hours before it starts. Times are East Africa Time.</p>

      {error && <p role="alert" className="mt-6 max-w-2xl rounded-md border border-line bg-surface p-4 text-sm text-down">{error}</p>}

      <h2 className="mt-12 text-2xl">Available sessions</h2>
      {slots.length === 0 ? (
        <div className="mt-4 rounded-md border border-dashed border-line p-8"><p className="font-medium">No sessions are open right now. Please check back soon.</p></div>
      ) : (
        <div className="mt-4 max-w-2xl space-y-8">
          {[...days.entries()].map(([day, list]) => (
            <section key={day}>
              <h3 className="text-lg">{day}</h3>
              <ul className="mt-2 divide-y divide-line border-y border-line">
                {list.map((s) => (
                  <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                    <span>{timeFmt.format(s.startsAt)} to {timeFmt.format(s.endsAt)} EAT{s.capacity > 1 ? ` · ${s.seatsLeft} seat${s.seatsLeft === 1 ? "" : "s"} left` : ""}</span>
                    <form action={bookSlot.bind(null, s.id, p.slug)}>
                      <button type="submit" className="btn btn-primary !min-h-9">{user ? (p.priceMinor === 0 ? "Book" : "Book and pay") : "Sign in to book"}</button>
                    </form>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
      <p className="mt-10 text-xs text-muted">Educational mentoring only. No guarantee of trading results.</p>
    </PublicShell>
  );
}
