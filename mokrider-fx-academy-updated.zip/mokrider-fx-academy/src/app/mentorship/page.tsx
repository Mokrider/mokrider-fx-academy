import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { formatMoney } from "@/lib/money";
import { formatEat } from "@/lib/time";
import { openSlots } from "@/lib/booking/slots";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { ContactTrigger } from "@/components/ContactTrigger";
import { getContact } from "@/lib/contact";

const mentorSteps = [
  ["Send your details", "Apply, book a session, or email us. Tell us what you trade and where you are stuck."],
  ["Have a conversation", "A short, honest talk about your goals, your risk and which session type fits."],
  ["Get matched", "You are placed in the right format: one-to-one, a group class or a chart review."],
  ["Journal and review", "Your journal becomes the record. Each session starts from what your own trades show."],
];

export const metadata: Metadata = {
  title: "Mentorship",
  description: "Individual mentorship, group classes and chart reviews for Gold and EURUSD traders.",
  alternates: { canonical: "/mentorship" },
};

export default async function MentorshipPage() {
  const contact = getContact();
  const packages = await prisma.mentorshipPackage.findMany({ where: { status: "PUBLISHED" }, orderBy: { priceMinor: "asc" } });
  const slots = await openSlots(packages.map((p) => p.id));
  return (
    <PublicShell>
      <Breadcrumbs trail={[{ label: "Mentorship" }]} />
      <h1 className="text-4xl md:text-5xl">Mentorship</h1>
      <p className="mt-3 max-w-2xl text-muted">Session times are shown in East Africa Time (Africa/Nairobi). Pay with M-Pesa to confirm a paid session.</p>
      <div className="mt-6 flex flex-wrap gap-3">
        <Link href="/mentorship/apply" className="btn btn-ghost">Apply for private 1-on-1 mentorship</Link>
        {contact.email && (
          <ContactTrigger
            className="btn btn-ghost"
            message={{ subject: "Mentorship enquiry", body: "Hello,\n\nI would like to ask about mentorship.\n\nWhat I want to work on:\nMy trading experience (none is fine):\nWhen I am free (East Africa Time):\n\nMy name:\n\nThank you." }}
          >
            Ask a question first
          </ContactTrigger>
        )}
      </div>
      {packages.length === 0 ? (
        <div className="mt-12 rounded-md border border-dashed border-line p-8"><p className="font-medium">No packages are published yet.</p></div>
      ) : (
        <div className="mt-10 grid gap-8 md:grid-cols-2">
          {packages.map((p) => {
            const next = slots.filter((s) => s.packageId === p.id).slice(0, 3);
            return (
              <section key={p.id} className="flex flex-col rounded-md border border-line bg-card p-6">
                <h2 className="text-2xl">{p.title}</h2>
                <p className="mt-1 text-sm text-accent-text">{p.durationMinutes} min &middot; {p.sessionCount} session{p.sessionCount === 1 ? "" : "s"} &middot; {p.deliveryMethod}</p>
                <p className="mt-3 text-muted">{p.description}</p>
                {p.objectives.length > 0 && <ul className="mt-4 list-disc space-y-1 pl-5 text-sm text-muted">{p.objectives.map((o) => <li key={o}>{o}</li>)}</ul>}
                <p className="mt-5 font-display text-2xl">{p.priceMinor === 0 ? "Free" : formatMoney(p.priceMinor, p.currency)}</p>
                <div className="mt-2 text-sm text-muted">
                  {next.length === 0 ? <p>No sessions are open right now.</p> : (
                    <><p>Next sessions:</p><ul>{next.map((s) => <li key={s.id}>{formatEat(s.startsAt)}</li>)}</ul></>
                  )}
                </div>
                <Link href={`/mentorship/${p.slug}`} className="btn btn-primary mt-4 self-start">See sessions and book</Link>
              </section>
            );
          })}
        </div>
      )}

      <section className="mt-20" aria-labelledby="mentor-process">
        <h2 id="mentor-process" className="text-3xl">How mentorship works</h2>
        <ol className="mt-8 grid gap-6 md:grid-cols-4">
          {mentorSteps.map(([title, text], i) => (
            <li key={title} className="flex gap-4 md:block">
              <span className="step-num" aria-hidden>{i + 1}</span>
              <div className="md:mt-3">
                <h3 className="text-lg">{title}</h3>
                <p className="mt-1 text-sm text-muted">{text}</p>
              </div>
            </li>
          ))}
        </ol>
        <p className="mt-8 max-w-2xl text-sm text-muted">Mentors give honest feedback, including when a plan is not ready. No session promises profit, and no mentor will tell you what to trade.</p>
        <p className="mt-4 text-sm text-muted">Not sure which route fits? <Link href="/contact" className="link-accent">Tell us where you are</Link> and we will suggest one.</p>
      </section>
    </PublicShell>
  );
}
