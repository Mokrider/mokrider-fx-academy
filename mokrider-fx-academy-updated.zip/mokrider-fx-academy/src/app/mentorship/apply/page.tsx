import type { Metadata } from "next";
import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ApplicationForm } from "@/components/ApplicationForm";
import { getIntake } from "@/lib/intake";
import { submitApplication } from "@/app/actions/applications";

export const metadata: Metadata = {
  title: "Apply for private 1-on-1 mentorship",
  description: "Apply for private mentorship in price action, risk management and trading routine. Educational coaching with no promises of profit.",
  alternates: { canonical: "/mentorship/apply" },
};

const pillars = [
  ["Structure and price action", "Read market structure, map session and daily liquidity, and plan entries from the chart instead of from a stack of lagging indicators."],
  ["Risk systems you can follow", "Position sizing, a daily loss limit and a written routine, so one bad day cannot wreck an account. Rules reduce risk. They cannot remove it."],
  ["Prop firm challenge preparation", "Understand drawdown and consistency rules and plan around them. Passing a challenge is never guaranteed, and the firm's rules always come first."],
];

const steps = [
  ["Apply", "Answer a few honest questions below."],
  ["Review", "Your answers are read to see if private coaching is a good fit."],
  ["Conversation", "If it looks right, we talk about your goals and how we would work."],
  ["Plan and sessions", "You get a written plan and booked one-to-one sessions."],
];

export default async function ApplyPage() {
  const intake = await getIntake();
  return (
    <>
      <SiteHeader />
      <main>
        <section className="hero-bg">
          <div className="container-page grid items-center gap-12 py-16 md:py-24 lg:grid-cols-[1.2fr_1fr]">
            <div>
              <p className={`inline-block rounded-full border px-3 py-1 text-xs font-semibold ${intake.open ? "border-up text-up" : "border-down text-down"}`}>
                {intake.open ? "Applications are open" : "Applications are closed right now"}
              </p>
              <h1 className="mt-5 text-4xl sm:text-5xl md:text-6xl">
                <span className="chrome">Master price action.</span>{" "}
                <span className="text-accent-text">Trade with discipline.</span>
              </h1>
              <p className="mt-6 max-w-xl text-lg text-muted">
                Stop chasing lagging indicators and copy-paste signal channels. Learn to read market structure and liquidity, manage drawdown with rules, and build a written trading plan, one to one.
              </p>
              {intake.note && <p className="mt-4 max-w-xl rounded-md border border-line bg-surface p-3 text-sm">{intake.note}</p>}
              {intake.open && <a href="#apply" className="btn btn-primary mt-8">Apply for 1-on-1 mentorship</a>}
            </div>
            <aside className="bg-card border border-line p-6" aria-label="How it works">
              <h2 className="text-xl">How it works</h2>
              <ol className="mt-4 space-y-4">
                {steps.map(([t, d], i) => (
                  <li key={t} className="flex gap-3">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-accent text-sm font-bold text-white" aria-hidden>{i + 1}</span>
                    <span><span className="font-semibold">{t}.</span> <span className="text-sm text-muted">{d}</span></span>
                  </li>
                ))}
              </ol>
            </aside>
          </div>
        </section>

        <section className="border-y border-line bg-surface py-14">
          <div className="container-page max-w-3xl text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-accent-text">The reality check</p>
            <h2 className="mt-3 text-2xl md:text-3xl">No shortcuts. No profit promises.</h2>
            <p className="mx-auto mt-4 max-w-2xl text-muted">
              If you want overnight riches or signal alerts, this is not for you. Trading carries a high risk of loss and nobody can promise results. This mentorship is for traders who treat it as practice, maths and risk management.
            </p>
          </div>
        </section>

        <section className="container-page py-20" aria-labelledby="pillars-h">
          <h2 id="pillars-h" className="text-3xl md:text-4xl">What we work on together</h2>
          <div className="mt-10 grid gap-8 md:grid-cols-3">
            {pillars.map(([t, d], i) => (
              <div key={t} className="bg-card border border-line p-6">
                <p className="text-xs font-semibold tracking-widest text-accent-text">0{i + 1}</p>
                <h3 className="mt-2 text-xl">{t}</h3>
                <p className="mt-3 text-sm text-muted">{d}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="apply" className="container-page max-w-3xl scroll-mt-20 pb-20" aria-labelledby="apply-h">
          <div className="bg-card border border-line p-8">
            <h2 id="apply-h" className="text-2xl md:text-3xl">Private 1-on-1 application</h2>
            {intake.open ? (
              <>
                <p className="mb-6 mt-2 text-sm text-muted">Answer honestly. There are no wrong answers, and nothing here is a test you can fail.</p>
                <ApplicationForm action={submitApplication} />
              </>
            ) : (
              <p className="mt-4 text-muted">Applications are closed at the moment. You can still <Link href="/mentorship" className="link-accent">see the group and session options</Link> or <Link href="/learn" className="link-accent">start with a course</Link>.</p>
            )}
          </div>
          <p className="mt-6 text-xs text-muted">Educational mentoring only. Not financial advice. Trading leveraged products carries a high risk of loss.</p>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
