import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { Markdown } from "@/components/Markdown";

export const metadata: Metadata = { title: "About the mentor", alternates: { canonical: "/about" } };

type About = { name: string; headline: string; body: string; topics: string[] };

export default async function AboutPage() {
  const row = await prisma.siteSetting.findUnique({ where: { key: "about" } });
  const about = (row?.value ?? null) as About | null;
  return (
    <PublicShell>
      {about ? (
        <div className="max-w-3xl">
          <p className="text-sm text-accent-text">{about.name}</p>
          <h1 className="mt-1 text-4xl md:text-5xl">{about.headline}</h1>
          <div className="mt-8"><Markdown source={about.body} /></div>
          {about.topics.length > 0 && (
            <section className="mt-10">
              <h2 className="text-2xl">What is taught</h2>
              <ul className="mt-3 list-disc space-y-1 pl-6 text-muted">{about.topics.map((t) => <li key={t}>{t}</li>)}</ul>
            </section>
          )}
          <div className="mt-10 flex flex-wrap gap-3">
            <Link href="/learn" className="btn btn-primary">See courses</Link>
            <Link href="/mentorship" className="btn btn-ghost">Mentorship</Link>
          </div>
          <p className="mt-10 border-t border-line pt-4 text-xs text-muted">Educational content only. No guarantee of trading results.</p>
        </div>
      ) : (
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl">About the mentor</h1>
          <p className="mt-6 rounded-md border border-dashed border-line p-6 text-muted">The mentor profile has not been added yet.</p>
        </div>
      )}
    </PublicShell>
  );
}
