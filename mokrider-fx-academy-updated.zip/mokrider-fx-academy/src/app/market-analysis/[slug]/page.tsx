import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { Markdown } from "@/components/Markdown";
import { visibleWhere } from "@/lib/publishing";
import { formatEat } from "@/lib/time";
import { getCurrentUser } from "@/lib/session";

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ preview?: string }> };

async function load(slug: string, preview: boolean) {
  return prisma.marketAnalysis.findFirst({
    where: preview ? { slug } : { slug, ...visibleWhere() },
    include: { author: { select: { name: true } } },
  });
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const a = await load(slug, false);
  if (!a) return { title: "Analysis", robots: { index: false } };
  const description = `${a.instrument} ${a.timeframe} educational analysis published ${formatEat(a.publishedAt ?? a.createdAt)}.`;
  return { title: a.title, description, alternates: { canonical: `/market-analysis/${a.slug}` }, openGraph: { title: a.title, description, type: "article" } };
}

function Block({ title, text }: { title: string; text: string | null }) {
  if (!text) return null;
  return (
    <section className="mt-10">
      <h2 className="text-2xl">{title}</h2>
      <div className="mt-3"><Markdown source={text} /></div>
    </section>
  );
}

export default async function AnalysisPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { preview } = await searchParams;
  const user = preview === "1" ? await getCurrentUser() : null;
  const isPreview = preview === "1" && user?.role === "ADMIN";
  const a = await load(slug, isPreview);
  if (!a) notFound();

  const updated = a.publishedAt && a.updatedAt.getTime() - a.publishedAt.getTime() > 5 * 60 * 1000 ? a.updatedAt : null;

  return (
    <PublicShell>
      {isPreview && <p className="mb-6 rounded-md border border-accent p-3 text-sm">Preview. Status: {a.status}.</p>}
      <article className="max-w-3xl">
        <Link href="/market-analysis" className="link-accent text-sm">All analysis</Link>
        <p className="mt-4 text-sm text-accent-text">{a.instrument} &middot; {a.timeframe}{a.marketSession ? ` · ${a.marketSession} session` : ""}</p>
        <h1 className="mt-1 text-4xl md:text-5xl">{a.title}</h1>
        <p className="mt-3 text-sm text-muted">
          {a.author.name} &middot; Published {a.publishedAt ? formatEat(a.publishedAt) : "not yet"}
          {updated && <> &middot; Updated {formatEat(updated)}</>}
          {a.dataTimestamp && <> &middot; Chart data as of {formatEat(a.dataTimestamp)}</>}
        </p>
        <p className="mt-6 rounded-md border border-line bg-surface p-4 text-sm">
          {a.isHistorical
            ? "Historical example. This shows a past chart for learning and is not current analysis."
            : "A point-in-time educational view. Markets move, so this may already be out of date. It is not a live feed, a signal or advice."}
        </p>
        {a.chartImage && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={a.chartImage} alt={`${a.instrument} ${a.timeframe} chart for this analysis`} className="mt-8 w-full rounded-md border border-line" loading="lazy" />
        )}
        <section className="mt-10"><h2 className="text-2xl">Market context</h2><div className="mt-3"><Markdown source={a.body} /></div></section>
        <Block title="Bullish scenario" text={a.bullishScenario} />
        <Block title="Bearish scenario" text={a.bearishScenario} />
        <Block title="What would invalidate this view" text={a.invalidation} />
        <Block title="Risk considerations" text={a.riskNotes} />
        <p className="mt-10 border-t border-line pt-4 text-xs text-muted">Educational content only. Scenarios are not trade recommendations. Trading carries a high risk of loss.</p>
      </article>
    </PublicShell>
  );
}
