import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { visibleWhere } from "@/lib/publishing";
import { formatEat } from "@/lib/time";

export const metadata: Metadata = {
  title: "Market analysis",
  description: "Educational XAUUSD and EURUSD chart analysis with timestamps, scenarios and invalidation levels.",
  alternates: { canonical: "/market-analysis" },
};

const INSTRUMENTS = ["XAUUSD", "EURUSD"];

export default async function MarketAnalysisPage({ searchParams }: { searchParams: Promise<{ instrument?: string }> }) {
  const { instrument } = await searchParams;
  const active = instrument && INSTRUMENTS.includes(instrument) ? instrument : undefined;
  const items = await prisma.marketAnalysis.findMany({
    where: { ...visibleWhere(), ...(active ? { instrument: active } : {}) },
    orderBy: { publishedAt: "desc" }, take: 30,
  });

  return (
    <PublicShell>
      <h1 className="text-4xl md:text-5xl">Market analysis</h1>
      <p className="mt-3 max-w-2xl text-muted">
        Educational chart breakdowns. Each one shows when it was published. This is not a live feed, not a signal service and not advice.
      </p>
      <nav aria-label="Instrument filter" className="mt-8 flex gap-2 text-sm">
        <Link href="/market-analysis" className={`btn ${!active ? "btn-primary" : "btn-ghost"}`}>All</Link>
        {INSTRUMENTS.map((i) => (
          <Link key={i} href={`/market-analysis?instrument=${i}`} className={`btn ${active === i ? "btn-primary" : "btn-ghost"}`}>{i}</Link>
        ))}
      </nav>

      {items.length === 0 ? (
        <div className="mt-12 rounded-md border border-dashed border-line p-8">
          <p className="font-medium">No analysis has been published yet.</p>
        </div>
      ) : (
        <ul className="mt-10 divide-y divide-line border-y border-line">
          {items.map((a) => (
            <li key={a.id} className="py-6">
              <p className="text-sm text-accent-text">{a.instrument} &middot; {a.timeframe}{a.marketSession ? ` · ${a.marketSession} session` : ""}{a.isHistorical ? " · Historical example" : ""}</p>
              <h2 className="mt-1 text-2xl"><Link href={`/market-analysis/${a.slug}`} className="hover:text-accent-text">{a.title}</Link></h2>
              <p className="mt-1 text-xs text-muted">Published {a.publishedAt ? formatEat(a.publishedAt) : ""}</p>
            </li>
          ))}
        </ul>
      )}
    </PublicShell>
  );
}
