import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { Markdown } from "@/components/Markdown";
import { visibleWhere } from "@/lib/publishing";
import { formatEat } from "@/lib/time";
import { getCurrentUser } from "@/lib/session";

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ preview?: string }> };

async function load(slug: string, preview: boolean) {
  return prisma.article.findFirst({
    where: preview ? { slug } : { slug, ...visibleWhere() },
    include: { author: { select: { name: true } } },
  });
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const a = await load(slug, false);
  if (!a) return { title: "Article", robots: { index: false } };
  const title = a.seoTitle || a.title;
  const description = a.seoDescription || a.excerpt;
  return {
    title, description, alternates: { canonical: `/blog/${a.slug}` },
    openGraph: { title, description, type: "article", publishedTime: a.publishedAt?.toISOString(), images: a.coverImage ? [a.coverImage] : undefined },
  };
}

export default async function ArticlePage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { preview } = await searchParams;
  const user = preview === "1" ? await getCurrentUser() : null;
  const isPreview = preview === "1" && user?.role === "ADMIN";
  const article = await load(slug, isPreview);
  if (!article) notFound();

  const related = article.tags.length
    ? await prisma.article.findMany({
        where: { ...visibleWhere(), id: { not: article.id }, tags: { hasSome: article.tags } },
        orderBy: { publishedAt: "desc" }, take: 3, select: { id: true, title: true, slug: true },
      })
    : [];

  const base = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  const jsonLd = {
    "@context": "https://schema.org", "@type": "Article", headline: article.title, description: article.excerpt,
    datePublished: article.publishedAt?.toISOString(), dateModified: article.updatedAt.toISOString(),
    author: { "@type": "Person", name: article.author.name }, mainEntityOfPage: `${base}/blog/${article.slug}`,
  };

  return (
    <PublicShell>
      {isPreview && <p className="mb-6 rounded-md border border-accent p-3 text-sm">Preview. Status: {article.status}. This is {article.status === "PUBLISHED" ? "live" : "not public"}.</p>}
      <article className="max-w-3xl">
        <Link href="/blog" className="link-accent text-sm">All articles</Link>
        <h1 className="mt-4 text-4xl md:text-5xl">{article.title}</h1>
        <p className="mt-3 text-sm text-muted">{article.author.name} &middot; {article.publishedAt ? formatEat(article.publishedAt) : "Unpublished"} &middot; {article.readingMinutes} min read</p>
        {article.coverImage && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={article.coverImage} alt="" className="mt-8 w-full rounded-md border border-line" loading="lazy" />
        )}
        <div className="mt-8"><Markdown source={article.body} /></div>
        {article.tags.length > 0 && (
          <p className="mt-8 flex flex-wrap gap-2 text-sm">
            {article.tags.map((t) => <Link key={t} href={`/blog?tag=${encodeURIComponent(t)}`} className="rounded border border-line px-2 py-0.5 text-muted hover:text-fg">{t}</Link>)}
          </p>
        )}
        <p className="mt-8 border-t border-line pt-4 text-xs text-muted">Educational content only. Not financial advice. Trading carries a high risk of loss.</p>
      </article>
      {related.length > 0 && (
        <section className="mt-12 max-w-3xl">
          <h2 className="text-2xl">Related reading</h2>
          <ul className="mt-3 space-y-1">{related.map((r) => <li key={r.id}><Link href={`/blog/${r.slug}`} className="link-accent">{r.title}</Link></li>)}</ul>
        </section>
      )}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />
    </PublicShell>
  );
}
