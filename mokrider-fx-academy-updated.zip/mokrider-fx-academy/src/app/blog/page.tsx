import type { Metadata } from "next";
import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { visibleWhere } from "@/lib/publishing";
import { formatEat } from "@/lib/time";

export const metadata: Metadata = {
  title: "Blog",
  description: "Educational articles on market structure, risk management and trading psychology for Gold and EURUSD.",
  alternates: { canonical: "/blog" },
};

const PAGE_SIZE = 9;

export default async function BlogPage({ searchParams }: { searchParams: Promise<{ q?: string; tag?: string; page?: string }> }) {
  const { q, tag, page } = await searchParams;
  const pageNum = Math.max(1, Number.parseInt(page ?? "1", 10) || 1);
  const where: Prisma.ArticleWhereInput = { ...visibleWhere() };
  if (q) where.OR = [{ title: { contains: q, mode: "insensitive" } }, { excerpt: { contains: q, mode: "insensitive" } }];
  if (tag) where.tags = { has: tag };

  const [total, articles] = await Promise.all([
    prisma.article.count({ where }),
    prisma.article.findMany({ where, orderBy: { publishedAt: "desc" }, skip: (pageNum - 1) * PAGE_SIZE, take: PAGE_SIZE, include: { author: { select: { name: true } } } }),
  ]);
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const href = (p: number) => {
    const sp = new URLSearchParams();
    if (q) sp.set("q", q);
    if (tag) sp.set("tag", tag);
    sp.set("page", String(p));
    return `/blog?${sp.toString()}`;
  };

  return (
    <PublicShell>
      <h1 className="text-4xl md:text-5xl">Blog</h1>
      <p className="mt-3 max-w-2xl text-muted">Educational articles. Nothing here is financial advice.</p>
      <form method="get" role="search" aria-label="Search articles" className="mt-8 flex max-w-lg gap-3">
        <label htmlFor="q" className="sr-only">Search articles</label>
        <input id="q" name="q" defaultValue={q} placeholder="Search articles" className="field" />
        <button type="submit" className="btn btn-primary">Search</button>
      </form>
      {(q || tag) && <p className="mt-3 text-sm text-muted">{tag ? `Tag: ${tag}. ` : ""}<Link href="/blog" className="link-accent">Clear</Link></p>}

      {articles.length === 0 ? (
        <div className="mt-12 rounded-md border border-dashed border-line p-8">
          <p className="font-medium">{q || tag ? "No articles match your search." : "No articles have been published yet."}</p>
        </div>
      ) : (
        <ul className="mt-10 divide-y divide-line border-y border-line">
          {articles.map((a) => (
            <li key={a.id} className="py-6">
              <h2 className="text-2xl"><Link href={`/blog/${a.slug}`} className="hover:text-accent-text">{a.title}</Link></h2>
              <p className="mt-2 max-w-2xl text-muted">{a.excerpt}</p>
              <p className="mt-2 text-xs text-muted">{a.author.name} &middot; {a.publishedAt ? formatEat(a.publishedAt) : ""} &middot; {a.readingMinutes} min read</p>
            </li>
          ))}
        </ul>
      )}

      {pages > 1 && (
        <nav aria-label="Pagination" className="mt-8 flex items-center justify-between text-sm">
          {pageNum > 1 ? <Link href={href(pageNum - 1)} className="btn btn-ghost">Newer</Link> : <span />}
          <span className="text-muted">Page {pageNum} of {pages}</span>
          {pageNum < pages ? <Link href={href(pageNum + 1)} className="btn btn-ghost">Older</Link> : <span />}
        </nav>
      )}
    </PublicShell>
  );
}
