import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { PhoneForm } from "@/components/CheckoutForm";
import { PriceTag } from "@/components/PriceTag";
import { AskToBuy } from "@/components/AskToBuy";
import { getCurrentUser } from "@/lib/session";
import { readCart } from "@/lib/commerce/cartStore";
import { resolveCart } from "@/lib/commerce/checkout";
import { orderTotals } from "@/lib/commerce/pricing";
import { formatMoney } from "@/lib/money";
import { isMpesaConfigured } from "@/lib/mpesa/daraja";
import { removeFromCart, startMpesaCheckout } from "@/app/actions/shop";

export const metadata: Metadata = { title: "Cart", robots: { index: false, follow: false } };

export default async function CartPage() {
  const user = await getCurrentUser();
  const { lines, notes } = await resolveCart(user?.id ?? null, await readCart());
  const totals = orderTotals(lines);
  const currency = lines[0]?.currency ?? "KES";
  const orderMessage = [
    "Hello,", "", "I would like to order:",
    ...lines.map((l) => `- ${l.title} (${formatMoney(l.unitMinor, l.currency)})`),
    "", `Total: ${formatMoney(totals.totalMinor, currency)}`, "",
    `My account email: ${user?.email ?? ""}`, "My name:", "", "Thank you.",
  ].join("\n");

  return (
    <PublicShell>
      <h1 className="text-4xl md:text-5xl">Your cart</h1>
      {notes.length > 0 && <ul className="mt-6 space-y-2 text-sm text-muted">{notes.map((n) => <li key={n} className="rounded-md border border-line bg-surface p-3">{n}</li>)}</ul>}

      {lines.length === 0 ? (
        <div className="mt-10 rounded-md border border-dashed border-line p-8">
          <p className="font-medium">Your cart is empty.</p>
          <div className="mt-4 flex gap-3"><Link href="/shop" className="btn btn-primary">Browse the shop</Link><Link href="/learn" className="btn btn-ghost">Browse courses</Link></div>
        </div>
      ) : (
        <div className="mt-10 grid gap-12 lg:grid-cols-[1.4fr_1fr]">
          <ul className="divide-y divide-line border-y border-line">
            {lines.map((l) => (
              <li key={`${l.kind}:${l.id}`} className="flex items-center justify-between gap-4 py-4">
                <div>
                  <Link href={l.kind === "PRODUCT" ? `/shop/${l.slug}` : `/learn/${l.slug}`} className="font-medium hover:text-accent-text">{l.title}</Link>
                  <p className="text-xs text-muted">{l.kind === "PRODUCT" ? "Digital product" : "Course"}</p>
                </div>
                <div className="flex items-center gap-4">
                  <PriceTag listMinor={l.listMinor} unitMinor={l.unitMinor} currency={l.currency} />
                  <form action={removeFromCart.bind(null, l.kind, l.id)}><button type="submit" className="text-sm text-muted underline" aria-label={`Remove ${l.title}`}>Remove</button></form>
                </div>
              </li>
            ))}
          </ul>

          <section aria-label="Checkout" className="h-fit rounded-md border border-line bg-card p-6">
            <dl className="space-y-1 text-sm">
              {totals.discountMinor > 0 && <div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd>{formatMoney(totals.subtotalMinor, currency)}</dd></div>}
              {totals.discountMinor > 0 && <div className="flex justify-between"><dt className="text-muted">Discount</dt><dd>-{formatMoney(totals.discountMinor, currency)}</dd></div>}
              <div className="flex justify-between border-t border-line pt-2 text-lg font-semibold"><dt>Total</dt><dd>{formatMoney(totals.totalMinor, currency)}</dd></div>
            </dl>
            <div className="mt-6">
              {!user ? (
                <Link href="/login?next=/cart" className="btn btn-primary w-full">Sign in to check out</Link>
              ) : !isMpesaConfigured() ? (
                <div className="space-y-3">
                  <p className="rounded-md border border-line bg-surface p-3 text-sm">Online M-Pesa checkout is not switched on yet. Send us your order and we will reply with the payment details. Access is added as soon as we confirm your payment.</p>
                  <AskToBuy subject="Order from MOKRIDER FX ACADEMY" message={orderMessage} label="Send my order" />
                </div>
              ) : (
                <PhoneForm action={startMpesaCheckout} label="Pay with M-Pesa" />
              )}
            </div>
            <p className="mt-4 text-xs text-muted">Prices are confirmed again on our server at checkout. Access is granted only after the payment is verified with M-Pesa.</p>
          </section>
        </div>
      )}
    </PublicShell>
  );
}
