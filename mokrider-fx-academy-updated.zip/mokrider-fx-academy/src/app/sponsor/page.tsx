import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { ContactTrigger } from "@/components/ContactTrigger";
import { getContact, whatsappUrl } from "@/lib/contact";
import { FULL_SPONSORSHIP_USD, selectionCriteria, sponsorshipSteps, waysToGive, whatFullSponsorshipCovers } from "@/content/sponsorship";

export const metadata: Metadata = {
  title: "Sponsor a student",
  description: `Pay for one student to learn Gold and EURUSD trading. USD ${FULL_SPONSORSHIP_USD} covers a whole student. Reach out first; no payment is taken on this site.`,
  alternates: { canonical: "/sponsor" },
};

export default function SponsorPage() {
  const c = getContact();
  const sponsorMsg = {
    subject: "I would like to sponsor a student",
    body: "Hello,\n\nI would like to sponsor a student.\n\nWhat I would like to fund (a whole student / a course / a session / other):\nMy name (or anonymous):\nBest way to reach me:\n\nThank you.",
  };
  const applyMsg = {
    subject: "Application for a sponsored seat",
    body: "Hello,\n\nI would like to apply for a sponsored seat.\n\nMy name:\nWhere I live:\nWhy I want to learn:\nWhat I have done so far (courses, journal, practice):\nWhy I cannot pay the full price right now:\n\nThank you.",
  };
  const waSponsor = whatsappUrl(c.whatsapp, "Hello, I would like to sponsor a student at MOKRIDER FX ACADEMY.");
  const waApply = whatsappUrl(c.whatsapp, "Hello, I would like to apply for a sponsored seat at MOKRIDER FX ACADEMY.");

  return (
    <PublicShell>
      <Breadcrumbs trail={[{ label: "Sponsor a student" }]} />
      <h1 className="text-4xl md:text-5xl">Sponsor a student. <span className="text-accent-text">Change one trader&apos;s start.</span></h1>
      <p className="mt-4 max-w-2xl text-muted">
        Many people in Kenya want to learn trading properly and cannot pay for it. USD {FULL_SPONSORSHIP_USD} pays for one student to learn everything the academy teaches. Whether you are a graduate saying thank you, a friend, or a business, there is a way to help.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        {c.email && <ContactTrigger message={sponsorMsg} className="btn btn-primary">Sponsor a student</ContactTrigger>}
        {waSponsor && <a className="btn btn-ghost" href={waSponsor} target="_blank" rel="noopener noreferrer">WhatsApp us</a>}
        {!c.email && !waSponsor && <Link href="/contact" className="btn btn-primary">Contact us to sponsor</Link>}
      </div>

      <section className="mt-16 grid gap-10 md:grid-cols-[1fr_1.2fr]" aria-labelledby="full-heading">
        <div className="bg-card self-start border border-line p-6">
          <p className="eyebrow">Full sponsorship</p>
          <p className="font-display mt-3 text-5xl text-accent-text">USD {FULL_SPONSORSHIP_USD}</p>
          <p className="mt-2 text-sm text-muted">One student, everything included.</p>
        </div>
        <div>
          <h2 id="full-heading" className="text-3xl">What USD {FULL_SPONSORSHIP_USD} covers</h2>
          <ul className="mt-5 list-disc space-y-2 pl-6 text-muted">
            {whatFullSponsorshipCovers.map((w) => <li key={w}>{w}</li>)}
          </ul>
          <p className="mt-5 text-sm text-muted">It pays for learning. It is never used as trading capital, and we will never ask a sponsor to fund a trading account.</p>
        </div>
      </section>

      <section className="mt-20" aria-labelledby="ways-heading">
        <h2 id="ways-heading" className="text-3xl">Ways to give</h2>
        <ul className="mt-8 grid gap-6 sm:grid-cols-2">
          {waysToGive.map((w) => (
            <li key={w.title} className="bg-card flex flex-col border border-line p-5">
              <h3 className="text-xl">{w.title}</h3>
              <p className="mt-2 flex-1 text-sm text-muted">{w.text}</p>
              <p className="mt-4 text-sm font-semibold text-accent-text">{w.amount}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-20" aria-labelledby="how-heading">
        <h2 id="how-heading" className="text-3xl">How it works</h2>
        <ol className="mt-8 grid gap-6 md:grid-cols-5">
          {sponsorshipSteps.map(([title, text], i) => (
            <li key={title} className="flex gap-4 md:block">
              <span className="step-num" aria-hidden>{i + 1}</span>
              <div className="md:mt-3">
                <h3 className="text-lg">{title}</h3>
                <p className="mt-1 text-sm text-muted">{text}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-20" aria-labelledby="criteria-heading">
        <h2 id="criteria-heading" className="text-3xl">Who gets a sponsored seat</h2>
        <p className="mt-3 max-w-2xl text-muted">Sponsored seats go to students who have earned them. These are the rules we use, in full.</p>
        <ul className="mt-8 grid gap-x-8 gap-y-8 md:grid-cols-2 lg:grid-cols-3">
          {selectionCriteria.map((k) => (
            <li key={k.title} className="border-t-2 border-accent pt-4">
              <h3 className="text-xl">{k.title}</h3>
              <p className="mt-2 text-sm text-muted">{k.text}</p>
            </li>
          ))}
        </ul>
        <div className="mt-8 flex flex-wrap gap-3">
          {c.email && <ContactTrigger message={applyMsg} className="btn btn-ghost">Apply for a sponsored seat</ContactTrigger>}
          {waApply && <a className="btn btn-ghost" href={waApply} target="_blank" rel="noopener noreferrer">Apply on WhatsApp</a>}
        </div>
      </section>

      <section className="mt-20 rounded-md border border-line p-6 text-sm text-muted" aria-label="Important">
        <p>
          <strong className="text-fg">Please read.</strong> Sponsoring a student is a gift for education. It is not an investment and returns nothing to the sponsor. Signals and mentorship are educational and are not personal financial advice. Trading carries a high risk of loss and no result is promised to any student.
        </p>
        <p className="mt-3">Read the full <Link href="/risk-disclosure" className="link-accent">risk disclosure</Link>.</p>
      </section>
    </PublicShell>
  );
}
