"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { parseMajorToMinor, parseSignedMajorToMinor } from "@/lib/money";
import { parseEatInput } from "@/lib/time";
import { checkTradeLevels } from "@/lib/trading/riskReward";
import type { FormState } from "@/components/ActionForm";

function text(fd: FormData, key: string) { return String(fd.get(key) ?? "").trim(); }
function longText(fd: FormData, key: string) { return text(fd, key).slice(0, 2000) || null; }

/** Optional positive decimal, kept as a string for exact storage. Returns undefined when blank, null when invalid. */
function decimal(fd: FormData, key: string): string | undefined | null {
  const v = text(fd, key).replace(/,/g, "");
  if (!v) return undefined;
  if (!/^\d+(\.\d{1,8})?$/.test(v) || Number(v) <= 0) return null;
  return v;
}

const baseSchema = z.object({
  instrument: z.string().toUpperCase().regex(/^[A-Z0-9]{3,12}$/, "Use letters and numbers only, for example XAUUSD"),
  direction: z.enum(["LONG", "SHORT"]),
  currency: z.enum(["USD", "EUR", "GBP", "KES"]),
});

export async function saveJournalEntry(_prev: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser("/tools/journal");
  const id = text(fd, "id");

  const base = baseSchema.safeParse({ instrument: text(fd, "instrument"), direction: text(fd, "direction"), currency: text(fd, "currency") });
  if (!base.success) return { error: `${base.error.issues[0].path.join(".")}: ${base.error.issues[0].message}` };

  const tradedAt = parseEatInput(text(fd, "tradedAt"));
  if (!tradedAt) return { error: "tradedAt: choose the trade date and time" };
  if (tradedAt.getTime() > Date.now() + 24 * 3600 * 1000) return { error: "tradedAt: the trade date cannot be in the future" };

  const entry = decimal(fd, "entryPrice");
  const stop = decimal(fd, "stopLoss");
  const target = decimal(fd, "takeProfit");
  const exit = decimal(fd, "exitPrice");
  const size = decimal(fd, "positionSize");
  if (entry === undefined || entry === null) return { error: "entryPrice: enter a price greater than zero" };
  for (const [label, v] of [["stopLoss", stop], ["takeProfit", target], ["exitPrice", exit], ["positionSize", size]] as const) {
    if (v === null) return { error: `${label}: enter a number greater than zero, or leave blank` };
  }
  if (stop) {
    const bad = checkTradeLevels(base.data.direction, Number(entry), Number(stop), target ? Number(target) : null);
    if (bad) return { error: bad };
  } else if (target) {
    const bad = checkTradeLevels(base.data.direction, Number(entry), base.data.direction === "LONG" ? 0 : Number.MAX_SAFE_INTEGER, Number(target));
    if (bad) return { error: bad };
  }

  const resultRaw = text(fd, "result");
  const resultMinor = resultRaw ? parseSignedMajorToMinor(resultRaw, base.data.currency) : null;
  if (resultRaw && resultMinor === null) return { error: "result: enter an amount such as 25.50 or -12" };
  const riskRaw = text(fd, "plannedRisk");
  const plannedRiskMinor = riskRaw ? parseMajorToMinor(riskRaw, base.data.currency) : null;
  if (riskRaw && plannedRiskMinor === null) return { error: "plannedRisk: enter a positive amount such as 10" };

  const data = {
    instrument: base.data.instrument, direction: base.data.direction, currency: base.data.currency, tradedAt,
    entryPrice: entry, stopLoss: stop ?? null, takeProfit: target ?? null, exitPrice: exit ?? null, positionSize: size ?? null,
    plannedRiskMinor, resultMinor, setup: text(fd, "setup").slice(0, 120) || null, emotionalState: text(fd, "emotionalState").slice(0, 120) || null,
    reasonEntry: longText(fd, "reasonEntry"), reasonExit: longText(fd, "reasonExit"), lessons: longText(fd, "lessons"),
  };

  if (id) {
    // Scoped to the signed-in user: someone else's entry id simply matches nothing.
    const res = await prisma.journalEntry.updateMany({ where: { id, userId: user.id }, data });
    if (res.count !== 1) return { error: "That entry was not found." };
  } else {
    await prisma.journalEntry.create({ data: { ...data, userId: user.id } });
  }
  revalidatePath("/tools/journal");
  redirect("/tools/journal?saved=1");
}

export async function deleteJournalEntry(id: string) {
  const user = await requireUser("/tools/journal");
  await prisma.journalEntry.deleteMany({ where: { id, userId: user.id } });
  revalidatePath("/tools/journal");
  redirect("/tools/journal?deleted=1");
}
