import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { PublicShell } from "@/components/PublicShell";
import { JournalForm } from "@/components/JournalForm";
import { JournalStatsView } from "@/components/JournalStatsView";
import { journalStats } from "@/lib/trading/journalStats";
import { formatMoney } from "@/lib/money";
import { formatEat } from "@/lib/time";

export const metadata: Metadata = { title: "Trading journal", robots: { index: false, follow: false } };

export default async function JournalPage({ searchParams }: { searchParams: Promise<{ saved?: string; deleted?: string }> }) {
  const user = await requireUser("/tools/journal");
  const { saved, deleted } = await searchParams;

  // Only this user's rows are ever read.
  const entries = await prisma.journalEntry.findMany({ where: { userId: user.id }, orderBy: { tradedAt: "desc" }, take: 2000 });
  const stats = journalStats(entries.map((e) => ({
    tradedAt: e.tradedAt, instrument: e.instrument, setup: e.setup, currency: e.currency, resultMinor: e.resultMinor, plannedRiskMinor: e.plannedRiskMinor,
  })));

  return (
    <PublicShell>
      <Link href="/tools" className="link-accent text-sm">All tools</Link>
      <h1 className="mt-4 text-4xl md:text-5xl">Trading journal</h1>
      <p className="mt-3 max-w-2xl text-muted">Private to your account. Nobody else can see these entries.</p>
      {saved && <p role="status" className="mt-4 rounded-md border border-line bg-surface p-3 text-sm text-up">Saved.</p>}
      {deleted && <p role="status" className="mt-4 rounded-md border border-line bg-surface p-3 text-sm">Entry deleted.</p>}

      <section className="mt-10" aria-labelledby="stats-h">
        <h2 id="stats-h" className="mb-4 text-3xl">Your statistics</h2>
        <JournalStatsView stats={stats} />
      </section>

      <section className="mt-14" aria-labelledby="add-h">
        <details open={entries.length === 0}>
          <summary className="cursor-pointer text-3xl" id="add-h">Add a trade</summary>
          <div className="mt-6 max-w-3xl"><JournalForm entry={null} /></div>
        </details>
      </section>

      <section className="mt-14" aria-labelledby="list-h">
        <h2 id="list-h" className="mb-4 text-3xl">Entries</h2>
        {entries.length === 0 ? <p className="text-muted">No entries yet.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-muted"><tr><th className="py-2 pr-4">Time</th><th className="pr-4">Instrument</th><th className="pr-4">Side</th><th className="pr-4">Result</th><th /></tr></thead>
              <tbody>
                {entries.slice(0, 100).map((e) => (
                  <tr key={e.id} className="border-t border-line">
                    <td className="py-2 pr-4">{formatEat(e.tradedAt)}</td>
                    <td className="pr-4">{e.instrument}</td>
                    <td className="pr-4">{e.direction === "LONG" ? "Long" : "Short"}</td>
                    <td className="pr-4">{e.resultMinor === null ? "Open" : formatMoney(e.resultMinor, e.currency)}</td>
                    <td><Link href={`/tools/journal/${e.id}`} className="link-accent">Edit</Link></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </PublicShell>
  );
}
