import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { PublicShell } from "@/components/PublicShell";
import { JournalForm } from "@/components/JournalForm";
import { deleteJournalEntry } from "@/app/tools/journal/actions";

export const metadata: Metadata = { title: "Edit journal entry", robots: { index: false, follow: false } };

export default async function EditEntry({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireUser("/tools/journal");
  const { id } = await params;
  // Ownership check: an id belonging to another user returns nothing, so the page is a 404.
  const entry = await prisma.journalEntry.findFirst({ where: { id, userId: user.id } });
  if (!entry) notFound();
  return (
    <PublicShell>
      <Link href="/tools/journal" className="link-accent text-sm">Back to journal</Link>
      <h1 className="mt-4 text-4xl">Edit entry</h1>
      <div className="mt-8 max-w-3xl"><JournalForm entry={entry} /></div>
      <form action={deleteJournalEntry.bind(null, entry.id)} className="mt-10 max-w-3xl border-t border-line pt-6">
        <p className="mb-3 text-sm text-muted">Deleting an entry cannot be undone.</p>
        <button type="submit" className="btn btn-ghost !text-down">Delete this entry</button>
      </form>
    </PublicShell>
  );
}
