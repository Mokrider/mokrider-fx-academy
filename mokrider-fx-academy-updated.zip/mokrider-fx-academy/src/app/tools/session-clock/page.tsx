import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { SessionClock } from "@/components/calc/SessionClock";

export const metadata: Metadata = { title: "Trading session timer", description: "Live Sydney, Tokyo, London and New York session times in your own time zone, with countdowns and what each session is usually like.", alternates: { canonical: "/tools/session-clock" } };

export default function Page() {
  return (
    <PublicShell>
      <Link href="/tools" className="link-accent text-sm">All tools</Link>
      <h1 className="mt-4 text-4xl md:text-5xl">Trading session timer</h1>
      <p className="mt-3 mb-10 max-w-2xl text-muted">Your own local time, which sessions are open right now, a countdown to the next open or close, and what each session is usually like for Gold and EURUSD. Daylight saving is handled for you.</p>
      <SessionClock />
      <p className="mt-10 text-xs text-muted">Educational tool. Results are estimates, not advice. Trading carries a high risk of loss.</p>
    </PublicShell>
  );
}
