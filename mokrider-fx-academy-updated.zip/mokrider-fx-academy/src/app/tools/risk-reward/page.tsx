import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { RiskRewardCalculator } from "@/components/calc/RiskRewardCalculator";

export const metadata: Metadata = { title: "Risk/reward calculator", description: "Check the risk, reward and ratio of a planned trade before you take it.", alternates: { canonical: "/tools/risk-reward" } };

export default function Page() {
  return (
    <PublicShell>
      <Link href="/tools" className="link-accent text-sm">All tools</Link>
      <h1 className="mt-4 text-4xl md:text-5xl">Risk/reward calculator</h1>
      <p className="mt-3 mb-10 max-w-2xl text-muted">See the risk, reward and ratio of a trade plan, plus the win rate you would need just to break even.</p>
      <RiskRewardCalculator />
      <p className="mt-10 text-xs text-muted">Educational tool. Results are estimates, not advice. Trading carries a high risk of loss.</p>
    </PublicShell>
  );
}
