import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { PositionSizeCalculator } from "@/components/calc/PositionSizeCalculator";

export const metadata: Metadata = { title: "Position-size calculator", description: "Work out a position size from your account balance, risk percentage and stop distance.", alternates: { canonical: "/tools/position-size" } };

export default function Page() {
  return (
    <PublicShell>
      <Link href="/tools" className="link-accent text-sm">All tools</Link>
      <h1 className="mt-4 text-4xl md:text-5xl">Position-size calculator</h1>
      <p className="mt-3 mb-10 max-w-2xl text-muted">Turn a risk percentage and a stop distance into a position size. Contract details are editable because brokers differ, and no exchange rate is assumed.</p>
      <PositionSizeCalculator />
      <p className="mt-10 text-xs text-muted">Educational tool. Results are estimates, not advice. Trading carries a high risk of loss.</p>
    </PublicShell>
  );
}
