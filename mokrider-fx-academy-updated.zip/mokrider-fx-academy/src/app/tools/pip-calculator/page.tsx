import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { PipCalculator } from "@/components/calc/PipCalculator";

export const metadata: Metadata = { title: "Pip and point calculator", description: "Convert pips to price distance and money value for an instrument.", alternates: { canonical: "/tools/pip-calculator" } };

export default function Page() {
  return (
    <PublicShell>
      <Link href="/tools" className="link-accent text-sm">All tools</Link>
      <h1 className="mt-4 text-4xl md:text-5xl">Pip and point calculator</h1>
      <p className="mt-3 mb-10 max-w-2xl text-muted">See what a move in pips is worth for your position size. Pip definitions differ by broker, so every value here is editable.</p>
      <PipCalculator />
      <p className="mt-10 text-xs text-muted">Educational tool. Results are estimates, not advice. Trading carries a high risk of loss.</p>
    </PublicShell>
  );
}
