import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { CompoundingCalculator } from "@/components/calc/CompoundingCalculator";

export const metadata: Metadata = { title: "Compounding calculator", description: "Explore a hypothetical growth scenario with a chosen return per period.", alternates: { canonical: "/tools/compounding" } };

export default function Page() {
  return (
    <PublicShell>
      <Link href="/tools" className="link-accent text-sm">All tools</Link>
      <h1 className="mt-4 text-4xl md:text-5xl">Compounding calculator</h1>
      <p className="mt-3 mb-10 max-w-2xl text-muted">Explore how a balance could grow if a chosen return repeated every period. It is arithmetic for a scenario, not a forecast.</p>
      <CompoundingCalculator />
      <p className="mt-10 text-xs text-muted">Educational tool. Results are estimates, not advice. Trading carries a high risk of loss.</p>
    </PublicShell>
  );
}
