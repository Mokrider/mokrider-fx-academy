import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";

export const metadata: Metadata = {
  title: "Trading tools",
  description: "Position-size, risk/reward, compounding and pip calculators, a session clock and a private trading journal.",
  alternates: { canonical: "/tools" },
};

const tools = [
  ["/tools/position-size", "Position-size calculator", "From balance, risk % and stop distance to lots, with editable contract specifications."],
  ["/tools/risk-reward", "Risk/reward calculator", "Risk, reward, ratio and the break-even win rate for a trade plan."],
  ["/tools/compounding", "Compounding calculator", "A hypothetical growth scenario. Arithmetic, not a forecast."],
  ["/tools/pip-calculator", "Pip and point calculator", "What a move in pips is worth for your position size."],
  ["/tools/session-clock", "Session timer", "Live time in your own zone, countdowns to each open and close, and what each session is usually like."],
  ["/coach", "Market Coach", "Quick quizzes and an AI coach that asks you questions and marks your explanations."],
  ["/tools/journal", "Trading journal", "Record trades privately and review your own statistics. Requires an account."],
];

export default function ToolsPage() {
  return (
    <PublicShell>
      <h1 className="text-4xl md:text-5xl">Trading tools</h1>
      <p className="mt-3 max-w-2xl text-muted">Each tool shows how it works and where its limits are. They are for learning and planning, not advice.</p>
      <ul className="mt-10 divide-y divide-line border-y border-line">
        {tools.map(([href, name, text]) => (
          <li key={href} className="py-5">
            <h2 className="text-2xl"><Link href={href} className="hover:text-accent-text">{name}</Link></h2>
            <p className="mt-1 text-muted">{text}</p>
          </li>
        ))}
        <li className="py-5">
          <h2 className="text-2xl">Economic calendar</h2>
          <p className="mt-1 text-muted">Not connected. It will appear once a licensed data source is configured. No events are invented in the meantime.</p>
        </li>
      </ul>
    </PublicShell>
  );
}
