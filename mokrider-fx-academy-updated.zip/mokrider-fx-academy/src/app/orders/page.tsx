import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { PublicShell } from "@/components/PublicShell";
import { formatMoney } from "@/lib/money";
import { formatEat } from "@/lib/time";

export const metadata: Metadata = { title: "My orders", robots: { index: false, follow: false } };

const STATUS_LABEL: Record<string, string> = {
  PENDING: "Pending", AWAITING_PAYMENT: "Awaiting payment", PAID: "Paid", FAILED: "Payment failed", CANCELLED: "Cancelled", REFUNDED: "Refunded",
};

export default async function OrdersPage() {
  const user = await requireUser("/orders");
  const orders = await prisma.order.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 100, include: { items: { select: { titleSnapshot: true } } } });
  return (
    <PublicShell>
      <h1 className="text-4xl md:text-5xl">My orders</h1>
      {orders.length === 0 ? (
        <div className="mt-10 rounded-md border border-dashed border-line p-8"><p className="font-medium">No orders yet.</p><Link href="/shop" className="btn btn-primary mt-4">Browse the shop</Link></div>
      ) : (
        <ul className="mt-10 divide-y divide-line border-y border-line">
          {orders.map((o) => (
            <li key={o.id} className="flex flex-wrap items-center justify-between gap-3 py-4">
              <div>
                <Link href={`/orders/${o.reference}`} className="font-medium hover:text-accent-text">{o.reference}</Link>
                <p className="text-sm text-muted">{o.items.map((i) => i.titleSnapshot).join(", ")}</p>
                <p className="text-xs text-muted">{formatEat(o.createdAt)}</p>
              </div>
              <div className="text-right text-sm"><p className="font-semibold">{formatMoney(o.totalMinor, o.currency)}</p><p className="text-muted">{STATUS_LABEL[o.status] ?? o.status}</p></div>
            </li>
          ))}
        </ul>
      )}
    </PublicShell>
  );
}
