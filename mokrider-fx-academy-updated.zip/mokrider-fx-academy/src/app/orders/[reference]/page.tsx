import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import { PublicShell } from "@/components/PublicShell";
import { PaymentStatus } from "@/components/PaymentStatus";
import { PhoneForm } from "@/components/CheckoutForm";
import { formatMoney } from "@/lib/money";
import { formatEat } from "@/lib/time";
import { checkPayment, retryPayment } from "@/app/actions/shop";

export const metadata: Metadata = { title: "Order", robots: { index: false, follow: false } };

const LABEL: Record<string, string> = { PENDING: "Pending", AWAITING_PAYMENT: "Awaiting payment", PAID: "Paid", FAILED: "Payment failed", CANCELLED: "Cancelled", REFUNDED: "Refunded" };

export default async function OrderPage({ params }: { params: Promise<{ reference: string }> }) {
  const { reference } = await params;
  const user = await requireUser(`/orders/${reference}`);
  // Scoped to the signed-in user: another customer's reference returns nothing, so the page is a 404.
  const order = await prisma.order.findFirst({
    where: { reference, userId: user.id },
    include: {
      items: { include: { entitlement: { select: { id: true, status: true } }, course: { select: { slug: true } }, product: { select: { slug: true } } } },
      payments: { orderBy: { createdAt: "desc" } },
    },
  });
  if (!order) notFound();
  const latest = order.payments[0];
  const paid = order.status === "PAID";

  return (
    <PublicShell>
      <Link href="/orders" className="link-accent text-sm">All orders</Link>
      <h1 className="mt-4 text-4xl">Order {order.reference}</h1>
      <p className="mt-2 text-muted">{formatEat(order.createdAt)} &middot; <span className="font-semibold text-fg">{LABEL[order.status] ?? order.status}</span></p>

      <div className="mt-8 max-w-3xl space-y-8">
        <PaymentStatus reference={order.reference} status={order.status} checkAction={checkPayment.bind(null, order.reference)} />

        {(order.status === "FAILED" || (order.status === "PENDING" && order.payments.length === 0)) && (
          <div className="rounded-md border border-line bg-card p-5">
            <p className="font-medium">{order.status === "FAILED" ? "The payment did not go through." : "Complete your payment to confirm this order."}</p>
            {latest?.failureReason && <p className="mt-1 text-sm text-muted">{latest.failureReason}</p>}
            <p className="mt-1 text-sm text-muted">You have not been charged unless you received an M-Pesa confirmation message. You can try again.</p>
            <div className="mt-4"><PhoneForm action={retryPayment.bind(null, order.reference)} label={order.status === "FAILED" ? "Try again with M-Pesa" : "Pay with M-Pesa"} /></div>
          </div>
        )}
        {order.status === "REFUNDED" && <p className="rounded-md border border-line bg-surface p-4 text-sm">This order was refunded and access to its items has ended.</p>}

        <section aria-label="Items">
          <ul className="divide-y divide-line border-y border-line">
            {order.items.map((i) => (
              <li key={i.id} className="flex flex-wrap items-center justify-between gap-3 py-4">
                <div>
                  <p className="font-medium">{i.titleSnapshot}</p>
                  <p className="text-sm text-muted">{formatMoney(i.unitPriceMinor, i.currency)}</p>
                </div>
                {paid && i.kind === "PRODUCT" && i.entitlement?.status === "ACTIVE" && <a href={`/api/downloads/${i.entitlement.id}`} className="btn btn-primary">Download</a>}
                {paid && i.kind === "COURSE" && i.course && <Link href={`/learn/${i.course.slug}`} className="btn btn-primary">Open course</Link>}
              </li>
            ))}
          </ul>
          <dl className="mt-4 space-y-1 text-sm">
            {order.discountMinor > 0 && <div className="flex justify-between"><dt className="text-muted">Discount</dt><dd>-{formatMoney(order.discountMinor, order.currency)}</dd></div>}
            <div className="flex justify-between text-lg font-semibold"><dt>Total</dt><dd>{formatMoney(order.totalMinor, order.currency)}</dd></div>
          </dl>
        </section>

        {latest && (
          <section aria-label="Payment" className="text-sm text-muted">
            <p>Payment: M-Pesa &middot; {latest.status.replace("_", " ").toLowerCase()}{latest.phoneLast4 ? ` · phone ending ${latest.phoneLast4}` : ""}</p>
            {latest.providerReceipt && <p>M-Pesa receipt: <span className="font-mono text-fg">{latest.providerReceipt}</span></p>}
            {latest.verifiedAt && <p>Verified {formatEat(latest.verifiedAt)}</p>}
          </section>
        )}
        {paid && !latest && <p className="text-sm text-muted">This was a free order. No payment was needed.</p>}
      </div>
    </PublicShell>
  );
}
