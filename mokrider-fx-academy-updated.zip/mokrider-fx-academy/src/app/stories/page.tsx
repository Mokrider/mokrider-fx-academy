import type { Metadata } from "next";
import Link from "next/link";
import { PublicShell } from "@/components/PublicShell";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { StoriesBoard } from "@/components/StoriesBoard";
import { ContactTrigger } from "@/components/ContactTrigger";
import { getContact, whatsappUrl } from "@/lib/contact";
import { stories, storyVoices } from "@/content/stories";

export const metadata: Metadata = {
  title: "Student stories",
  description: "Honest accounts from MOKRIDER FX ACADEMY students, in their own words, including what could have been better.",
  alternates: { canonical: "/stories" },
};

const prompts = [
  ["Students", "What did you learn, what habit changed, and what did you find hard?"],
  ["Mentees", "How did the one-to-one sessions work for you, and what would you change?"],
  ["Anyone who left", "Candid feedback from someone who did not finish is just as welcome."],
];

export default function StoriesPage() {
  const c = getContact();
  const storyMessage = {
    subject: "My story with MOKRIDER FX ACADEMY",
    body: "Hello,\n\nI would like to share my story.\n\nMy name:\nWhich course or mentorship I took:\nWhere I started:\nWhat changed for me:\nWhat could have been better:\n\nYou may / may not publish this with my name (delete one).\n\nThank you.",
  };
  const wa = whatsappUrl(c.whatsapp, "Hello, I would like to share my story about MOKRIDER FX ACADEMY.");

  return (
    <PublicShell>
      <Breadcrumbs trail={[{ label: "Student stories" }]} />
      <h1 className="text-4xl md:text-5xl">The people this <span className="text-accent-text">actually happened to.</span></h1>
      <p className="mt-4 max-w-2xl text-muted">
        Every word here is the student&apos;s own. We publish a story only with the person&apos;s written permission, and we include what could have been better, because a page with only praise tells you nothing.
      </p>
      <p className="mt-3 max-w-2xl text-sm text-muted">
        We never show trading profits as typical. Most people who trade lose money, and no story on this page is a promise of results.
      </p>

      <section className="mt-12" aria-label="Stories">
        {stories.length > 0 ? (
          <StoriesBoard stories={stories} voices={storyVoices} />
        ) : (
          <div className="rounded-md border border-dashed border-line p-8">
            <p className="font-medium">No stories are published yet.</p>
            <p className="mt-2 max-w-xl text-sm text-muted">
              We will not write them ourselves. When the first students are ready, their accounts will appear here with their permission. If you have already studied with us, you can be the first.
            </p>
          </div>
        )}
      </section>

      <section className="mt-16" aria-labelledby="share-heading">
        <h2 id="share-heading" className="text-3xl">Share your story</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {prompts.map(([who, ask]) => (
            <div key={who} className="border-t-2 border-accent pt-4">
              <h3 className="text-xl">{who}</h3>
              <p className="mt-2 text-sm text-muted">{ask}</p>
            </div>
          ))}
        </div>
        <div className="mt-8 flex flex-wrap gap-3">
          {c.email && <ContactTrigger message={storyMessage} className="btn btn-primary">Send my story by email</ContactTrigger>}
          {wa && <a className="btn btn-ghost" href={wa} target="_blank" rel="noopener noreferrer">Message us on WhatsApp</a>}
        </div>
        <p className="mt-6 max-w-2xl rounded-md border border-line p-4 text-sm text-muted">
          <strong className="text-fg">Your permission, in plain words.</strong> We will ask before publishing anything with your name on it. If you do not give permission, your story is not used. You can withdraw permission at any time by emailing us, and we will remove it.
        </p>
      </section>

      <section className="mt-16" aria-labelledby="start-heading">
        <h2 id="start-heading" className="text-3xl">Start your own</h2>
        <p className="mt-3 max-w-xl text-muted">Begin with a course, or talk to a mentor first.</p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link href="/learn" className="btn btn-primary">See the courses</Link>
          <Link href="/mentorship" className="btn btn-ghost">Mentorship</Link>
        </div>
      </section>
    </PublicShell>
  );
}
