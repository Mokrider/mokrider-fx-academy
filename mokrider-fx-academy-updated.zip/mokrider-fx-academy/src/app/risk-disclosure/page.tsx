import type { Metadata } from "next";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export const metadata: Metadata = { title: "Risk disclosure" };

export default function RiskDisclosure() {
  return (
    <>
      <SiteHeader />
      <main className="container-page max-w-3xl py-16">
        <h1 className="text-4xl">Risk disclosure</h1>
        <p className="mt-4 rounded-md border border-line bg-surface p-4 text-sm">
          Draft text. It has not been reviewed by a lawyer and should be reviewed before launch.
        </p>
        <div className="mt-8 space-y-4 text-muted">
          <p>MOKRIDER FX ACADEMY provides educational content only. Nothing on this site is investment, financial, tax or legal advice, and nothing is a recommendation to buy or sell any instrument.</p>
          <p>Trading foreign exchange and gold, particularly with leverage, carries a high risk of loss. You can lose more than you deposit with some products. Only trade with money you can afford to lose.</p>
          <p>Chart examples, scenarios and calculators are for learning. Hypothetical examples and illustrations are not records of real trading and do not indicate future results. We do not guarantee profits or any level of skill after completing a course.</p>
          <p>Market commentary shows the time it was published and may be out of date by the time you read it. It is not a live signal service.</p>
          <p>Where this site links to brokers or other partners, any financial relationship will be disclosed on the relevant page.</p>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
