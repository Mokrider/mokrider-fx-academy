import type { Metadata } from "next";
import { SiteHeader } from "@/components/SiteHeader";
import { AuthForm } from "@/components/AuthForm";
import { safeNextPath } from "@/lib/session";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

export default async function Page({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  return (
    <>
      <SiteHeader />
      <main className="container-page flex justify-center py-16">
        <div className="w-full max-w-md rounded-md border border-line bg-card p-8">
          <h1 className="mb-6 text-3xl">Sign in</h1>
          <AuthForm mode="login" next={safeNextPath(next)} />
        </div>
      </main>
    </>
  );
}
