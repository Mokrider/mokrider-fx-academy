import { ImageResponse } from "next/og";

export const alt = "MOKRIDER FX ACADEMY: Learn the Market. Master your process.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

// 1200x630 share card shown when the site is linked on WhatsApp, X, Facebook and so on.
export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: "0 90px",
          background: "radial-gradient(circle at 90% 5%, #7a0a10 0%, #070707 60%)",
          color: "#ffffff",
        }}
      >
        <div style={{ fontSize: 30, letterSpacing: 12, color: "#ff5a5a", fontWeight: 700 }}>GOLD · EURUSD · NAIROBI</div>
        <div style={{ marginTop: 24, fontSize: 96, fontWeight: 800, lineHeight: 1.05 }}>MOKRIDER FX ACADEMY</div>
        <div style={{ marginTop: 24, fontSize: 44, color: "#d2d2d8" }}>Learn the Market. Master your process.</div>
        <div style={{ marginTop: 40, fontSize: 26, color: "#b8b8bf" }}>Educational content only. Trading involves risk of loss.</div>
      </div>
    ),
    size,
  );
}
