"use client";

export default function GlobalError({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="container-page py-24">
      <h1 className="text-4xl">Something went wrong</h1>
      <p className="mt-3 text-muted">The page could not load. Try again, and contact us if it keeps happening.</p>
      <button type="button" onClick={reset} className="btn btn-primary mt-6">Try again</button>
    </main>
  );
}
