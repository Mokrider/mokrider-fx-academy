"use server";

import { z } from "zod";
import { prisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { getIntake } from "@/lib/intake";
import { allow, clientId } from "@/lib/security/rateLimit";
import { cleanContactPhone } from "@/lib/commerce/phone";
import { brandedEmail, sendEmail } from "@/lib/email";
import { esc } from "@/lib/html";
import { APPLICATION_CONSENT, BOTTLENECKS, EXPERIENCE, FOCUS, labelFor, values } from "@/content/application";
import type { FormState } from "@/components/ActionForm";

const schema = z.object({
  name: z.string().trim().min(2, "Enter your name.").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email address.").max(254),
  experience: z.enum(values(EXPERIENCE), { errorMap: () => ({ message: "Choose your experience." }) }),
  bottleneck: z.enum(values(BOTTLENECKS), { errorMap: () => ({ message: "Choose your biggest challenge." }) }),
  focus: z.enum(values(FOCUS), { errorMap: () => ({ message: "Choose your main goal." }) }),
  goals: z.string().trim().max(1500, "Please keep your message under 1500 characters.").optional(),
});

export async function submitApplication(_prev: FormState, fd: FormData): Promise<FormState> {
  // Honeypot: real people never see or fill this field. Bots do, and get a fake success.
  if (String(fd.get("website") ?? "") !== "") return { ok: "Thank you. Your application has been received." };

  if (!(await getIntake()).open) return { error: "Applications are closed right now. Please check back later." };
  if (fd.get("consent") !== "on") return { error: "Please tick the box to agree to be contacted about your application." };
  if (!(await allow(`apply:${await clientId()}`, 3, 3600))) return { error: "Too many submissions from this connection. Please try again later." };

  const parsed = schema.safeParse({
    name: fd.get("name"), email: fd.get("email"), experience: fd.get("experience"), bottleneck: fd.get("bottleneck"), focus: fd.get("focus"),
    goals: String(fd.get("goals") ?? "") || undefined,
  });
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const phoneRaw = String(fd.get("phone") ?? "").trim();
  const phone = phoneRaw ? cleanContactPhone(phoneRaw) : null;
  if (phoneRaw && !phone) return { error: "Enter a valid phone or WhatsApp number, for example +254712345678, or leave it blank." };

  const d = parsed.data;
  const user = await getCurrentUser();
  try {
    await prisma.mentorshipApplication.create({
      data: { userId: user?.id ?? null, name: d.name, email: d.email, phone, experience: d.experience, bottleneck: d.bottleneck, focus: d.focus, goals: d.goals ?? null, consentText: APPLICATION_CONSENT },
    });
  } catch (e) {
    console.error("application save failed", e instanceof Error ? e.message : "unknown");
    return { error: "We could not save your application. Please try again." };
  }

  // Best-effort emails. The application is already saved; a failed email changes nothing.
  try {
    await sendEmail({
      to: d.email, subject: "We received your mentorship application",
      html: brandedEmail("Application received", `<p>Hi ${esc(d.name.split(" ")[0])}, thank you for applying for private mentorship. We will review your answers and contact you using the details you gave.</p><p style="color:#B8B8BF;font-size:13px">Receiving this email does not mean you have been accepted.</p>`),
    });
    const admin = process.env.ADMIN_NOTIFY_EMAIL;
    if (admin) {
      const base = (process.env.NEXT_PUBLIC_APP_URL ?? "").replace(/\/$/, "");
      await sendEmail({
        to: admin, subject: `New mentorship application: ${d.name}`,
        html: brandedEmail("New mentorship application", `<p><strong>${esc(d.name)}</strong> (${esc(d.email)}${phone ? `, ${esc(phone)}` : ""})</p><p>Experience: ${esc(labelFor(EXPERIENCE, d.experience))}<br>Challenge: ${esc(labelFor(BOTTLENECKS, d.bottleneck))}<br>Goal: ${esc(labelFor(FOCUS, d.focus))}</p><p><a href="${base}/admin/applications" style="color:#FF6B6B">Review it in the admin</a></p>`),
      });
    }
  } catch (e) {
    console.error("application email failed", e instanceof Error ? e.message : "unknown");
  }
  return { ok: "Thank you. Your application has been received. We will contact you using the details you gave." };
}
