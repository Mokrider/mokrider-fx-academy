"use server";

import { z } from "zod";
import { prisma } from "@/lib/db";
import { NEWSLETTER_CONSENT_TEXT } from "@/content/consent";
import { allow, clientId } from "@/lib/security/rateLimit";

export type NewsletterState = { ok: boolean; message: string } | null;

const schema = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  consent: z.literal("on"),
});

export async function subscribeNewsletter(_prev: NewsletterState, formData: FormData): Promise<NewsletterState> {
  const parsed = schema.safeParse({ email: formData.get("email"), consent: formData.get("consent") });
  if (!parsed.success) {
    return { ok: false, message: "Enter a valid email address and tick the consent box." };
  }
  try {
    if (!(await allow(`newsletter:${await clientId()}`, 5, 3600))) return { ok: false, message: "Too many attempts. Please try again later." };
    const existing = await prisma.newsletterConsent.findUnique({ where: { email: parsed.data.email } });
    if (existing && !existing.unsubscribedAt) {
      return { ok: true, message: "You are already on the list." };
    }
    await prisma.newsletterConsent.upsert({
      where: { email: parsed.data.email },
      create: { email: parsed.data.email, consentText: NEWSLETTER_CONSENT_TEXT, source: "home" },
      update: { consentText: NEWSLETTER_CONSENT_TEXT, unsubscribedAt: null },
    });
    return { ok: true, message: "You are subscribed. Your consent has been recorded." };
  } catch {
    return { ok: false, message: "We could not save your signup. Please try again later." };
  }
}
