"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";

/** Free-course enrollment. The server re-checks that the course is published and actually free. */
export async function enrollFree(courseId: string, slug: string) {
  const user = await requireUser(`/learn/${slug}`);
  const course = await prisma.course.findFirst({ where: { id: courseId, status: "PUBLISHED", isFree: true }, select: { id: true } });
  if (!course) redirect(`/learn/${slug}`);

  await prisma.$transaction(async (tx) => {
    await tx.enrollment.upsert({
      where: { userId_courseId: { userId: user.id, courseId: course.id } },
      update: {},
      create: { userId: user.id, courseId: course.id },
    });
    const existing = await tx.entitlement.findFirst({ where: { userId: user.id, kind: "COURSE", courseId: course.id } });
    if (!existing) await tx.entitlement.create({ data: { userId: user.id, kind: "COURSE", courseId: course.id } });
  });
  revalidatePath("/dashboard");
  redirect("/dashboard");
}
