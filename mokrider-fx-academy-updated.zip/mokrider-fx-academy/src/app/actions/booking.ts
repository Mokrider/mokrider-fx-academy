"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/session";
import { allow } from "@/lib/security/rateLimit";
import { BookingError, cancelBookingFor, reserveSlot } from "@/lib/booking/engine";
import { sendBookingConfirmationEmail } from "@/lib/commerce/notify";
import type { BookingErrorCode } from "@/lib/booking/rules";

export async function bookSlot(slotId: string, slug: string) {
  const user = await requireUser(`/mentorship/${slug}`);
  if (!(await allow(`book:${user.id}`, 30, 3600))) redirect(`/mentorship/${slug}?e=rate`);
  let result: Awaited<ReturnType<typeof reserveSlot>> | null = null;
  let code: BookingErrorCode | null = null;
  try {
    result = await reserveSlot(user.id, slotId);
  } catch (e) {
    if (e instanceof BookingError) code = e.code;
    else throw e;
  }
  if (code || !result) redirect(`/mentorship/${slug}?e=${code ?? "unavailable"}`);
  if (result.reference) redirect(`/orders/${result.reference}`); // paid session: pay with M-Pesa on the order page
  await sendBookingConfirmationEmail(result.bookingId);
  revalidatePath("/dashboard");
  redirect("/dashboard?booked=1");
}

export async function cancelBooking(bookingId: string) {
  const user = await requireUser("/dashboard");
  const r = await cancelBookingFor({ id: user.id, admin: false }, bookingId);
  revalidatePath("/dashboard");
  redirect(r.ok ? (r.refundRequested ? "/dashboard?cancelled=refund" : "/dashboard?cancelled=1") : `/dashboard?cancelError=${r.code}`);
}
