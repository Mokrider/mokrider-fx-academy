"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";
import type { FormState } from "@/components/ActionForm";
import { readCart, writeCart } from "@/lib/commerce/cartStore";
import { createOrder, resolveCart } from "@/lib/commerce/checkout";
import { reconcilePayment, fulfilOrderTx } from "@/lib/commerce/payments";
import { isWholeShillings } from "@/lib/commerce/pricing";
import { last4, normalizeKenyanPhone } from "@/lib/commerce/phone";
import { DarajaError, isMpesaConfigured, stkPush } from "@/lib/mpesa/daraja";
import { afterOrderPaid } from "@/lib/commerce/notify";
import { allow } from "@/lib/security/rateLimit";

const ID = /^[a-z0-9]{10,40}$/i;

export async function addToCart(kind: "PRODUCT" | "COURSE", id: string) {
  if (ID.test(id)) {
    const exists = kind === "PRODUCT"
      ? await prisma.product.findFirst({ where: { id, status: "PUBLISHED" }, select: { id: true } })
      : await prisma.course.findFirst({ where: { id, status: "PUBLISHED", isFree: false }, select: { id: true } });
    if (exists) {
      const cart = await readCart();
      if (!cart.some((c) => c.kind === kind && c.id === id)) await writeCart([...cart, { kind, id }]);
    }
  }
  redirect("/cart");
}

export async function removeFromCart(kind: "PRODUCT" | "COURSE", id: string) {
  const cart = await readCart();
  await writeCart(cart.filter((c) => !(c.kind === kind && c.id === id)));
  revalidatePath("/cart");
}

/** Free products: no payment, but still a recorded order and an entitlement. Price is re-checked on the server. */
export async function claimFree(productId: string, slug: string) {
  const user = await requireUser(`/shop/${slug}`);
  if (!(await allow(`claim:${user.id}`, 20, 3600))) redirect(`/shop/${slug}`);
  const { lines } = await resolveCart(user.id, [{ kind: "PRODUCT", id: productId }]);
  if (lines.length !== 1 || lines[0].unitMinor !== 0) redirect(`/shop/${slug}`);
  const order = await createOrder(user.id, lines);
  await prisma.$transaction((tx) => fulfilOrderTx(tx, order.id));
  await afterOrderPaid(order.id);
  revalidatePath("/dashboard");
  redirect(`/orders/${order.reference}`);
}

async function initiatePayment(order: { id: string; reference: string; totalMinor: number; currency: string }, phone: string): Promise<string | null> {
  const payment = await prisma.payment.create({
    data: { orderId: order.id, provider: "MPESA", status: "INITIATED", amountMinor: order.totalMinor, currency: order.currency, phoneLast4: last4(phone) },
  });
  try {
    const r = await stkPush({ phone, amountShillings: order.totalMinor / 100, reference: order.reference.replace(/-/g, ""), description: "MOKRIDER FX" });
    await prisma.$transaction([
      prisma.payment.update({ where: { id: payment.id }, data: { status: "PENDING", providerRef: r.checkoutRequestId } }),
      prisma.order.updateMany({ where: { id: order.id, status: { in: ["PENDING", "FAILED"] } }, data: { status: "AWAITING_PAYMENT" } }),
    ]);
    return null;
  } catch (e) {
    await prisma.$transaction([
      prisma.payment.update({ where: { id: payment.id }, data: { status: "FAILED", failureReason: "Could not start the request" } }),
      prisma.order.updateMany({ where: { id: order.id, status: { in: ["PENDING", "AWAITING_PAYMENT"] } }, data: { status: "FAILED" } }),
    ]);
    return e instanceof DarajaError ? e.message : "Could not start the M-Pesa payment. Please try again.";
  }
}

async function tooManyAttempts(userId: string): Promise<boolean> {
  const recent = await prisma.payment.count({ where: { order: { userId }, createdAt: { gt: new Date(Date.now() - 10 * 60 * 1000) } } });
  return recent >= 3;
}

export async function startMpesaCheckout(_prev: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser("/cart");
  if (!isMpesaConfigured()) return { error: "M-Pesa payments are not set up on this site yet." };
  const phone = normalizeKenyanPhone(String(fd.get("phone") ?? ""));
  if (!phone) return { error: "Enter a valid Safaricom number, for example 0712 345 678." };

  const { lines, notes } = await resolveCart(user.id, await readCart());
  if (lines.length === 0) return { error: notes[0] ?? "Your cart is empty." };
  if (new Set(lines.map((l) => l.currency)).size !== 1 || lines[0].currency !== "KES") return { error: "M-Pesa can only be used for items priced in KES." };
  const total = lines.reduce((n, l) => n + l.unitMinor, 0);
  if (total <= 0) return { error: "Nothing to pay for. Free items are claimed from their own page." };
  if (!isWholeShillings(total)) return { error: "This order total is not a whole number of shillings, so M-Pesa cannot charge it." };
  if (await tooManyAttempts(user.id)) return { error: "Too many payment attempts. Please wait a few minutes and try again." };

  const order = await createOrder(user.id, lines);
  const failure = await initiatePayment(order, phone);
  if (failure) return { error: failure };
  await writeCart([]);
  redirect(`/orders/${order.reference}`);
}

export async function retryPayment(reference: string, _prev: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser(`/orders/${reference}`);
  if (!isMpesaConfigured()) return { error: "M-Pesa payments are not set up on this site yet." };
  const phone = normalizeKenyanPhone(String(fd.get("phone") ?? ""));
  if (!phone) return { error: "Enter a valid Safaricom number, for example 0712 345 678." };

  const order = await prisma.order.findFirst({ where: { reference, userId: user.id }, include: { payments: true } });
  if (!order || !["PENDING", "FAILED", "AWAITING_PAYMENT"].includes(order.status)) return { error: "This order cannot be paid again." };
  if (!isWholeShillings(order.totalMinor) || order.totalMinor <= 0) return { error: "This order cannot be paid with M-Pesa." };

  // Settle any earlier request first so a late success is never charged twice.
  for (const p of order.payments.filter((x) => x.status === "INITIATED" || x.status === "PENDING")) await reconcilePayment(p.id);
  const fresh = await prisma.order.findUnique({ where: { id: order.id }, include: { payments: true } });
  if (!fresh) return { error: "Order not found." };
  if (fresh.status === "PAID") redirect(`/orders/${reference}`);
  if (fresh.payments.some((p) => p.status === "INITIATED" || p.status === "PENDING")) return { error: "A payment request is still waiting. Approve it on your phone or wait a minute." };
  if (await tooManyAttempts(user.id)) return { error: "Too many payment attempts. Please wait a few minutes and try again." };

  const failure = await initiatePayment(fresh, phone);
  if (failure) return { error: failure };
  redirect(`/orders/${reference}`);
}

export async function checkPayment(reference: string) {
  const user = await requireUser(`/orders/${reference}`);
  const order = await prisma.order.findFirst({ where: { reference, userId: user.id }, include: { payments: { orderBy: { createdAt: "desc" }, take: 1 } } });
  const pay = order?.payments[0];
  if (pay && (pay.status === "INITIATED" || pay.status === "PENDING")) await reconcilePayment(pay.id);
  revalidatePath(`/orders/${reference}`);
}
