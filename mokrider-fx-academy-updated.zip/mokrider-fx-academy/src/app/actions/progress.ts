"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/session";

/**
 * Mark a lesson complete or incomplete for the signed-in user. Only enrolled students can track progress,
 * and the user id always comes from the server session, never from the browser.
 */
export async function setLessonComplete(lessonId: string, slug: string, complete: boolean) {
  const user = await requireUser(`/learn/${slug}`);
  const lesson = await prisma.lesson.findFirst({
    where: { id: lessonId, module: { course: { slug, status: "PUBLISHED" } } },
    select: { id: true, module: { select: { courseId: true } } },
  });
  if (!lesson) return;
  const courseId = lesson.module.courseId;
  const enrollment = await prisma.enrollment.findUnique({ where: { userId_courseId: { userId: user.id, courseId } } });
  if (!enrollment) return;

  await prisma.$transaction(async (tx) => {
    if (complete) {
      await tx.lessonProgress.upsert({ where: { userId_lessonId: { userId: user.id, lessonId } }, update: {}, create: { userId: user.id, lessonId } });
    } else {
      await tx.lessonProgress.deleteMany({ where: { userId: user.id, lessonId } });
    }
    const total = await tx.lesson.count({ where: { module: { courseId } } });
    const done = await tx.lessonProgress.count({ where: { userId: user.id, lesson: { module: { courseId } } } });
    await tx.enrollment.update({
      where: { id: enrollment.id },
      data: { completedAt: total > 0 && done >= total ? (enrollment.completedAt ?? new Date()) : null },
    });
  });

  revalidatePath(`/learn/${slug}/lessons/${lessonId}`);
  revalidatePath(`/learn/${slug}`);
  revalidatePath("/dashboard");
}
