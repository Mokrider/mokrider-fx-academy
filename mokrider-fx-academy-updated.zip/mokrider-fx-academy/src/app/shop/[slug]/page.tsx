import type { Metadata } from "next";
import Link from "next/link";
import { AskToBuy } from "@/components/AskToBuy";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { Markdown } from "@/components/Markdown";
import { PriceTag } from "@/components/PriceTag";
import { getCurrentUser } from "@/lib/session";
import { effectivePriceMinor } from "@/lib/commerce/pricing";
import { readCart } from "@/lib/commerce/cartStore";
import { addToCart, claimFree } from "@/app/actions/shop";

type Props = { params: Promise<{ slug: string }> };

async function load(slug: string) {
  return prisma.product.findFirst({ where: { slug, status: "PUBLISHED" }, include: { versions: { where: { isCurrent: true }, take: 1 } } });
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const p = await load(slug);
  if (!p) return { title: "Product not found" };
  const description = p.description.slice(0, 160);
  return { title: p.name, description, alternates: { canonical: `/shop/${p.slug}` }, openGraph: { title: p.name, description, type: "website" } };
}

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const p = await load(slug);
  if (!p) notFound();
  const version = p.versions[0];
  const user = await getCurrentUser();
  const owned = user ? await prisma.entitlement.findFirst({ where: { userId: user.id, kind: "PRODUCT", productId: p.id, status: "ACTIVE" }, select: { id: true } }) : null;
  const inCart = (await readCart()).some((c) => c.kind === "PRODUCT" && c.id === p.id);
  const unit = effectivePriceMinor(p);
  const mb = version ? (version.sizeBytes / (1024 * 1024)).toFixed(1) : null;

  return (
    <PublicShell>
      <Link href="/shop" className="link-accent text-sm">All products</Link>
      <div className="mt-4 grid gap-12 lg:grid-cols-[1.6fr_1fr]">
        <div>
          <h1 className="text-4xl md:text-5xl">{p.name}</h1>
          <div className="mt-8"><Markdown source={p.description} /></div>
          <p className="mt-10 border-t border-line pt-4 text-xs text-muted">Educational content only. No guarantee of trading results.</p>
        </div>
        <aside className="h-fit rounded-md border border-line bg-card p-6 lg:sticky lg:top-24">
          <PriceTag listMinor={p.priceMinor} unitMinor={unit} currency={p.currency} className="font-display text-3xl" />
          <p className="mt-1 text-sm text-muted">{p.format.charAt(0) + p.format.slice(1).toLowerCase()}{version ? ` · version ${version.version}` : ""}{mb ? ` · ${mb} MB` : ""}</p>
          <div className="mt-6">
            {owned ? (
              <>
                <a href={`/api/downloads/${owned.id}`} className="btn btn-primary w-full">Download</a>
                <p className="mt-2 text-xs text-muted">You own this.{p.downloadLimit ? ` Up to ${p.downloadLimit} downloads.` : ""}</p>
              </>
            ) : !version ? (
              <>
                <p className="mb-3 text-sm text-muted">This product is not ready to download yet. Ask us and we will tell you when it is.</p>
                <AskToBuy subject={`Question about: ${p.name}`} message={`Hello,\n\nI am interested in "${p.name}". Please tell me when it is available.\n\nMy name:\n\nThank you.`} label="Ask when it is ready" />
              </>
            ) : unit === 0 ? (
              <form action={claimFree.bind(null, p.id, p.slug)}><button type="submit" className="btn btn-primary w-full">{user ? "Get it free" : "Sign in to get it free"}</button></form>
            ) : inCart ? (
              <Link href="/cart" className="btn btn-primary w-full">In your cart. View cart</Link>
            ) : (
              <form action={addToCart.bind(null, "PRODUCT", p.id)}><button type="submit" className="btn btn-primary w-full">Add to cart</button></form>
            )}
          </div>
        </aside>
      </div>
    </PublicShell>
  );
}
