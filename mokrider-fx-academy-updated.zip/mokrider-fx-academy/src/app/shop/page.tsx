import type { Metadata } from "next";
import Link from "next/link";
import type { Prisma, ProductFormat } from "@prisma/client";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { PriceTag } from "@/components/PriceTag";
import { effectivePriceMinor } from "@/lib/commerce/pricing";

export const metadata: Metadata = {
  title: "Shop",
  description: "Trading PDFs, workbooks, checklists and templates for Gold and EURUSD traders.",
  alternates: { canonical: "/shop" },
};

const FORMATS: [ProductFormat, string][] = [
  ["PDF", "PDF"], ["EBOOK", "E-book"], ["CHECKLIST", "Checklist"], ["WORKBOOK", "Workbook"], ["VIDEO", "Video"], ["TEMPLATE", "Template"], ["JOURNAL", "Journal"], ["TOOL", "Tool"],
];

export default async function ShopPage({ searchParams }: { searchParams: Promise<{ q?: string; format?: string; access?: string }> }) {
  const { q, format, access } = await searchParams;
  const where: Prisma.ProductWhereInput = { status: "PUBLISHED", versions: { some: { isCurrent: true } } };
  if (q) where.OR = [{ name: { contains: q, mode: "insensitive" } }, { description: { contains: q, mode: "insensitive" } }];
  if (format && FORMATS.some(([f]) => f === format)) where.format = format as ProductFormat;
  const products = await prisma.product.findMany({ where, orderBy: { createdAt: "desc" } });
  const now = new Date();
  const shown = products.filter((p) => {
    const free = effectivePriceMinor(p, now) === 0;
    return access === "free" ? free : access === "paid" ? !free : true;
  });
  const filtered = Boolean(q || format || access);

  return (
    <PublicShell>
      <h1 className="text-4xl md:text-5xl">Shop</h1>
      <p className="mt-3 max-w-2xl text-muted">Digital guides, workbooks and templates. Educational content only, with no promise of profit. Pay with M-Pesa.</p>

      <form method="get" role="search" aria-label="Filter products" className="mt-8 grid gap-3 sm:grid-cols-[1fr_auto_auto_auto]">
        <div><label htmlFor="q" className="sr-only">Search products</label><input id="q" name="q" defaultValue={q} placeholder="Search products" className="field" /></div>
        <div><label htmlFor="format" className="sr-only">Format</label>
          <select id="format" name="format" defaultValue={format ?? ""} className="field"><option value="">All formats</option>{FORMATS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>
        <div><label htmlFor="access" className="sr-only">Price</label>
          <select id="access" name="access" defaultValue={access ?? ""} className="field"><option value="">Free and paid</option><option value="free">Free</option><option value="paid">Paid</option></select></div>
        <button type="submit" className="btn btn-primary">Apply</button>
      </form>
      {filtered && <Link href="/shop" className="link-accent mt-3 inline-block text-sm">Clear filters</Link>}

      {shown.length === 0 ? (
        <div className="mt-12 rounded-md border border-dashed border-line p-8"><p className="font-medium">{filtered ? "No products match those filters." : "No products are available yet."}</p></div>
      ) : (
        <ul className="mt-10 divide-y divide-line border-y border-line">
          {shown.map((p) => (
            <li key={p.id} className="grid gap-3 py-6 md:grid-cols-[1.6fr_1fr] md:gap-10">
              <div>
                <h2 className="text-2xl"><Link href={`/shop/${p.slug}`} className="hover:text-accent-text">{p.name}</Link></h2>
                <p className="mt-2 line-clamp-2 text-muted">{p.description}</p>
              </div>
              <div className="text-sm text-muted md:text-right">
                <p>{FORMATS.find(([f]) => f === p.format)?.[1]}</p>
                <PriceTag listMinor={p.priceMinor} unitMinor={effectivePriceMinor(p, now)} currency={p.currency} className="mt-1 block text-base font-semibold text-fg" />
              </div>
            </li>
          ))}
        </ul>
      )}
    </PublicShell>
  );
}
