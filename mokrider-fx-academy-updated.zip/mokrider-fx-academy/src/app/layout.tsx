import type { Metadata } from "next";
import { Montserrat, Schibsted_Grotesk, Yellowtail } from "next/font/google";
import "./globals.css";

const display = Montserrat({ subsets: ["latin"], weight: ["700", "800", "900"], style: ["normal", "italic"], variable: "--font-montserrat", display: "swap" });
const script = Yellowtail({ subsets: ["latin"], weight: "400", variable: "--font-script", display: "swap" });
const sans = Schibsted_Grotesk({ subsets: ["latin"], variable: "--font-grotesk", display: "swap" });

const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(appUrl),
  title: { default: "MOKRIDER FX ACADEMY | Learn the Market. Master Your Process.", template: "%s | MOKRIDER FX ACADEMY" },
  description:
    "Trading education for XAUUSD (Gold) and EURUSD: structured courses, risk-first mentorship and practical tools. Educational content only. Trading involves risk of loss.",
  openGraph: {
    siteName: "MOKRIDER FX ACADEMY",
    type: "website",
    title: "MOKRIDER FX ACADEMY | Learn the Market. Master Your Process.",
    description: "Risk-first Gold and EURUSD education: courses, mentorship and tools that show their working.",
  },
  twitter: { card: "summary_large_image", title: "MOKRIDER FX ACADEMY", description: "Risk-first Gold and EURUSD education from Nairobi." },
};

const orgJsonLd = JSON.stringify({
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  name: "MOKRIDER FX ACADEMY",
  url: appUrl,
  description: "Trading education for XAUUSD (Gold) and EURUSD. Educational content only; trading involves risk of loss.",
});

// Runs before paint so the saved theme is applied without a flash. Dark is the default.
const themeScript = `try{var t=localStorage.getItem("theme");document.documentElement.setAttribute("data-theme",t==="light"?"light":"dark")}catch(e){document.documentElement.setAttribute("data-theme","dark")}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark" suppressHydrationWarning className={`${display.variable} ${sans.variable} ${script.variable}`}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body>
        <a href="#main" className="skip-link">Skip to main content</a>
        {children}
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: orgJsonLd }} />
      </body>
    </html>
  );
}
