import type { Metadata } from "next";
import Link from "next/link";
import type { CourseLevel, Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { formatMoney } from "@/lib/money";

export const metadata: Metadata = {
  title: "Courses",
  description: "Trading courses covering market structure, liquidity, Gold, EURUSD, risk management and psychology.",
  alternates: { canonical: "/learn" },
};

const LEVELS = ["BEGINNER", "INTERMEDIATE", "ADVANCED"] as const;
const levelLabel = { BEGINNER: "Beginner", INTERMEDIATE: "Intermediate", ADVANCED: "Advanced" } as const;

export default async function LearnPage({ searchParams }: { searchParams: Promise<{ q?: string; level?: string; access?: string }> }) {
  const { q, level, access } = await searchParams;
  const where: Prisma.CourseWhereInput = { status: "PUBLISHED" };
  if (q) where.OR = [{ title: { contains: q, mode: "insensitive" } }, { summary: { contains: q, mode: "insensitive" } }];
  if (level && (LEVELS as readonly string[]).includes(level)) where.level = level as CourseLevel;
  if (access === "free") where.isFree = true;
  if (access === "paid") where.isFree = false;

  const courses = await prisma.course.findMany({
    where,
    orderBy: { createdAt: "asc" },
    include: { modules: { select: { _count: { select: { lessons: true } } } } },
  });
  const filtered = Boolean(q || level || access);

  return (
    <PublicShell>
      <h1 className="text-4xl md:text-5xl">Courses</h1>
      <p className="mt-3 max-w-2xl text-muted">Structured learning for XAUUSD and EURUSD. Educational content only, with no promise of profit.</p>

      <form method="get" className="mt-8 grid gap-3 sm:grid-cols-[1fr_auto_auto_auto]" role="search" aria-label="Filter courses">
        <div>
          <label htmlFor="q" className="sr-only">Search courses</label>
          <input id="q" name="q" defaultValue={q} placeholder="Search courses" className="field" />
        </div>
        <div>
          <label htmlFor="level" className="sr-only">Level</label>
          <select id="level" name="level" defaultValue={level ?? ""} className="field">
            <option value="">All levels</option>
            {LEVELS.map((l) => <option key={l} value={l}>{levelLabel[l]}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="access" className="sr-only">Access</label>
          <select id="access" name="access" defaultValue={access ?? ""} className="field">
            <option value="">Free and paid</option>
            <option value="free">Free</option>
            <option value="paid">Paid</option>
          </select>
        </div>
        <button type="submit" className="btn btn-primary">Apply</button>
      </form>
      {filtered && <Link href="/learn" className="link-accent mt-3 inline-block text-sm">Clear filters</Link>}

      {courses.length === 0 ? (
        <div className="mt-12 rounded-md border border-dashed border-line p-8">
          <p className="font-medium">{filtered ? "No courses match those filters." : "No courses are published yet."}</p>
          <p className="mt-1 text-sm text-muted">{filtered ? "Try a different search." : "New courses appear here as soon as they are published."}</p>
        </div>
      ) : (
        <ul className="mt-10 divide-y divide-line border-y border-line">
          {courses.map((c) => {
            const lessons = c.modules.reduce((n, m) => n + m._count.lessons, 0);
            return (
              <li key={c.id} className="py-6">
                <div className="grid gap-3 md:grid-cols-[1.4fr_1fr] md:gap-10">
                  <div>
                    <h2 className="text-2xl"><Link href={`/learn/${c.slug}`} className="hover:text-accent-text">{c.title}</Link></h2>
                    <p className="mt-2 text-muted">{c.summary}</p>
                  </div>
                  <div className="text-sm text-muted md:text-right">
                    <p>{levelLabel[c.level]} &middot; {lessons} lesson{lessons === 1 ? "" : "s"}{c.outlineOnly ? " (outline)" : ""}</p>
                    <p className="mt-1 font-semibold text-fg">{c.isFree ? "Free" : c.priceMinor > 0 ? formatMoney(c.priceMinor, c.currency) : "Price to be announced"}</p>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </PublicShell>
  );
}
