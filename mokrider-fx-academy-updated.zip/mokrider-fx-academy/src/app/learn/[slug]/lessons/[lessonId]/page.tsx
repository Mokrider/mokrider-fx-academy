import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { Markdown } from "@/components/Markdown";
import { getCurrentUser } from "@/lib/session";
import { neighbours } from "@/lib/learning/nav";
import { toEmbedUrl } from "@/lib/learning/video";
import { setLessonComplete } from "@/app/actions/progress";

type Props = { params: Promise<{ slug: string; lessonId: string }> };

export const metadata: Metadata = { title: "Lesson", robots: { index: false, follow: false } };

export default async function LessonPage({ params }: Props) {
  const { slug, lessonId } = await params;

  const meta = await prisma.lesson.findUnique({
    where: { id: lessonId },
    select: {
      id: true, title: true, kind: true, isFreePreview: true, durationMinutes: true,
      module: { select: { course: { select: { id: true, slug: true, title: true, status: true, outlineOnly: true } } } },
    },
  });
  if (!meta || meta.module.course.slug !== slug) notFound();
  const course = meta.module.course;

  const user = await getCurrentUser();
  const isAdmin = user?.role === "ADMIN";
  if (course.status !== "PUBLISHED" && !isAdmin) notFound();

  const enrolled = user ? Boolean(await prisma.enrollment.findUnique({ where: { userId_courseId: { userId: user.id, courseId: course.id } }, select: { id: true } })) : false;
  const allowed = meta.isFreePreview || enrolled || isAdmin;

  const all = await prisma.lesson.findMany({
    where: { module: { courseId: course.id } },
    orderBy: [{ module: { position: "asc" } }, { position: "asc" }],
    select: { id: true, title: true, isFreePreview: true, module: { select: { id: true, title: true } } },
  });
  const completed = new Set<string>();
  if (user && enrolled) {
    const rows = await prisma.lessonProgress.findMany({ where: { userId: user.id, lessonId: { in: all.map((l) => l.id) } }, select: { lessonId: true } });
    rows.forEach((r) => completed.add(r.lessonId));
  }
  const canOpen = (l: { isFreePreview: boolean }) => l.isFreePreview || enrolled || isAdmin;
  const { prev, next } = neighbours(all, lessonId);
  const done = completed.has(lessonId);

  // Content is only read from the database once access has been confirmed.
  const full = allowed ? await prisma.lesson.findUnique({ where: { id: lessonId }, select: { content: true, videoUrl: true } }) : null;
  const embed = full?.videoUrl ? toEmbedUrl(full.videoUrl) : null;

  const sidebar = (
    <nav aria-label="Course lessons" className="text-sm">
      <p className="mb-3 font-semibold">{course.title}</p>
      {all.map((l, i) => (
        <div key={l.id}>
          {(i === 0 || all[i - 1].module.id !== l.module.id) && <p className="mb-1 mt-4 text-xs uppercase tracking-wide text-muted">{l.module.title}</p>}
          {canOpen(l) ? (
            <Link href={`/learn/${slug}/lessons/${l.id}`} aria-current={l.id === lessonId ? "page" : undefined}
              className={`flex items-start gap-2 rounded px-2 py-1.5 hover:bg-card ${l.id === lessonId ? "bg-card text-fg" : "text-muted"}`}>
              <span aria-hidden className="w-4 shrink-0">{completed.has(l.id) ? "✓" : ""}</span>
              <span>{l.title}{completed.has(l.id) && <span className="sr-only"> (completed)</span>}</span>
            </Link>
          ) : (
            <p className="flex items-start gap-2 px-2 py-1.5 text-muted/70"><span aria-hidden className="w-4 shrink-0" /><span>{l.title} <span className="text-xs">(enrolled students)</span></span></p>
          )}
        </div>
      ))}
    </nav>
  );

  return (
    <PublicShell>
      <Link href={`/learn/${slug}`} className="link-accent text-sm">Back to course</Link>
      <div className="mt-4 grid gap-10 lg:grid-cols-[18rem_1fr]">
        <aside className="lg:sticky lg:top-24 lg:h-fit">
          <details className="lg:hidden rounded-md border border-line p-3"><summary className="cursor-pointer text-sm font-medium">Lessons</summary><div className="mt-3">{sidebar}</div></details>
          <div className="hidden lg:block">{sidebar}</div>
        </aside>

        <article className="min-w-0 max-w-3xl">
          <h1 className="text-3xl md:text-4xl">{meta.title}</h1>
          {meta.durationMinutes && <p className="mt-2 text-sm text-muted">About {meta.durationMinutes} min</p>}

          {!allowed ? (
            <div className="mt-8 rounded-md border border-line bg-card p-6">
              <p className="font-medium">This lesson is for enrolled students.</p>
              <p className="mt-1 text-sm text-muted">Open the course page to see how to enroll.</p>
              <Link href={`/learn/${slug}`} className="btn btn-primary mt-4">View course</Link>
            </div>
          ) : (
            <>
              {course.outlineOnly && <p className="mt-6 rounded-md border border-line bg-surface p-4 text-sm">This course is still an outline, so this lesson has no full content yet.</p>}
              {isAdmin && !enrolled && <p className="mt-6 rounded-md border border-accent p-3 text-sm">Admin view. Progress is not tracked for this account.</p>}
              {meta.kind === "QUIZ" && <p className="mt-6 rounded-md border border-line bg-surface p-4 text-sm">Quiz lessons are not available yet.</p>}
              {full?.videoUrl && (embed ? (
                <iframe src={embed} title={`${meta.title} video`} className="mt-6 aspect-video w-full rounded-md border border-line" loading="lazy" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" />
              ) : (
                <p className="mt-6 text-sm text-down">The video link for this lesson is not from a supported provider.</p>
              ))}
              {full?.content && <div className="mt-8"><Markdown source={full.content} /></div>}

              <div className="mt-10 border-t border-line pt-6">
                {enrolled ? (
                  <form action={setLessonComplete.bind(null, lessonId, slug, !done)}>
                    <button type="submit" className={`btn ${done ? "btn-ghost" : "btn-primary"}`}>{done ? "Completed. Mark as not done" : "Mark as complete"}</button>
                  </form>
                ) : !isAdmin ? (
                  <p className="text-sm text-muted">This is a free preview. <Link href={`/learn/${slug}`} className="link-accent">Enroll</Link> to track your progress.</p>
                ) : null}
              </div>
            </>
          )}

          <nav aria-label="Lesson navigation" className="mt-8 flex justify-between gap-4">
            {prev ? <Link href={`/learn/${slug}/lessons/${prev}`} className="btn btn-ghost">Previous</Link> : <span />}
            {next ? <Link href={`/learn/${slug}/lessons/${next}`} className="btn btn-ghost">Next</Link> : <span />}
          </nav>
          <p className="mt-10 text-xs text-muted">Educational content only. No guarantee of trading results.</p>
        </article>
      </div>
    </PublicShell>
  );
}
