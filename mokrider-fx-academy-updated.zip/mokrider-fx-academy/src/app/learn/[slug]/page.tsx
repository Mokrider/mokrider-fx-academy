import type { Metadata } from "next";
import Link from "next/link";
import { AskToBuy } from "@/components/AskToBuy";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { PublicShell } from "@/components/PublicShell";
import { Markdown } from "@/components/Markdown";
import { formatMoney } from "@/lib/money";
import { getCurrentUser } from "@/lib/session";
import { courseProgressFor } from "@/lib/progress";
import { enrollFree } from "@/app/actions/enroll";
import { addToCart } from "@/app/actions/shop";

type Props = { params: Promise<{ slug: string }> };

async function getCourse(slug: string) {
  return prisma.course.findFirst({
    where: { slug, status: "PUBLISHED" },
    include: { modules: { orderBy: { position: "asc" }, include: { lessons: { orderBy: { position: "asc" }, select: { id: true, title: true, isFreePreview: true } } } } },
  });
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const c = await getCourse(slug);
  if (!c) return { title: "Course not found" };
  return { title: c.title, description: c.summary, alternates: { canonical: `/learn/${c.slug}` }, openGraph: { title: c.title, description: c.summary, type: "website" } };
}

export default async function CoursePage({ params }: Props) {
  const { slug } = await params;
  const course = await getCourse(slug);
  if (!course) notFound();
  const user = await getCurrentUser();
  const enrolled = user ? Boolean(await prisma.enrollment.findUnique({ where: { userId_courseId: { userId: user.id, courseId: course.id } }, select: { id: true } })) : false;
  const lessonCount = course.modules.reduce((n, m) => n + m.lessons.length, 0);

  const completed = new Set<string>();
  let progress: Awaited<ReturnType<typeof courseProgressFor>>[string] | undefined;
  if (user && enrolled) {
    const rows = await prisma.lessonProgress.findMany({ where: { userId: user.id, lesson: { module: { courseId: course.id } } }, select: { lessonId: true } });
    rows.forEach((r) => completed.add(r.lessonId));
    progress = (await courseProgressFor(user.id, [course.id]))[course.id];
  }

  return (
    <PublicShell>
      <Link href="/learn" className="link-accent text-sm">All courses</Link>
      <div className="mt-4 grid gap-12 lg:grid-cols-[1.6fr_1fr]">
        <div>
          <h1 className="text-4xl md:text-5xl">{course.title}</h1>
          <p className="mt-4 text-lg text-muted">{course.summary}</p>
          {course.outlineOnly && (
            <p className="mt-6 rounded-md border border-line bg-surface p-4 text-sm">
              This course is currently an outline. The topics below are planned, and full lesson content is still being written.
            </p>
          )}
          {course.description && <div className="mt-8"><Markdown source={course.description} /></div>}

          <h2 className="mt-12 text-2xl">Syllabus</h2>
          <p className="mt-1 text-sm text-muted">{lessonCount} topic{lessonCount === 1 ? "" : "s"}</p>
          <div className="mt-4 space-y-6">
            {course.modules.map((m) => (
              <section key={m.id}>
                <h3 className="text-lg">{m.title}</h3>
                <ul className="mt-2 divide-y divide-line border-y border-line text-sm">
                  {m.lessons.map((l) => {
                    const open = enrolled || l.isFreePreview;
                    return (
                      <li key={l.id} className="flex justify-between gap-4 py-2">
                        <span>
                          {completed.has(l.id) && <span aria-hidden className="mr-2">✓</span>}
                          {open ? <Link href={`/learn/${course.slug}/lessons/${l.id}`} className="hover:text-accent-text">{l.title}</Link> : l.title}
                          {completed.has(l.id) && <span className="sr-only"> (completed)</span>}
                        </span>
                        {l.isFreePreview && <span className="text-accent-text">Free preview</span>}
                      </li>
                    );
                  })}
                </ul>
              </section>
            ))}
          </div>
        </div>

        <aside className="h-fit rounded-md border border-line bg-card p-6 lg:sticky lg:top-24">
          <p className="font-display text-3xl">{course.isFree ? "Free" : course.priceMinor > 0 ? formatMoney(course.priceMinor, course.currency) : "Price to be announced"}</p>
          <p className="mt-1 text-sm text-muted">{course.level.charAt(0) + course.level.slice(1).toLowerCase()} level</p>
          <div className="mt-6">
            {enrolled ? (
              <>
                {progress && <p className="mb-3 text-sm text-muted">{progress.completed} of {progress.total} lessons complete ({progress.percent}%)</p>}
                {progress?.nextLessonId ? (
                  <Link href={`/learn/${course.slug}/lessons/${progress.nextLessonId}`} className="btn btn-primary w-full">{progress.completed > 0 ? "Continue learning" : "Start learning"}</Link>
                ) : (
                  <Link href="/dashboard" className="btn btn-primary w-full">Open dashboard</Link>
                )}
              </>
            ) : course.isFree ? (
              <form action={enrollFree.bind(null, course.id, course.slug)}>
                <button type="submit" className="btn btn-primary w-full">{user ? "Enroll for free" : "Sign in to enroll"}</button>
              </form>
            ) : (
              course.priceMinor > 0 ? (
                <>
                  <form action={addToCart.bind(null, "COURSE", course.id)}><button type="submit" className="btn btn-primary w-full">Add to cart</button></form>
                  <p className="mt-3 text-xs text-muted">Pay with M-Pesa at checkout. You get access once the payment is verified.</p>
                </>
              ) : (
                <>
                  <p className="mb-3 text-sm text-muted">The price for this course has not been set yet. Ask us and we will tell you the price and when it opens.</p>
                  <AskToBuy subject={`Question about the course: ${course.title}`} message={`Hello,\n\nI am interested in the course "${course.title}". Please tell me the price and when it starts.\n\nMy name:\n\nThank you.`} label="Ask about this course" />
                </>
              )
            )}
          </div>
          <p className="mt-6 text-xs text-muted">Educational content only. No guarantee of trading results.</p>
        </aside>
      </div>
    </PublicShell>
  );
}
