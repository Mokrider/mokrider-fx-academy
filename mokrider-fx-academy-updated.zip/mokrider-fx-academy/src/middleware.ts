import { NextResponse, type NextRequest } from "next/server";
import { getSessionCookie } from "better-auth/cookies";
import { securityHeaders } from "@/lib/security/headers";

const PROTECTED = [/^\/dashboard(\/|$)/, /^\/admin(\/|$)/, /^\/tools\/journal(\/|$)/, /^\/orders(\/|$)/];

// Optimistic redirect only. Real authorisation happens on the server in requireUser/requireRole.
export function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname;
  let response: NextResponse;
  if (PROTECTED.some((r) => r.test(path)) && !getSessionCookie(request)) {
    const url = new URL("/login", request.url);
    url.searchParams.set("next", path);
    response = NextResponse.redirect(url);
  } else {
    response = NextResponse.next();
  }
  for (const [key, value] of Object.entries(securityHeaders())) response.headers.set(key, value);
  return response;
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)"] };
