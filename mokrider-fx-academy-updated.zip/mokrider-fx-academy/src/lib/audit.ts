import "server-only";
import { prisma } from "@/lib/db";

export async function audit(actorId: string, action: string, entity: string, entityId?: string, meta?: Record<string, string | number | boolean | null>) {
  try {
    await prisma.auditLog.create({ data: { actorId, action, entity, entityId, meta: meta ?? undefined } });
  } catch (e) {
    console.error("audit log failed", e);
  }
}
