export const ROLES = ["STUDENT", "MEMBER", "MENTOR", "ADMIN"] as const;
export type RoleName = (typeof ROLES)[number];

const RANK: Record<RoleName, number> = { STUDENT: 1, MEMBER: 2, MENTOR: 3, ADMIN: 4 };

/** True when `role` is at least as privileged as `minimum`. Guests (null) never pass. */
export function hasRoleAtLeast(role: RoleName | null | undefined, minimum: RoleName): boolean {
  if (!role) return false;
  return RANK[role] >= RANK[minimum];
}

export type Action =
  | "admin:access"
  | "users:manage"
  | "orders:view"
  | "content:manage"
  | "enrollments:view";

const REQUIRED_ROLE: Record<Action, RoleName> = {
  "admin:access": "ADMIN",
  "users:manage": "ADMIN",
  "orders:view": "ADMIN",
  "content:manage": "MENTOR",
  "enrollments:view": "MENTOR",
};

export function can(role: RoleName | null | undefined, action: Action): boolean {
  return hasRoleAtLeast(role, REQUIRED_ROLE[action]);
}
