import "server-only";
import { betterAuth } from "better-auth";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { nextCookies } from "better-auth/next-js";
import { prisma } from "@/lib/db";
import { brandedEmail, sendEmail } from "@/lib/email";

const verificationOn = process.env.EMAIL_VERIFICATION === "true";
const googleOn = Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);

export const auth = betterAuth({
  database: prismaAdapter(prisma, { provider: "postgresql" }),
  emailAndPassword: {
    enabled: true,
    minPasswordLength: 10,
    requireEmailVerification: verificationOn,
    sendResetPassword: async ({ user, url }) => {
      await sendEmail({
        to: user.email,
        subject: "Reset your MOKRIDER FX ACADEMY password",
        html: brandedEmail("Reset your password", `<p>Use this link to choose a new password:</p><p><a href="${url}" style="color:#FF6B6B">${url}</a></p><p>If you did not ask for this, ignore this email.</p>`),
        text: `Reset your password: ${url}`,
      });
    },
  },
  emailVerification: {
    sendOnSignUp: verificationOn,
    sendVerificationEmail: async ({ user, url }) => {
      await sendEmail({
        to: user.email,
        subject: "Verify your email",
        html: brandedEmail("Verify your email", `<p><a href="${url}" style="color:#FF6B6B">Confirm your email address</a></p>`),
        text: `Verify your email: ${url}`,
      });
    },
  },
  socialProviders: googleOn
    ? { google: { clientId: process.env.GOOGLE_CLIENT_ID!, clientSecret: process.env.GOOGLE_CLIENT_SECRET! } }
    : {},
  user: {
    additionalFields: {
      // input:false means a client can never set its own role during sign-up.
      role: { type: "string", defaultValue: "STUDENT", input: false },
    },
  },
  // Per-instance limits on the sign-in family of endpoints (Better Auth keeps these counters in memory).
  rateLimit: {
    enabled: true, window: 60, max: 100,
    customRules: {
      "/sign-in/email": { window: 60, max: 5 },
      "/sign-up/email": { window: 3600, max: 10 },
      "/request-password-reset": { window: 3600, max: 5 },
      "/forget-password": { window: 3600, max: 5 },
    },
  },
  plugins: [nextCookies()],
});
