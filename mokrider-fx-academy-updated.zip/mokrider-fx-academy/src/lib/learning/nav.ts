/** Previous and next lesson ids in course order. */
export function neighbours(order: { id: string }[], currentId: string): { prev: string | null; next: string | null } {
  const i = order.findIndex((l) => l.id === currentId);
  if (i === -1) return { prev: null, next: null };
  return { prev: order[i - 1]?.id ?? null, next: order[i + 1]?.id ?? null };
}

/** The first lesson not yet completed. Null when the course is empty or everything is complete. */
export function firstIncomplete(order: { id: string }[], completed: ReadonlySet<string>): string | null {
  return order.find((l) => !completed.has(l.id))?.id ?? null;
}
