/**
 * Turns a YouTube or Vimeo link into an embed URL. Anything else returns null, so lessons can only
 * embed from these providers. YouTube uses the privacy-enhanced domain.
 */
export function toEmbedUrl(input: string): string | null {
  let u: URL;
  try { u = new URL(input.trim()); } catch { return null; }
  if (u.protocol !== "https:") return null;
  const host = u.hostname.replace(/^www\./, "");
  const parts = u.pathname.split("/").filter(Boolean);

  let yt: string | null = null;
  if (host === "youtu.be") yt = parts[0] ?? null;
  else if (host === "youtube.com" || host === "m.youtube.com") {
    if (u.pathname === "/watch") yt = u.searchParams.get("v");
    else if (["embed", "shorts", "live"].includes(parts[0] ?? "")) yt = parts[1] ?? null;
  }
  if (yt && /^[\w-]{11}$/.test(yt)) return `https://www.youtube-nocookie.com/embed/${yt}`;

  if (host === "vimeo.com" && /^\d+$/.test(parts[0] ?? "")) return `https://player.vimeo.com/video/${parts[0]}`;
  if (host === "player.vimeo.com" && parts[0] === "video" && /^\d+$/.test(parts[1] ?? "")) return `https://player.vimeo.com/video/${parts[1]}`;
  return null;
}
