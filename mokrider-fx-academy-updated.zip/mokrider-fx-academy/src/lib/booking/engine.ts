import "server-only";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { createOrder, type CheckoutLine } from "@/lib/commerce/checkout";
import { formatEat } from "@/lib/time";
import { blackoutDates } from "@/lib/booking/slots";
import { BOOKING_ERRORS, canStudentCancel, holdActive, isBlackout, overlaps, seatsTaken, slotBookable, type BookingErrorCode } from "@/lib/booking/rules";

type Tx = Prisma.TransactionClient;

export class BookingError extends Error {
  constructor(public code: BookingErrorCode) { super(BOOKING_ERRORS[code]); }
}

/** Row lock on the slot: two people booking the last seat at the same moment are handled one after the other. */
async function lockSlot(tx: Tx, slotId: string) {
  await tx.$queryRaw`SELECT id FROM "AvailabilitySlot" WHERE id = ${slotId} FOR UPDATE`;
}

export async function reserveSlot(userId: string, slotId: string): Promise<{ bookingId: string; reference: string | null; confirmedNow: boolean }> {
  const now = new Date();
  const blackout = await blackoutDates();

  return prisma.$transaction(async (tx) => {
    await lockSlot(tx, slotId);
    const slot = await tx.availabilitySlot.findUnique({
      where: { id: slotId },
      include: { package: true, bookings: { select: { id: true, userId: true, status: true, createdAt: true } } },
    });
    if (!slot || slot.package.status !== "PUBLISHED") throw new BookingError("unavailable");
    if (!slotBookable(slot.startsAt, now)) throw new BookingError("notice");
    if (isBlackout(slot.startsAt, blackout)) throw new BookingError("blackout");

    const mine = slot.bookings.find((b) => b.userId === userId);
    if (mine && mine.status !== "CANCELLED") throw new BookingError("exists");

    const others = slot.bookings.filter((b) => b.userId !== userId);
    if (seatsTaken(others, now) >= slot.capacity) throw new BookingError("full");

    if (slot.package.enrollmentLimit) {
      const pkg = await tx.booking.findMany({
        where: { packageId: slot.packageId, userId: { not: userId }, status: { in: ["CONFIRMED", "COMPLETED", "AWAITING_PAYMENT", "REQUESTED"] } },
        select: { status: true, createdAt: true },
      });
      if (seatsTaken(pkg, now) >= slot.package.enrollmentLimit) throw new BookingError("limit");
    }

    const clashing = await tx.booking.findMany({
      where: { userId, slotId: { not: slotId }, status: { in: ["CONFIRMED", "AWAITING_PAYMENT"] } },
      include: { slot: { select: { startsAt: true, endsAt: true } } },
    });
    for (const b of clashing) {
      if (b.status === "AWAITING_PAYMENT" && !holdActive(b.createdAt, now)) continue;
      if (overlaps(slot.startsAt, slot.endsAt, b.slot.startsAt, b.slot.endsAt)) throw new BookingError("overlap");
    }

    const free = slot.package.priceMinor === 0;
    let order: { id: string; reference: string } | null = null;
    if (!free) {
      const line: CheckoutLine = {
        kind: "BOOKING", id: slot.package.id, title: `${slot.package.title} (${formatEat(slot.startsAt)})`, slug: slot.package.slug,
        listMinor: slot.package.priceMinor, unitMinor: slot.package.priceMinor, currency: slot.package.currency,
      };
      order = await createOrder(userId, [line], tx);
    }

    const data = { status: free ? ("CONFIRMED" as const) : ("AWAITING_PAYMENT" as const), orderId: order?.id ?? null };
    const booking = mine
      ? await tx.booking.update({ where: { id: mine.id }, data: { ...data, createdAt: now } })
      : await tx.booking.create({ data: { userId, packageId: slot.packageId, slotId, ...data } });
    return { bookingId: booking.id, reference: order?.reference ?? null, confirmedNow: free };
  }, { timeout: 15_000 });
}

/**
 * Called inside the payment-fulfilment transaction. If the seat is still free the booking is confirmed.
 * If the seat was lost while the person was paying, the booking is cancelled and a refund request is
 * recorded automatically so the money is never silently kept.
 */
export async function confirmBookingForOrderTx(tx: Tx, orderId: string): Promise<void> {
  const booking = await tx.booking.findFirst({ where: { orderId }, include: { slot: true, order: { select: { totalMinor: true, currency: true } } } });
  if (!booking || booking.status === "CONFIRMED") return;
  await lockSlot(tx, booking.slotId);
  const others = await tx.booking.findMany({ where: { slotId: booking.slotId, id: { not: booking.id } }, select: { status: true, createdAt: true } });
  if (seatsTaken(others, new Date()) < booking.slot.capacity) {
    await tx.booking.update({ where: { id: booking.id }, data: { status: "CONFIRMED" } });
  } else {
    await tx.booking.update({ where: { id: booking.id }, data: { status: "CANCELLED" } });
    await tx.refund.create({
      data: {
        orderId, amountMinor: booking.order?.totalMinor ?? 0, currency: booking.order?.currency ?? "KES", status: "REQUESTED", requestedById: "system",
        reason: "Payment was received after the seat was no longer available. Refund requested automatically.",
      },
    });
  }
}

export type CancelResult = { ok: true; refundRequested: boolean } | { ok: false; code: "notfound" | "state" | "window" | "payment" };

/** Cancel a booking. Students: own bookings only, up to 24 hours before. Admins: any booking, any time. */
export async function cancelBookingFor(actor: { id: string; admin: boolean }, bookingId: string): Promise<CancelResult> {
  const now = new Date();
  return prisma.$transaction(async (tx) => {
    const b = await tx.booking.findFirst({
      where: actor.admin ? { id: bookingId } : { id: bookingId, userId: actor.id },
      include: { slot: true, order: { include: { payments: true } } },
    });
    if (!b) return { ok: false as const, code: "notfound" as const };
    if (!["CONFIRMED", "AWAITING_PAYMENT", "REQUESTED"].includes(b.status)) return { ok: false as const, code: "state" as const };
    if (!actor.admin && b.status === "CONFIRMED" && !canStudentCancel(b.slot.startsAt, now)) return { ok: false as const, code: "window" as const };

    if (b.status === "AWAITING_PAYMENT" && b.order) {
      if (b.order.payments.some((p) => ["INITIATED", "PENDING", "SUCCEEDED"].includes(p.status))) return { ok: false as const, code: "payment" as const };
      await tx.order.updateMany({ where: { id: b.order.id, status: { in: ["PENDING", "AWAITING_PAYMENT", "FAILED"] } }, data: { status: "CANCELLED" } });
    }
    await tx.booking.update({ where: { id: b.id }, data: { status: "CANCELLED" } });

    let refundRequested = false;
    if (b.order?.status === "PAID") {
      refundRequested = true;
      const existing = await tx.refund.count({ where: { orderId: b.order.id, status: { in: ["REQUESTED", "PROCESSED"] } } });
      if (!existing) {
        await tx.refund.create({
          data: {
            orderId: b.order.id, amountMinor: b.order.totalMinor, currency: b.order.currency, status: "REQUESTED", requestedById: actor.id,
            reason: actor.admin ? "Booking cancelled by an administrator." : "Cancelled by the student more than 24 hours before the session.",
          },
        });
      }
    }
    return { ok: true as const, refundRequested };
  });
}

export type RescheduleResult = { ok: true } | { ok: false; message: string };

export async function rescheduleBooking(bookingId: string, newSlotId: string): Promise<RescheduleResult> {
  const now = new Date();
  try {
    return await prisma.$transaction(async (tx): Promise<RescheduleResult> => {
      await lockSlot(tx, newSlotId);
      const booking = await tx.booking.findUnique({ where: { id: bookingId } });
      const slot = await tx.availabilitySlot.findUnique({ where: { id: newSlotId }, include: { bookings: { select: { id: true, userId: true, status: true, createdAt: true } } } });
      if (!booking || !slot) return { ok: false, message: "Booking or session not found." };
      if (!["CONFIRMED", "AWAITING_PAYMENT"].includes(booking.status)) return { ok: false, message: "Only active bookings can be moved." };
      if (slot.packageId !== booking.packageId) return { ok: false, message: "Choose a session of the same package." };
      if (slot.startsAt <= now) return { ok: false, message: "Choose a future session." };
      if (slot.bookings.some((b) => b.userId === booking.userId && b.status !== "CANCELLED")) return { ok: false, message: "This student already has a booking on that session." };
      if (seatsTaken(slot.bookings.filter((b) => b.id !== booking.id), now) >= slot.capacity) return { ok: false, message: "That session is full." };
      await tx.booking.update({ where: { id: booking.id }, data: { slotId: slot.id, reminderSentAt: null } });
      return { ok: true };
    }, { timeout: 15_000 });
  } catch {
    return { ok: false, message: "Could not move the booking. Please try again." };
  }
}
