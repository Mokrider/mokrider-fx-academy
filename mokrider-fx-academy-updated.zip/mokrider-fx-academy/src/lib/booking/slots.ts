import "server-only";
import { prisma } from "@/lib/db";
import { MIN_NOTICE_MS, isBlackout, seatsTaken } from "@/lib/booking/rules";

export async function blackoutDates(): Promise<string[]> {
  const row = await prisma.siteSetting.findUnique({ where: { key: "booking" } });
  const v = row?.value as { blackoutDates?: unknown } | null;
  return Array.isArray(v?.blackoutDates) ? (v.blackoutDates as unknown[]).filter((d): d is string => typeof d === "string") : [];
}

export type OpenSlot = { id: string; packageId: string; startsAt: Date; endsAt: Date; capacity: number; seatsLeft: number };

/** Upcoming bookable slots with seats left. The meeting link is deliberately not selected here. */
export async function openSlots(packageIds: string[], now = new Date()): Promise<OpenSlot[]> {
  if (packageIds.length === 0) return [];
  const blackout = await blackoutDates();
  const slots = await prisma.availabilitySlot.findMany({
    where: { packageId: { in: packageIds }, startsAt: { gte: new Date(now.getTime() + MIN_NOTICE_MS) } },
    orderBy: { startsAt: "asc" }, take: 300,
    select: { id: true, packageId: true, startsAt: true, endsAt: true, capacity: true, bookings: { select: { status: true, createdAt: true } } },
  });
  return slots
    .filter((s) => !isBlackout(s.startsAt, blackout))
    .map((s) => ({ id: s.id, packageId: s.packageId, startsAt: s.startsAt, endsAt: s.endsAt, capacity: s.capacity, seatsLeft: s.capacity - seatsTaken(s.bookings, now) }))
    .filter((s) => s.seatsLeft > 0);
}
