import { toEatInput } from "../time";

export const MIN_NOTICE_MS = 2 * 3600 * 1000; // bookings close 2 hours before a session
export const CANCEL_WINDOW_MS = 24 * 3600 * 1000; // students may cancel up to 24 hours before
export const HOLD_MS = 30 * 60 * 1000; // an unpaid booking holds its seat for 30 minutes
export const REMINDER_WINDOW_MS = 36 * 3600 * 1000;

export const BOOKING_ERRORS = {
  full: "That session is full. Please choose another time.",
  notice: "Bookings close 2 hours before a session starts.",
  blackout: "That date is not available for sessions.",
  exists: "You already have a booking for that session.",
  overlap: "You already have another session at that time.",
  unavailable: "That session is not available any more.",
  limit: "This package has reached its enrollment limit.",
  rate: "Too many booking attempts. Please try again later.",
} as const;
export type BookingErrorCode = keyof typeof BOOKING_ERRORS;

export type SeatBooking = { status: string; createdAt: Date };

export function holdActive(createdAt: Date, now: Date): boolean {
  return createdAt.getTime() > now.getTime() - HOLD_MS;
}

/** Confirmed and finished bookings always take a seat. Unpaid bookings hold one only for a short time. */
export function seatsTaken(bookings: SeatBooking[], now: Date): number {
  return bookings.filter((b) =>
    b.status === "CONFIRMED" || b.status === "COMPLETED" || b.status === "NO_SHOW" ||
    ((b.status === "AWAITING_PAYMENT" || b.status === "REQUESTED") && holdActive(b.createdAt, now)),
  ).length;
}

export function slotBookable(startsAt: Date, now: Date): boolean {
  return startsAt.getTime() - now.getTime() >= MIN_NOTICE_MS;
}

export function canStudentCancel(startsAt: Date, now: Date): boolean {
  return startsAt.getTime() - now.getTime() >= CANCEL_WINDOW_MS;
}

export function overlaps(aStart: Date, aEnd: Date, bStart: Date, bEnd: Date): boolean {
  return aStart < bEnd && bStart < aEnd;
}

/** Blackout dates are calendar dates (YYYY-MM-DD) in East Africa Time. */
export function isBlackout(startsAt: Date, blackoutDates: string[]): boolean {
  return blackoutDates.includes(toEatInput(startsAt).slice(0, 10));
}

export function parseBlackoutDates(input: string): { dates: string[]; invalid: string[] } {
  const dates: string[] = [];
  const invalid: string[] = [];
  for (const raw of input.split(/[\n,]+/)) {
    const line = raw.trim();
    if (!line) continue;
    const ok = /^\d{4}-\d{2}-\d{2}$/.test(line) && new Date(`${line}T00:00:00Z`).toISOString().startsWith(line);
    if (ok) { if (!dates.includes(line)) dates.push(line); } else invalid.push(line);
  }
  return { dates: dates.sort(), invalid };
}

/** The same weekly time for `weeks` weeks. Kenya has no daylight saving, so +7 days keeps the same EAT clock time. */
export function weeklySlots(firstStart: Date, weeks: number, durationMinutes: number): { startsAt: Date; endsAt: Date }[] {
  const out: { startsAt: Date; endsAt: Date }[] = [];
  for (let w = 0; w < weeks; w++) {
    const startsAt = new Date(firstStart.getTime() + w * 7 * 24 * 3600 * 1000);
    out.push({ startsAt, endsAt: new Date(startsAt.getTime() + durationMinutes * 60 * 1000) });
  }
  return out;
}

export function reminderDue(startsAt: Date, now: Date): boolean {
  const diff = startsAt.getTime() - now.getTime();
  return diff > 0 && diff <= REMINDER_WINDOW_MS;
}
