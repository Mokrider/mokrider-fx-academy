import "server-only";
import { cookies } from "next/headers";
import { CART_COOKIE, parseCart, serializeCart, type CartItem } from "@/lib/commerce/cart";

export async function readCart(): Promise<CartItem[]> {
  return parseCart((await cookies()).get(CART_COOKIE)?.value);
}

/** Only call from server actions or route handlers (cookies are read-only while rendering). */
export async function writeCart(items: CartItem[]): Promise<void> {
  const jar = await cookies();
  if (items.length === 0) jar.delete(CART_COOKIE);
  else jar.set(CART_COOKIE, serializeCart(items), { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 24 * 14 });
}
