/** Identify an upload by its first bytes, not its filename. Only PDF and ZIP-based files (EPUB, XLSX, DOCX, ZIP) are allowed. */
export function detectFileType(bytes: Uint8Array): { ext: string; mime: string } | null {
  const starts = (sig: number[]) => sig.every((b, i) => bytes[i] === b);
  if (bytes.length >= 5 && starts([0x25, 0x50, 0x44, 0x46, 0x2d])) return { ext: "pdf", mime: "application/pdf" };
  if (bytes.length >= 4 && starts([0x50, 0x4b, 0x03, 0x04])) return { ext: "zip", mime: "application/zip" };
  return null;
}

export const MAX_UPLOAD_BYTES = 4 * 1024 * 1024; // stays under the serverless request limit on Vercel
