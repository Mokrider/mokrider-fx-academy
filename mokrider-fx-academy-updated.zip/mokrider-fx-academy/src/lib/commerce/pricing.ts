export type Priced = { priceMinor: number; discountMinor: number | null; discountEndsAt: Date | null };

/** `discountMinor` is the SALE PRICE while a discount is active (it must be below the normal price). */
export function effectivePriceMinor(p: Priced, now = new Date()): number {
  const active = p.discountMinor !== null && p.discountMinor >= 0 && p.discountMinor < p.priceMinor && (p.discountEndsAt === null || p.discountEndsAt > now);
  return active ? (p.discountMinor as number) : p.priceMinor;
}

/** M-Pesa can only charge whole shillings, so KES amounts must be a multiple of 100 minor units. */
export function isWholeShillings(minor: number): boolean {
  return Number.isInteger(minor) && minor >= 0 && minor % 100 === 0;
}

export function orderTotals(lines: { listMinor: number; unitMinor: number }[]) {
  const subtotal = lines.reduce((n, l) => n + l.listMinor, 0);
  const total = lines.reduce((n, l) => n + l.unitMinor, 0);
  return { subtotalMinor: subtotal, discountMinor: subtotal - total, totalMinor: total };
}
