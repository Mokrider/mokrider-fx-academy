export type CartItem = { kind: "PRODUCT" | "COURSE"; id: string };
export const CART_COOKIE = "mfx_cart";
const ID = /^[a-z0-9]{10,40}$/i;

/** Cart cookie format: "p:<id>,c:<id>". Anything malformed is dropped. Prices are never stored here. */
export function parseCart(raw: string | undefined | null): CartItem[] {
  if (!raw) return [];
  const seen = new Set<string>();
  const items: CartItem[] = [];
  for (const part of raw.split(",")) {
    const [tag, id] = part.split(":");
    if (!id || !ID.test(id) || (tag !== "p" && tag !== "c")) continue;
    const key = `${tag}:${id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    items.push({ kind: tag === "p" ? "PRODUCT" : "COURSE", id });
    if (items.length >= 20) break;
  }
  return items;
}

export function serializeCart(items: CartItem[]): string {
  return items.map((i) => `${i.kind === "PRODUCT" ? "p" : "c"}:${i.id}`).join(",");
}
