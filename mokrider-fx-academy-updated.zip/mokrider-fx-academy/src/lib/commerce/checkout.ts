import "server-only";
import { randomBytes } from "node:crypto";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import type { CartItem } from "@/lib/commerce/cart";
import { effectivePriceMinor, orderTotals } from "@/lib/commerce/pricing";
import { referenceFrom } from "@/lib/commerce/orders";

export type CheckoutLine = {
  kind: "PRODUCT" | "COURSE" | "BOOKING";
  id: string;
  title: string;
  slug: string;
  listMinor: number;
  unitMinor: number;
  currency: string;
};

/**
 * Rebuilds the cart from the database. Prices come from here, never from the browser. Items that
 * cannot be bought (unpublished, no file yet, already owned) are dropped with a note.
 */
export async function resolveCart(userId: string | null, items: CartItem[], now = new Date()): Promise<{ lines: (CheckoutLine & { kind: "PRODUCT" | "COURSE" })[]; notes: string[] }> {
  const notes: string[] = [];
  const productIds = items.filter((i) => i.kind === "PRODUCT").map((i) => i.id);
  const courseIds = items.filter((i) => i.kind === "COURSE").map((i) => i.id);

  const [products, courses, ownedProducts, enrollments] = await Promise.all([
    prisma.product.findMany({ where: { id: { in: productIds }, status: "PUBLISHED" }, include: { versions: { where: { isCurrent: true }, select: { id: true } } } }),
    prisma.course.findMany({ where: { id: { in: courseIds }, status: "PUBLISHED" } }),
    userId
      ? prisma.entitlement.findMany({ where: { userId, kind: "PRODUCT", status: "ACTIVE", productId: { in: productIds } }, select: { productId: true } })
      : Promise.resolve([] as { productId: string | null }[]),
    userId
      ? prisma.enrollment.findMany({ where: { userId, courseId: { in: courseIds } }, select: { courseId: true } })
      : Promise.resolve([] as { courseId: string }[]),
  ]);
  const ownedP = new Set(ownedProducts.map((o) => o.productId));
  const ownedC = new Set(enrollments.map((e) => e.courseId));

  const lines: (CheckoutLine & { kind: "PRODUCT" | "COURSE" })[] = [];
  for (const item of items) {
    if (item.kind === "PRODUCT") {
      const p = products.find((x) => x.id === item.id);
      if (!p) { notes.push("An item in your cart is no longer available and was removed."); continue; }
      if (ownedP.has(p.id)) { notes.push(`You already own "${p.name}".`); continue; }
      if (p.versions.length === 0) { notes.push(`"${p.name}" is not ready to download yet.`); continue; }
      lines.push({ kind: "PRODUCT", id: p.id, title: p.name, slug: p.slug, listMinor: p.priceMinor, unitMinor: effectivePriceMinor(p, now), currency: p.currency });
    } else {
      const c = courses.find((x) => x.id === item.id);
      if (!c) { notes.push("A course in your cart is no longer available and was removed."); continue; }
      if (ownedC.has(c.id)) { notes.push(`You are already enrolled in "${c.title}".`); continue; }
      if (c.isFree || c.priceMinor <= 0) { notes.push(`"${c.title}" is free. Enroll from its page.`); continue; }
      lines.push({ kind: "COURSE", id: c.id, title: c.title, slug: c.slug, listMinor: c.priceMinor, unitMinor: c.priceMinor, currency: c.currency });
    }
  }
  return { lines, notes };
}

export async function createOrder(userId: string, lines: CheckoutLine[], client: Prisma.TransactionClient | typeof prisma = prisma) {
  const currency = lines[0].currency;
  const t = orderTotals(lines);
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      return await client.order.create({
        data: {
          reference: referenceFrom(new Date(), randomBytes(6)),
          userId, status: "PENDING", currency,
          subtotalMinor: t.subtotalMinor, discountMinor: t.discountMinor, totalMinor: t.totalMinor,
          items: {
            create: lines.map((l) => ({
              kind: l.kind, productId: l.kind === "PRODUCT" ? l.id : null, courseId: l.kind === "COURSE" ? l.id : null, packageId: l.kind === "BOOKING" ? l.id : null,
              titleSnapshot: l.title, unitPriceMinor: l.unitMinor, currency: l.currency, quantity: 1,
            })),
          },
        },
      });
    } catch (e) {
      if (!(e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002")) throw e; // retry only on reference collision
    }
  }
  throw new Error("Could not create an order reference.");
}
