import "server-only";
import { prisma } from "@/lib/db";
import { brandedEmail, sendEmail, type EmailResult } from "@/lib/email";
import { formatEat } from "@/lib/time";
import { formatMoney } from "@/lib/money";

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);
const appUrl = () => (process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000").replace(/\/$/, "");

type BookingForEmail = {
  status: string;
  package: { title: string; durationMinutes: number; deliveryMethod: string; cancellationPolicy: string };
  slot: { startsAt: Date; meetingUrl: string | null };
};

function bookingBlock(b: BookingForEmail): string {
  if (b.status === "CANCELLED") {
    return `<p><strong>${esc(b.package.title)}</strong></p><p>Your payment arrived after the seat was taken, so the session could not be held. A refund request has been recorded and we will contact you about it.</p>`;
  }
  const link = b.slot.meetingUrl && b.slot.meetingUrl.startsWith("https://")
    ? `<p>Meeting link: <a href="${esc(b.slot.meetingUrl)}" style="color:#FF6B6B">${esc(b.slot.meetingUrl)}</a></p>`
    : `<p>Your meeting link will be sent to you before the session.</p>`;
  const policy = b.package.cancellationPolicy ? `<p style="color:#B8B8BF;font-size:13px">Cancellation: ${esc(b.package.cancellationPolicy)}</p>` : "";
  return `<p><strong>${esc(b.package.title)}</strong><br>${esc(formatEat(b.slot.startsAt))} &middot; ${b.package.durationMinutes} minutes &middot; ${esc(b.package.deliveryMethod)}</p>${link}${policy}`;
}

const bookingInclude = { package: { select: { title: true, durationMinutes: true, deliveryMethod: true, cancellationPolicy: true } }, slot: { select: { startsAt: true, meetingUrl: true } } } as const;

/** Receipt email after an order is verified as paid (or a free order is claimed). Failures are logged, never thrown. */
export async function afterOrderPaid(orderId: string): Promise<void> {
  try {
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { user: { select: { email: true, name: true } }, items: true, bookings: { include: bookingInclude } },
    });
    if (!order?.user) return;
    const items = order.items.map((i) => `<li>${esc(i.titleSnapshot)} &ndash; ${esc(formatMoney(i.unitPriceMinor, i.currency))}</li>`).join("");
    const hasFiles = order.items.some((i) => i.kind === "PRODUCT");
    const html = brandedEmail("Your order is confirmed", `
      <p>Hi ${esc(order.user.name.split(" ")[0])}, thank you for your order <strong>${esc(order.reference)}</strong>.</p>
      <ul>${items}</ul>
      <p><strong>Total: ${esc(formatMoney(order.totalMinor, order.currency))}</strong></p>
      ${order.bookings.map(bookingBlock).join("")}
      <p><a href="${appUrl()}/orders/${esc(order.reference)}" style="color:#FF6B6B">${hasFiles ? "View your order and download your files" : "View your order"}</a></p>`);
    const r = await sendEmail({ to: order.user.email, subject: `Order ${order.reference} confirmed`, html });
    if (r.status === "failed") console.error("order email failed", order.reference, r.error);
  } catch (e) {
    console.error("afterOrderPaid failed", e instanceof Error ? e.message : "unknown");
  }
}

async function bookingEmail(bookingId: string, title: string, subject: string, intro: string): Promise<EmailResult> {
  const b = await prisma.booking.findUnique({ where: { id: bookingId }, include: { ...bookingInclude, user: { select: { email: true, name: true } } } });
  if (!b) return { status: "failed", error: "Booking not found" };
  const html = brandedEmail(title, `<p>Hi ${esc(b.user.name.split(" ")[0])}, ${intro}</p>${bookingBlock(b)}<p><a href="${appUrl()}/dashboard" style="color:#FF6B6B">Open your dashboard</a></p>`);
  return sendEmail({ to: b.user.email, subject, html });
}

export async function sendBookingConfirmationEmail(bookingId: string): Promise<void> {
  try { await bookingEmail(bookingId, "Your session is booked", "Your session is booked", "your session is confirmed."); }
  catch (e) { console.error("booking email failed", e instanceof Error ? e.message : "unknown"); }
}

export async function sendBookingReminderEmail(bookingId: string): Promise<EmailResult> {
  try { return await bookingEmail(bookingId, "Session reminder", "Reminder: your session is coming up", "this is a reminder about your upcoming session."); }
  catch { return { status: "failed", error: "Unexpected error" }; }
}

export async function sendBookingMovedEmail(bookingId: string): Promise<void> {
  try { await bookingEmail(bookingId, "Your session was moved", "Your session time has changed", "your session has been moved to a new time."); }
  catch (e) { console.error("booking email failed", e instanceof Error ? e.message : "unknown"); }
}
