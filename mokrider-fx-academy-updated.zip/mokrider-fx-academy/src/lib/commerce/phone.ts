/** Normalise a Kenyan mobile number to 2547XXXXXXXX or 2541XXXXXXXX. Returns null if it is not valid. */
export function normalizeKenyanPhone(input: string): string | null {
  const t = input.replace(/[\s()-]/g, "").replace(/^\+/, "");
  const m = /^(?:254|0)?([17]\d{8})$/.exec(t);
  return m ? `254${m[1]}` : null;
}

export function last4(phone: string): string {
  return phone.slice(-4);
}

/** A contact phone number in any country format: optional +, then 7 to 15 digits. Returns the cleaned number or null. */
export function cleanContactPhone(input: string): string | null {
  const cleaned = input.trim().replace(/[\s().-]/g, "");
  return /^\+?\d{7,15}$/.test(cleaned) ? cleaned : null;
}
