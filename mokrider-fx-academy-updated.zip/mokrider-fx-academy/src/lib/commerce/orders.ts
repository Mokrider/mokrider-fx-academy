export type OrderStatus = "PENDING" | "AWAITING_PAYMENT" | "PAID" | "FAILED" | "CANCELLED" | "REFUNDED";

const TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  PENDING: ["AWAITING_PAYMENT", "PAID", "CANCELLED", "FAILED"],
  AWAITING_PAYMENT: ["PAID", "FAILED", "CANCELLED"],
  FAILED: ["AWAITING_PAYMENT", "PAID"], // a retried payment can still succeed
  PAID: ["REFUNDED"],
  CANCELLED: [],
  REFUNDED: [],
};

export function canTransition(from: OrderStatus, to: OrderStatus): boolean {
  return TRANSITIONS[from].includes(to);
}

/** Statuses from which a verified payment may mark an order paid. */
export const PAYABLE_STATUSES: OrderStatus[] = ["PENDING", "AWAITING_PAYMENT", "FAILED"];

const ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; // Crockford base32, no I L O U

/** Order reference like MFX-261101-7K3QZ8. Pass random bytes in (6 or more). */
export function referenceFrom(date: Date, bytes: Uint8Array): string {
  const yy = String(date.getUTCFullYear()).slice(2);
  const mm = String(date.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(date.getUTCDate()).padStart(2, "0");
  let tail = "";
  for (let i = 0; i < 6; i++) tail += ALPHABET[bytes[i] % 32];
  return `MFX-${yy}${mm}${dd}-${tail}`;
}
