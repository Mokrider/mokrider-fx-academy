import "server-only";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { PAYABLE_STATUSES } from "@/lib/commerce/orders";
import { mapResultCode } from "@/lib/mpesa/parse";
import { stkQuery } from "@/lib/mpesa/daraja";
import { confirmBookingForOrderTx } from "@/lib/booking/engine";
import { afterOrderPaid } from "@/lib/commerce/notify";

type Tx = Prisma.TransactionClient;
const OPEN = ["INITIATED", "PENDING"] as const;
const FINAL = ["SUCCEEDED", "FAILED", "CANCELLED", "TIMED_OUT"];

/**
 * Marks an order paid and grants access. The status update is a guarded compare-and-set, so if two
 * requests race (callback and polling) only one wins and creates entitlements. Safe to call twice.
 */
export async function fulfilOrderTx(tx: Tx, orderId: string): Promise<boolean> {
  const order = await tx.order.findUnique({ where: { id: orderId }, include: { items: true } });
  if (!order || !order.userId) return false;
  const gate = await tx.order.updateMany({ where: { id: orderId, status: { in: PAYABLE_STATUSES } }, data: { status: "PAID", paidAt: new Date() } });
  if (gate.count !== 1) return false;

  if (order.items.some((i) => i.kind === "BOOKING")) await confirmBookingForOrderTx(tx, order.id);

  for (const item of order.items) {
    if (item.kind === "PRODUCT" && item.productId) {
      await tx.entitlement.create({ data: { userId: order.userId, kind: "PRODUCT", productId: item.productId, orderItemId: item.id } });
    } else if (item.kind === "COURSE" && item.courseId) {
      await tx.enrollment.upsert({
        where: { userId_courseId: { userId: order.userId, courseId: item.courseId } },
        update: {}, create: { userId: order.userId, courseId: item.courseId },
      });
      await tx.entitlement.create({ data: { userId: order.userId, kind: "COURSE", courseId: item.courseId, orderItemId: item.id } });
    }
  }
  return true;
}

export type CallbackHint = { receipt: string | null; amountShillings: number | null };

/**
 * Settles a payment by asking Safaricom what happened (the STK Query API). A callback is only a
 * prompt to check, never proof. If Safaricom cannot be reached or says "still processing", the
 * payment stays pending. Nothing is granted on an unverified claim.
 */
export async function reconcilePayment(paymentId: string, hint?: CallbackHint): Promise<string | null> {
  const payment = await prisma.payment.findUnique({ where: { id: paymentId } });
  if (!payment) return null;

  if (FINAL.includes(payment.status)) {
    if (payment.status === "SUCCEEDED" && hint?.receipt && !payment.providerReceipt) {
      await prisma.payment.update({ where: { id: payment.id }, data: { providerReceipt: hint.receipt } });
    }
    return payment.status;
  }
  if (payment.provider !== "MPESA" || !payment.providerRef) return payment.status;

  let result;
  try {
    result = await stkQuery(payment.providerRef);
  } catch {
    return payment.status; // could not verify: stay pending
  }
  if (result.state === "pending") return payment.status;

  const outcome = mapResultCode(result.resultCode);

  if (outcome === "SUCCEEDED") {
    if (hint?.amountShillings != null && hint.amountShillings * 100 !== payment.amountMinor) {
      // Verified as paid by Safaricom but the callback amount disagrees with our order. Do not grant access: flag for review.
      await prisma.paymentEvent.upsert({
        where: { provider_eventKey: { provider: "MPESA", eventKey: `amount-mismatch:${payment.providerRef}` } },
        update: {}, create: { paymentId: payment.id, provider: "MPESA", eventKey: `amount-mismatch:${payment.providerRef}`, payload: { expectedMinor: payment.amountMinor, callbackShillings: hint.amountShillings } },
      });
      return payment.status;
    }
    const fulfilled = await prisma.$transaction(async (tx) => {
      const won = await tx.payment.updateMany({
        where: { id: payment.id, status: { in: [...OPEN] } },
        data: { status: "SUCCEEDED", providerReceipt: hint?.receipt ?? null, verifiedAt: new Date(), failureReason: null },
      });
      return won.count === 1 ? await fulfilOrderTx(tx, payment.orderId) : false;
    });
    if (fulfilled) await afterOrderPaid(payment.orderId); // emails never block or undo a verified payment
    return "SUCCEEDED";
  }

  await prisma.$transaction(async (tx) => {
    const won = await tx.payment.updateMany({
      where: { id: payment.id, status: { in: [...OPEN] } },
      data: { status: outcome, failureReason: result.state === "result" ? result.resultDesc.slice(0, 200) : null },
    });
    if (won.count !== 1) return;
    const stillActive = await tx.payment.count({ where: { orderId: payment.orderId, id: { not: payment.id }, status: { in: ["INITIATED", "PENDING", "SUCCEEDED"] } } });
    if (stillActive === 0) {
      await tx.order.updateMany({ where: { id: payment.orderId, status: { in: ["PENDING", "AWAITING_PAYMENT"] } }, data: { status: "FAILED" } });
    }
  });
  return outcome;
}
