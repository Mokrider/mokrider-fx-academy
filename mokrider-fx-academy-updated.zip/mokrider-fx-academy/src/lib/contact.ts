/**
 * Contact helpers: pre-filled email (Gmail, Outlook, default mail app) and WhatsApp links.
 * Pure functions with no imports, so they are safe in server and client code and easy to unit-test.
 */

export type ContactMessage = { subject: string; body: string };

/** Window event used by <ContactTrigger> to ask the <ContactDock> dialog to open. */
export const OPEN_CONTACT_EVENT = "mokrider:open-contact";

export const DEFAULT_MESSAGE: ContactMessage = {
  subject: "Question about MOKRIDER FX ACADEMY",
  body: "Hello,\n\nI would like to ask about:\n\nMy name:\nMy phone (optional):\n\nThank you.",
};

const enc = encodeURIComponent;

export function mailtoUrl(email: string, m: ContactMessage): string {
  return `mailto:${email}?subject=${enc(m.subject)}&body=${enc(m.body)}`;
}

export function gmailUrl(email: string, m: ContactMessage): string {
  return `https://mail.google.com/mail/?view=cm&fs=1&to=${enc(email)}&su=${enc(m.subject)}&body=${enc(m.body)}`;
}

export function outlookUrl(email: string, m: ContactMessage): string {
  return `https://outlook.live.com/mail/0/deeplink/compose?to=${enc(email)}&subject=${enc(m.subject)}&body=${enc(m.body)}`;
}

/**
 * Turns a phone number as people type it into the digits-only form wa.me needs.
 * Kenyan local numbers (07xx, 01xx) become 254 numbers. Returns "" when nothing usable is left.
 */
export function whatsappDigits(raw: string | undefined | null): string {
  if (!raw) return "";
  let d = raw.replace(/\D/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  if (d.length === 10 && d.startsWith("0")) d = `254${d.slice(1)}`;
  if (d.length === 9 && /^[17]/.test(d)) d = `254${d}`;
  return d.length >= 10 ? d : "";
}

export function whatsappUrl(rawNumber: string | undefined | null, text: string): string | null {
  const digits = whatsappDigits(rawNumber);
  return digits ? `https://wa.me/${digits}?text=${enc(text)}` : null;
}

export type ContactConfig = {
  email: string | null;
  phone: string | null;
  whatsapp: string | null;
  hours: string | null;
  location: string | null;
  socials: { label: string; href: string }[];
};

/** Reads the public contact settings from the environment. Anything left empty is hidden on the site. */
export function getContact(): ContactConfig {
  const clean = (v: string | undefined) => (v && v.trim() ? v.trim() : null);
  const socials = [
    ["Facebook", process.env.NEXT_PUBLIC_SOCIAL_FACEBOOK],
    ["X", process.env.NEXT_PUBLIC_SOCIAL_X],
    ["Instagram", process.env.NEXT_PUBLIC_SOCIAL_INSTAGRAM],
    ["YouTube", process.env.NEXT_PUBLIC_SOCIAL_YOUTUBE],
    ["TikTok", process.env.NEXT_PUBLIC_SOCIAL_TIKTOK],
    ["Telegram", process.env.NEXT_PUBLIC_SOCIAL_TELEGRAM],
  ]
    .map(([label, href]) => ({ label: label as string, href: clean(href as string | undefined) }))
    .filter((s): s is { label: string; href: string } => s.href !== null && /^https:\/\//.test(s.href));
  return {
    email: clean(process.env.NEXT_PUBLIC_CONTACT_EMAIL),
    phone: clean(process.env.NEXT_PUBLIC_CONTACT_PHONE),
    whatsapp: whatsappDigits(process.env.NEXT_PUBLIC_WHATSAPP_NUMBER) || null,
    hours: clean(process.env.NEXT_PUBLIC_CONTACT_HOURS),
    location: clean(process.env.NEXT_PUBLIC_CONTACT_LOCATION),
    socials,
  };
}
