import "server-only";
import { prisma } from "@/lib/db";

export type Intake = { open: boolean; note: string };

/** Whether private-mentorship applications are being accepted. Defaults to open until you change it in the admin. */
export async function getIntake(): Promise<Intake> {
  const row = await prisma.siteSetting.findUnique({ where: { key: "intake" } });
  const v = row?.value as Partial<Intake> | null;
  return { open: v?.open !== false, note: typeof v?.note === "string" ? v.note : "" };
}
