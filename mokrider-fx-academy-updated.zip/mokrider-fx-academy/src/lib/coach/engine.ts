import type { Level, Question, Topic } from "@/content/coach/questions";

/** One answered question, kept in the student's own browser. */
export type Attempt = { id: string; t: Topic; ok: boolean; at: number };
export type TopicStat = { asked: number; correct: number };
export type Rng = () => number;

export function topicStats(history: Attempt[]): Partial<Record<Topic, TopicStat>> {
  const out: Partial<Record<Topic, TopicStat>> = {};
  for (const a of history) {
    const s = (out[a.t] ??= { asked: 0, correct: 0 });
    s.asked += 1;
    if (a.ok) s.correct += 1;
  }
  return out;
}

/** Accuracy with a gentle prior, so one lucky or unlucky answer does not swing it to 0% or 100%. */
export function accuracy(s: TopicStat | undefined): number {
  return ((s?.correct ?? 0) + 1) / ((s?.asked ?? 0) + 2);
}

/** The hardest level a student has earned in a topic: 1 to start, 2 after steady results, 3 after more. */
export function workingLevel(s: TopicStat | undefined): Level {
  if (!s) return 1;
  if (s.asked >= 6 && s.correct / s.asked >= 0.75) return 3;
  if (s.asked >= 3 && s.correct / s.asked >= 0.7) return 2;
  return 1;
}

export type PickOptions = { topic?: Topic | "adaptive"; level?: Level | "adaptive"; rng?: Rng; skipIds?: string[] };

/**
 * Chooses the next question. Unseen questions and ones answered wrong last time are favoured, weak topics
 * are favoured, recently answered ones are avoided, and in adaptive mode difficulty follows the student.
 */
export function pickNext(bank: Question[], history: Attempt[], opts: PickOptions = {}): Question | null {
  const rng = opts.rng ?? Math.random;
  const topic = opts.topic ?? "adaptive";
  const level = opts.level ?? "adaptive";
  const skip = new Set(opts.skipIds ?? []);
  const stats = topicStats(history);
  const last = new Map<string, Attempt>();
  for (const a of history) last.set(a.id, a); // later entries win
  const recent = new Set(history.slice(-12).map((a) => a.id));

  let pool = bank.filter((q) => (topic === "adaptive" || q.t === topic) && !skip.has(q.id));
  if (level !== "adaptive") pool = pool.filter((q) => q.l === level);
  else {
    const within = pool.filter((q) => q.l <= workingLevel(stats[q.t]));
    if (within.length > 0) pool = within;
  }
  if (pool.length === 0) return null;
  const fresh = pool.filter((q) => !recent.has(q.id));
  if (fresh.length > 0) pool = fresh;

  const weights = pool.map((q) => {
    const prev = last.get(q.id);
    let w = 1;
    if (!prev) w += 2;
    else if (!prev.ok) w += 3;
    w += (1 - accuracy(stats[q.t])) * 2;
    return w;
  });
  let r = rng() * weights.reduce((a, b) => a + b, 0);
  for (let i = 0; i < pool.length; i++) {
    r -= weights[i];
    if (r <= 0) return pool[i];
  }
  return pool[pool.length - 1];
}

/** Shuffles a question's options and returns where the correct one landed. */
export function shuffleOptions(q: Question, rng: Rng = Math.random): { options: string[]; answerIndex: number } {
  const order = [0, 1, 2, 3];
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  return { options: order.map((i) => q.o[i]), answerIndex: order.indexOf(q.a) };
}

export type Summary = { total: number; correct: number; percent: number; weakest: Topic[]; strongest: Topic[] };

export function summarize(history: Attempt[]): Summary {
  const total = history.length;
  const correct = history.filter((a) => a.ok).length;
  const entries = (Object.entries(topicStats(history)) as [Topic, TopicStat][]).filter(([, s]) => s.asked >= 2);
  const byAcc = [...entries].sort((x, y) => accuracy(x[1]) - accuracy(y[1]));
  return {
    total,
    correct,
    percent: total === 0 ? 0 : Math.round((correct / total) * 100),
    weakest: byAcc.filter(([, s]) => accuracy(s) < 0.7).slice(0, 3).map(([t]) => t),
    strongest: [...byAcc].reverse().filter(([, s]) => accuracy(s) >= 0.7).slice(0, 3).map(([t]) => t),
  };
}
