import { round } from "./num";

export function pipsToPrice(pips: number, pipSize: number): number {
  return round(pips * pipSize, 8);
}

/** Money value of a price move: distance x contractSize x lots x rate (quote currency to account currency). */
export function moveValue(priceDistance: number, lots: number, contractSize: number, rate: number): number {
  return priceDistance * contractSize * lots * rate;
}

export function valuePerPipPerLot(pipSize: number, contractSize: number, rate = 1): number {
  return round(pipSize * contractSize * rate, 6);
}
