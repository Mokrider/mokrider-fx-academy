import { SESSIONS, isSessionOpen, zonedLocalToUtc, zonedParts, type SessionDef } from "@/lib/trading/sessions";

/**
 * What each forex session is usually like. These are tendencies seen often, not rules: news can make
 * any session wild, and quiet sessions can surprise. Nothing here predicts price or suggests a trade.
 */
export type SessionTraits = {
  tagline: string;
  activity: 1 | 2 | 3 | 4; // typical activity for the majors, 4 = highest
  activityLabel: string;
  character: string;
  gold: string;
  eurusd: string;
  watch: string[];
  mainCurrencies: string;
};

export const SESSION_TRAITS: Record<string, SessionTraits> = {
  sydney: {
    tagline: "The quiet start of the trading day",
    activity: 1,
    activityLabel: "Usually the quietest",
    mainCurrencies: "AUD, NZD",
    character: "Fewer banks are trading, so the major pairs often drift in narrow ranges and spreads can be wider. Australian and New Zealand dollar pairs are the most active.",
    gold: "Gold is usually calm, though it can react to weekend news when the week opens.",
    eurusd: "EURUSD is normally slow, with small ranges.",
    watch: ["Australian and New Zealand data and central bank decisions", "Gaps at the weekly open"],
  },
  tokyo: {
    tagline: "Asia sets the first range of the day",
    activity: 2,
    activityLabel: "Moderate, mostly in yen pairs",
    mainCurrencies: "JPY, AUD, CNH",
    character: "Often builds a range that London later breaks out of or pushes through. Yen pairs are the most active, while pairs like EURUSD tend to be calmer.",
    gold: "Gold has steady demand from Asian buyers and can trend gently, but its biggest moves usually wait for London and New York.",
    eurusd: "EURUSD is usually quieter than in London or New York.",
    watch: ["Bank of Japan decisions and Japanese or Chinese data", "The high and low of the Asian range, which many traders mark before London opens"],
  },
  london: {
    tagline: "The largest share of forex trading",
    activity: 4,
    activityLabel: "Usually very active",
    mainCurrencies: "EUR, GBP, CHF",
    character: "More forex is traded in London than in any other centre. Activity often jumps at the open as traders react to the Asian range, and the day's high or low is frequently set here. False breakouts happen often.",
    gold: "Gold usually becomes much more active, because London is a major centre for gold trading.",
    eurusd: "EURUSD is typically at its busiest, driven by European data and the European Central Bank.",
    watch: ["Eurozone and UK data releases", "The first hour after the open, when moves can be sharp and reverse quickly"],
  },
  newyork: {
    tagline: "US data and the dollar take over",
    activity: 4,
    activityLabel: "Very active early, fading late",
    mainCurrencies: "USD, CAD",
    character: "Moves are often driven by US economic data, much of it released at 8:30 New York time. Activity is highest while London is still open, then tends to thin after London closes.",
    gold: "Gold reacts strongly to US data such as jobs and inflation, to Federal Reserve news and to the US dollar.",
    eurusd: "EURUSD reacts to US data, and the biggest moves often come in the first hours before London closes.",
    watch: ["US jobs report, inflation data and Federal Reserve decisions", "Thin, jumpy trading late in the session"],
  },
};

/** Notes for the busy periods where two sessions are open together. */
export const OVERLAPS: { ids: [string, string]; label: string; note: string }[] = [
  { ids: ["london", "newyork"], label: "London + New York", note: "Usually the busiest part of the day, with the most volume and the widest ranges. News can make it fast, so spreads and slippage matter." },
  { ids: ["tokyo", "london"], label: "Tokyo + London", note: "A short handover. The Asian range often gets tested or broken as Europe arrives." },
  { ids: ["sydney", "tokyo"], label: "Sydney + Tokyo", note: "Asia-Pacific trading together. Mostly relevant to AUD, NZD and JPY pairs." },
];

export function openSessionIds(at: Date): string[] {
  return SESSIONS.filter((s) => isSessionOpen(s, at)).map((s) => s.id);
}

export function activeOverlaps(at: Date) {
  const open = new Set(openSessionIds(at));
  return OVERLAPS.filter((o) => o.ids.every((id) => open.has(id)));
}

/** True on Saturday and Sunday in New York, when the major forex centres are closed. */
export function isWeekendClosed(at: Date): boolean {
  const ny = zonedParts(at, "America/New_York");
  return ny.weekday === 6 || (ny.weekday === 7 && ny.hour < 17);
}

export type Segment = { startMin: number; endMin: number };
export type TimelineRow = { id: string; name: string; segments: Segment[] };

/**
 * The display zone's current calendar day (00:00 to 24:00) as 15-minute slots, so the page can draw a 24-hour
 * bar with each session's open stretch. `nowMin` is where "now" sits on that bar.
 */
export function dayTimeline(now: Date, tz: string, defs: SessionDef[] = SESSIONS): { rows: TimelineRow[]; nowMin: number } {
  const p = zonedParts(now, tz);
  const dayStart = zonedLocalToUtc(p.year, p.month, p.day, 0, 0, tz).getTime();
  const SLOT = 15;
  const rows: TimelineRow[] = defs.map((s) => {
    const segments: Segment[] = [];
    let runStart: number | null = null;
    for (let m = 0; m <= 24 * 60; m += SLOT) {
      const open = m < 24 * 60 && isSessionOpen(s, new Date(dayStart + m * 60_000));
      if (open && runStart === null) runStart = m;
      if (!open && runStart !== null) {
        segments.push({ startMin: runStart, endMin: m });
        runStart = null;
      }
    }
    return { id: s.id, name: s.name, segments };
  });
  return { rows, nowMin: p.hour * 60 + p.minute };
}

/** 3725 seconds -> "1h 02m 05s". */
export function formatCountdown(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const two = (n: number) => String(n).padStart(2, "0");
  return h > 0 ? `${h}h ${two(m)}m ${two(sec)}s` : `${m}m ${two(sec)}s`;
}
