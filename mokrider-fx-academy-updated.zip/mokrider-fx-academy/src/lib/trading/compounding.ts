export type CompoundingInput = { start: number; contribution: number; periods: number; ratePercent: number };
export type CompoundingRow = { period: number; balance: number; contributed: number };
export type CompoundingResult =
  | { ok: false; errors: string[] }
  | { ok: true; rows: CompoundingRow[]; final: number; contributed: number; growth: number };

/** Balance after each period = previous balance x (1 + rate) + contribution (added at the end of the period). */
export function calcCompounding(i: CompoundingInput): CompoundingResult {
  const errors: string[] = [];
  if (!(i.start >= 0)) errors.push("Starting balance cannot be negative.");
  if (!(i.contribution >= 0)) errors.push("Contribution cannot be negative.");
  if (!Number.isInteger(i.periods) || i.periods < 1 || i.periods > 600) errors.push("Number of periods must be a whole number from 1 to 600.");
  if (!(i.ratePercent > -100 && i.ratePercent <= 1000)) errors.push("Return per period must be above -100% and at most 1000%.");
  if (errors.length) return { ok: false, errors };

  const rows: CompoundingRow[] = [];
  let balance = i.start;
  let contributed = i.start;
  for (let p = 1; p <= i.periods; p++) {
    balance = balance * (1 + i.ratePercent / 100) + i.contribution;
    contributed += i.contribution;
    rows.push({ period: p, balance, contributed });
  }
  return { ok: true, rows, final: balance, contributed, growth: balance - contributed };
}
