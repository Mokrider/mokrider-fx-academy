/** Parse a user-typed number ("1,250.5"). Returns null for blank or invalid input. */
export function parseNum(input: string): number | null {
  const t = input.trim().replace(/,/g, "");
  if (t === "" || !/^-?\d*\.?\d+(e-?\d+)?$/i.test(t)) return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

export function round(n: number, digits: number): number {
  return Number(n.toFixed(digits));
}

export function fmt(n: number, digits = 2): string {
  return n.toLocaleString("en-KE", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}
