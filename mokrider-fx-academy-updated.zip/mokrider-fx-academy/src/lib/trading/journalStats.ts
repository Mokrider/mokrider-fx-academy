export type JournalRow = {
  tradedAt: Date;
  instrument: string;
  setup: string | null;
  currency: string;
  resultMinor: number | null;
  plannedRiskMinor: number | null;
};

export type CurrencyStats = {
  currency: string;
  closed: number;
  wins: number;
  losses: number;
  breakeven: number;
  winRate: number | null; // 0..1
  netMinor: number;
  grossProfitMinor: number;
  grossLossMinor: number; // positive magnitude
  profitFactor: number | null; // null when there are no losing trades
  avgWinMinor: number | null;
  avgLossMinor: number | null; // positive magnitude
  payoffRatio: number | null; // average win / average loss
  avgR: number | null; // mean of result / planned risk, only where planned risk was recorded
  rCount: number;
  maxDrawdownMinor: number; // largest peak-to-trough fall of cumulative results (positive)
  byInstrument: Record<string, { count: number; netMinor: number }>;
  bySetup: Record<string, { count: number; netMinor: number }>;
  smallSample: boolean;
};

export type JournalStats = { totalEntries: number; openEntries: number; byCurrency: CurrencyStats[] };

/** Statistics are computed per currency so different currencies are never added together. */
export function journalStats(rows: JournalRow[]): JournalStats {
  const closedRows = rows.filter((r) => r.resultMinor !== null);
  const currencies = [...new Set(closedRows.map((r) => r.currency))].sort();

  const byCurrency = currencies.map((currency): CurrencyStats => {
    const list = closedRows.filter((r) => r.currency === currency).sort((a, b) => a.tradedAt.getTime() - b.tradedAt.getTime());
    const results = list.map((r) => r.resultMinor as number);
    const wins = results.filter((x) => x > 0);
    const losses = results.filter((x) => x < 0);
    const grossProfit = wins.reduce((a, b) => a + b, 0);
    const grossLoss = Math.abs(losses.reduce((a, b) => a + b, 0));

    let cum = 0, peak = 0, maxDd = 0;
    for (const r of results) {
      cum += r;
      peak = Math.max(peak, cum);
      maxDd = Math.max(maxDd, peak - cum);
    }

    const rs = list.filter((r) => (r.plannedRiskMinor ?? 0) > 0).map((r) => (r.resultMinor as number) / (r.plannedRiskMinor as number));

    const group = (key: (r: JournalRow) => string) => {
      const out: Record<string, { count: number; netMinor: number }> = {};
      for (const r of list) {
        const k = key(r);
        out[k] ??= { count: 0, netMinor: 0 };
        out[k].count += 1;
        out[k].netMinor += r.resultMinor as number;
      }
      return out;
    };

    const avgWin = wins.length ? grossProfit / wins.length : null;
    const avgLoss = losses.length ? grossLoss / losses.length : null;
    return {
      currency, closed: list.length, wins: wins.length, losses: losses.length, breakeven: results.length - wins.length - losses.length,
      winRate: list.length ? wins.length / list.length : null,
      netMinor: results.reduce((a, b) => a + b, 0), grossProfitMinor: grossProfit, grossLossMinor: grossLoss,
      profitFactor: grossLoss > 0 ? grossProfit / grossLoss : null,
      avgWinMinor: avgWin, avgLossMinor: avgLoss,
      payoffRatio: avgWin !== null && avgLoss !== null && avgLoss > 0 ? avgWin / avgLoss : null,
      avgR: rs.length ? rs.reduce((a, b) => a + b, 0) / rs.length : null, rCount: rs.length,
      maxDrawdownMinor: maxDd,
      byInstrument: group((r) => r.instrument),
      bySetup: group((r) => r.setup?.trim() || "No setup recorded"),
      smallSample: list.length < 30,
    };
  });

  return { totalEntries: rows.length, openEntries: rows.length - closedRows.length, byCurrency };
}
