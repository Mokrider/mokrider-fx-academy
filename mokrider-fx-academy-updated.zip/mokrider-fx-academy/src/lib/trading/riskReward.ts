export type Direction = "LONG" | "SHORT";

/** Returns an error message when stop/target are on the wrong side of entry, otherwise null. */
export function checkTradeLevels(direction: Direction, entry: number, stop: number, target?: number | null): string | null {
  if (direction === "LONG") {
    if (!(stop < entry)) return "For a long trade the stop-loss must be below the entry price.";
    if (target != null && !(target > entry)) return "For a long trade the take-profit must be above the entry price.";
  } else {
    if (!(stop > entry)) return "For a short trade the stop-loss must be above the entry price.";
    if (target != null && !(target < entry)) return "For a short trade the take-profit must be below the entry price.";
  }
  return null;
}

export type RiskRewardInput = {
  direction: Direction;
  entry: number;
  stop: number;
  target: number;
  lots?: number | null;
  contractSize?: number | null;
  quoteToAccountRate?: number | null;
};

export type RiskRewardResult =
  | { ok: false; error: string }
  | {
      ok: true;
      riskDistance: number;
      rewardDistance: number;
      ratio: number;
      breakEvenWinRate: number; // percent, before costs
      lossAtStop: number | null;
      profitAtTarget: number | null;
    };

export function calcRiskReward(i: RiskRewardInput): RiskRewardResult {
  if (!(i.entry > 0 && i.stop > 0 && i.target > 0)) return { ok: false, error: "Entry, stop-loss and take-profit must all be greater than zero." };
  const bad = checkTradeLevels(i.direction, i.entry, i.stop, i.target);
  if (bad) return { ok: false, error: bad };
  const riskDistance = Math.abs(i.entry - i.stop);
  const rewardDistance = Math.abs(i.target - i.entry);
  const ratio = rewardDistance / riskDistance;
  const canPrice = i.lots != null && i.lots > 0 && i.contractSize != null && i.contractSize > 0 && i.quoteToAccountRate != null && i.quoteToAccountRate > 0;
  const per = canPrice ? (i.lots as number) * (i.contractSize as number) * (i.quoteToAccountRate as number) : null;
  return {
    ok: true, riskDistance, rewardDistance, ratio,
    breakEvenWinRate: 100 / (1 + ratio),
    lossAtStop: per === null ? null : riskDistance * per,
    profitAtTarget: per === null ? null : rewardDistance * per,
  };
}
