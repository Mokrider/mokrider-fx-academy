import { round } from "./num";

export type PositionSizeInput = {
  balance: number;
  riskPercent: number;
  entry: number;
  stop: number;
  contractSize: number; // units per 1.00 lot
  quoteToAccountRate: number; // 1 unit of the instrument's quote currency = this many account-currency units
  lotStep: number;
  minLot: number;
};

export type PositionSizeResult =
  | { ok: false; errors: string[] }
  | {
      ok: true;
      riskAmount: number;
      stopDistance: number;
      lossPerLot: number;
      rawLots: number;
      lots: number;
      actualRisk: number;
      actualRiskPercent: number;
      warnings: string[];
    };

function decimals(step: number): number {
  const s = String(step);
  return s.includes(".") ? s.split(".")[1].length : 0;
}

export function roundDownToStep(value: number, step: number): number {
  const n = Math.floor(value / step + 1e-9);
  return Number((n * step).toFixed(decimals(step)));
}

/**
 * lots = (balance x risk%) / (|entry - stop| x contractSize x quoteToAccountRate)
 * Loss per lot is in the instrument's quote currency, converted with a rate the user supplies.
 * No exchange rate is assumed or fetched.
 */
export function calcPositionSize(i: PositionSizeInput): PositionSizeResult {
  const errors: string[] = [];
  if (!(i.balance > 0)) errors.push("Account balance must be greater than zero.");
  if (!(i.riskPercent > 0 && i.riskPercent <= 100)) errors.push("Risk percentage must be between 0 and 100.");
  if (!(i.entry > 0)) errors.push("Entry price must be greater than zero.");
  if (!(i.stop > 0)) errors.push("Stop-loss price must be greater than zero.");
  if (i.entry > 0 && i.stop > 0 && i.entry === i.stop) errors.push("Entry and stop-loss cannot be the same price.");
  if (!(i.contractSize > 0)) errors.push("Contract size must be greater than zero.");
  if (!(i.quoteToAccountRate > 0)) errors.push("Enter the exchange rate from the instrument's quote currency to your account currency.");
  if (!(i.lotStep > 0)) errors.push("Lot step must be greater than zero.");
  if (!(i.minLot > 0)) errors.push("Minimum lot must be greater than zero.");
  if (errors.length) return { ok: false, errors };

  const warnings: string[] = [];
  const riskAmount = (i.balance * i.riskPercent) / 100;
  const stopDistance = Math.abs(i.entry - i.stop);
  const lossPerLot = stopDistance * i.contractSize * i.quoteToAccountRate;
  const rawLots = riskAmount / lossPerLot;
  let lots = roundDownToStep(rawLots, i.lotStep);

  if (lots < i.minLot) {
    warnings.push(
      `Even the minimum lot (${i.minLot}) would risk about ${round(i.minLot * lossPerLot, 2)} in your account currency, more than your chosen risk of ${round(riskAmount, 2)}. Widen the risk, reduce the stop distance, or do not take this trade.`,
    );
    lots = 0;
  }
  if (i.riskPercent > 2) warnings.push("Many risk frameworks cap risk at 1% to 2% of the account per trade. Your figure is higher.");
  warnings.push("This is an estimate. Spread, slippage, commission and swap can make the real loss larger than the stop distance suggests.");

  const actualRisk = lots * lossPerLot;
  return {
    ok: true, riskAmount, stopDistance, lossPerLot, rawLots, lots, actualRisk,
    actualRiskPercent: (actualRisk / i.balance) * 100, warnings,
  };
}
