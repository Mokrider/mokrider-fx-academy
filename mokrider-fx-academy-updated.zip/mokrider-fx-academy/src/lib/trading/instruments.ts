// Starting-point contract specifications. Brokers differ, so every value is editable in the tools.
export type InstrumentSpec = {
  symbol: string;
  label: string;
  contractSize: number; // units per 1.00 lot
  quoteCurrency: string;
  pipSize: number; // price distance this tool calls 1 pip
  lotStep: number;
  minLot: number;
  note: string;
};

export const INSTRUMENTS: InstrumentSpec[] = [
  {
    symbol: "EURUSD", label: "EURUSD", contractSize: 100000, quoteCurrency: "USD", pipSize: 0.0001, lotStep: 0.01, minLot: 0.01,
    note: "A standard lot is usually 100,000 EUR. One pip is 0.0001 (a fractional pip, or pipette, is 0.00001).",
  },
  {
    symbol: "XAUUSD", label: "XAUUSD (Gold)", contractSize: 100, quoteCurrency: "USD", pipSize: 0.1, lotStep: 0.01, minLot: 0.01,
    note: "Many brokers use 100 oz per standard lot, but not all. What counts as a pip or a point differs by broker (0.10 and 0.01 are both common). Check your broker's specification.",
  },
];

export const CUSTOM_SPEC: InstrumentSpec = {
  symbol: "CUSTOM", label: "Custom instrument", contractSize: 1, quoteCurrency: "USD", pipSize: 0.0001, lotStep: 0.01, minLot: 0.01,
  note: "Enter the contract size and pip size from your broker's specification.",
};
