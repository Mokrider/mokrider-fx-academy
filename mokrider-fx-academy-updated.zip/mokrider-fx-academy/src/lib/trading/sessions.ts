// Approximate FX session windows in each financial centre's LOCAL time, converted with real
// time-zone rules (so daylight saving is handled). These are typical trading-hours windows,
// not official exchange schedules.
export type SessionDef = { id: string; name: string; tz: string; start: [number, number]; end: [number, number] };

export const SESSIONS: SessionDef[] = [
  { id: "sydney", name: "Sydney", tz: "Australia/Sydney", start: [7, 0], end: [16, 0] },
  { id: "tokyo", name: "Tokyo", tz: "Asia/Tokyo", start: [9, 0], end: [18, 0] },
  { id: "london", name: "London", tz: "Europe/London", start: [8, 0], end: [17, 0] },
  { id: "newyork", name: "New York", tz: "America/New_York", start: [8, 0], end: [17, 0] },
];

export const DISPLAY_ZONES = [
  "Africa/Nairobi", "UTC", "Europe/London", "America/New_York", "Asia/Dubai", "Asia/Tokyo", "Australia/Sydney", "Africa/Lagos", "Africa/Johannesburg",
];

const cache = new Map<string, Intl.DateTimeFormat>();
function formatter(tz: string) {
  let f = cache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-GB", {
      timeZone: tz, hourCycle: "h23", weekday: "short", year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
    });
    cache.set(tz, f);
  }
  return f;
}

const WEEKDAY: Record<string, number> = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 };

export function zonedParts(date: Date, tz: string) {
  const m: Record<string, string> = {};
  for (const p of formatter(tz).formatToParts(date)) m[p.type] = p.value;
  return {
    year: Number(m.year), month: Number(m.month), day: Number(m.day),
    hour: Number(m.hour), minute: Number(m.minute), second: Number(m.second), weekday: WEEKDAY[m.weekday] ?? 0,
  };
}

function offsetAt(ms: number, tz: string): number {
  const p = zonedParts(new Date(ms), tz);
  return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second) - Math.floor(ms / 1000) * 1000;
}

/** The UTC instant at which the wall clock in `tz` reads the given local date and time. */
export function zonedLocalToUtc(y: number, mo: number, d: number, h: number, mi: number, tz: string): Date {
  const asUtc = Date.UTC(y, mo - 1, d, h, mi, 0);
  const first = asUtc - offsetAt(asUtc, tz);
  return new Date(asUtc - offsetAt(first, tz));
}

export function isSessionOpen(s: SessionDef, at: Date): boolean {
  const p = zonedParts(at, s.tz);
  if (p.weekday > 5) return false;
  const mins = p.hour * 60 + p.minute;
  return mins >= s.start[0] * 60 + s.start[1] && mins < s.end[0] * 60 + s.end[1];
}

/** Today's window (in the session's own calendar day) as real instants. */
export function sessionWindow(s: SessionDef, at: Date): { start: Date; end: Date } {
  const p = zonedParts(at, s.tz);
  return {
    start: zonedLocalToUtc(p.year, p.month, p.day, s.start[0], s.start[1], s.tz),
    end: zonedLocalToUtc(p.year, p.month, p.day, s.end[0], s.end[1], s.tz),
  };
}

/** Next moment the open/closed state flips, scanning on a 30-minute UTC grid (session edges fall on it). */
export function nextChange(s: SessionDef, at: Date): Date | null {
  const current = isSessionOpen(s, at);
  const step = 30 * 60 * 1000;
  let t = Math.ceil((at.getTime() + 1) / step) * step;
  for (let i = 0; i < 24 * 2 * 9; i++, t += step) {
    if (isSessionOpen(s, new Date(t)) !== current) return new Date(t);
  }
  return null;
}
