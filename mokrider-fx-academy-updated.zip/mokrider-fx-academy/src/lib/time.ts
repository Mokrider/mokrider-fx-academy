// Kenya (Africa/Nairobi) is UTC+3 all year with no daylight saving, so a fixed offset is correct HERE.
// Do NOT reuse this for London or New York, whose offsets change with daylight saving.
const EAT_OFFSET_MS = 3 * 60 * 60 * 1000;

/** Parse a <input type="datetime-local"> value ("2026-11-02T09:30") as East Africa Time. */
export function parseEatInput(value: string | null | undefined): Date | null {
  const v = value?.trim();
  if (!v || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(v)) return null;
  const d = new Date(`${v}:00+03:00`);
  return Number.isNaN(d.getTime()) ? null : d;
}

/** Format a stored date for a datetime-local input, in East Africa Time. */
export function toEatInput(date: Date | null | undefined): string {
  if (!date) return "";
  return new Date(date.getTime() + EAT_OFFSET_MS).toISOString().slice(0, 16);
}

export function formatEat(date: Date): string {
  return (
    new Intl.DateTimeFormat("en-KE", { dateStyle: "medium", timeStyle: "short", timeZone: "Africa/Nairobi" }).format(date) +
    " EAT"
  );
}
