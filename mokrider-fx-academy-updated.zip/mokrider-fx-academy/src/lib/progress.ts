import { prisma } from "@/lib/db";
import { firstIncomplete } from "@/lib/learning/nav";

export type CourseProgress = { total: number; completed: number; percent: number };
export type CourseProgressWithNext = CourseProgress & { nextLessonId: string | null };

/** Pure calculation: percent of lessons completed. Empty courses report 0%. */
export function computeProgress(totalLessonIds: string[], completedLessonIds: Iterable<string>): CourseProgress {
  const total = new Set(totalLessonIds);
  let completed = 0;
  for (const id of new Set(completedLessonIds)) if (total.has(id)) completed++;
  const percent = total.size === 0 ? 0 : Math.round((completed / total.size) * 100);
  return { total: total.size, completed, percent };
}

/** Progress per course for one user, plus the lesson to continue with. Only reads that user's own rows. */
export async function courseProgressFor(userId: string, courseIds: string[]): Promise<Record<string, CourseProgressWithNext>> {
  if (courseIds.length === 0) return {};
  const lessons = await prisma.lesson.findMany({
    where: { module: { courseId: { in: courseIds } } },
    orderBy: [{ module: { position: "asc" } }, { position: "asc" }],
    select: { id: true, module: { select: { courseId: true } } },
  });
  const done = await prisma.lessonProgress.findMany({
    where: { userId, lessonId: { in: lessons.map((l) => l.id) } },
    select: { lessonId: true },
  });
  const doneIds = new Set(done.map((d) => d.lessonId));
  const result: Record<string, CourseProgressWithNext> = {};
  for (const courseId of courseIds) {
    const order = lessons.filter((l) => l.module.courseId === courseId);
    result[courseId] = {
      ...computeProgress(order.map((l) => l.id), doneIds),
      nextLessonId: firstIncomplete(order, doneIds) ?? order[0]?.id ?? null,
    };
  }
  return result;
}
