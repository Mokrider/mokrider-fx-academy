// Money is stored as integer minor units plus an explicit currency. No floats, no silent conversion.

const MINOR_DIGITS: Record<string, number> = { KES: 2, USD: 2, EUR: 2, GBP: 2 };

export function minorDigits(currency: string): number {
  const digits = MINOR_DIGITS[currency.toUpperCase()];
  if (digits === undefined) throw new Error(`Unsupported currency: ${currency}`);
  return digits;
}

/** Format minor units for display, e.g. (150000, "KES") -> "KES 1,500.00". */
export function formatMoney(minor: number, currency: string): string {
  const digits = minorDigits(currency);
  const negative = minor < 0;
  const abs = Math.abs(minor);
  const factor = 10 ** digits;
  const whole = Math.trunc(abs / factor);
  const fraction = String(abs % factor).padStart(digits, "0");
  const grouped = whole.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${negative ? "-" : ""}${currency.toUpperCase()} ${grouped}.${fraction}`;
}

/** Parse a user-typed decimal string ("1500", "1,500.5") to minor units without using floats. */
export function parseMajorToMinor(input: string, currency: string): number | null {
  const digits = minorDigits(currency);
  const cleaned = input.trim().replace(/,/g, "");
  const match = /^(\d+)(?:\.(\d+))?$/.exec(cleaned);
  if (!match) return null;
  const [, whole, fraction = ""] = match;
  if (fraction.length > digits) return null;
  const minor = Number(whole) * 10 ** digits + Number(fraction.padEnd(digits, "0"));
  return Number.isSafeInteger(minor) ? minor : null;
}

/** Sum amounts per currency. Different currencies are never added together. */
export function sumByCurrency(items: { currency: string; amountMinor: number }[]): Record<string, number> {
  const totals: Record<string, number> = {};
  for (const item of items) totals[item.currency] = (totals[item.currency] ?? 0) + item.amountMinor;
  return totals;
}

/** Like parseMajorToMinor but allows a leading + or - (for trade results). */
export function parseSignedMajorToMinor(input: string, currency: string): number | null {
  const t = input.trim();
  if (t.startsWith("-")) {
    const r = parseMajorToMinor(t.slice(1).trim(), currency);
    return r === null ? null : r === 0 ? 0 : -r;
  }
  return parseMajorToMinor(t.startsWith("+") ? t.slice(1).trim() : t, currency);
}
