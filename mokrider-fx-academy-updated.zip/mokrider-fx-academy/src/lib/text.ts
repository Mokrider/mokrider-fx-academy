export function slugify(input: string): string {
  return input
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80)
    .replace(/-+$/g, "");
}

export function readingMinutes(text: string): number {
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.ceil(words / 200));
}

export function parseTags(input: string): string[] {
  const tags = input.split(",").map((t) => slugify(t)).filter(Boolean);
  return [...new Set(tags)].slice(0, 10);
}

export function parseLines(input: string): string[] {
  return input.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
}
