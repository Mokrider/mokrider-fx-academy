import "server-only";

export type EmailResult = { status: "sent" | "dev-sink" | "failed"; id?: string; error?: string };

/**
 * Sends a transactional email through Resend. With no RESEND_API_KEY the message is printed to the
 * server console (development sink) and reported as "dev-sink", never as "sent".
 */
export async function sendEmail(input: { to: string; subject: string; html: string; text?: string }): Promise<EmailResult> {
  const key = process.env.RESEND_API_KEY;
  if (!key) {
    console.info(`[email:dev-sink] to=${input.to} subject="${input.subject}"\n${input.text ?? input.html}`);
    return { status: "dev-sink" };
  }
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM,
        to: input.to,
        subject: input.subject,
        html: input.html,
        text: input.text,
      }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) return { status: "failed", error: `Provider responded ${res.status}` };
    const data = (await res.json()) as { id?: string };
    return { status: "sent", id: data.id };
  } catch {
    return { status: "failed", error: "Network error or timeout" };
  }
}

export function brandedEmail(title: string, bodyHtml: string): string {
  return `<div style="font-family:Arial,sans-serif;background:#070707;padding:32px">
  <div style="max-width:520px;margin:auto;background:#151516;border-radius:8px;padding:28px;color:#FFFFFF">
    <p style="color:#FF3B3B;font-size:14px;margin:0 0 12px">MOKRIDER FX ACADEMY</p>
    <h1 style="font-size:20px;margin:0 0 16px">${title}</h1>
    ${bodyHtml}
    <p style="color:#B8B8BF;font-size:12px;margin-top:24px">Educational content only. Trading involves risk of loss.</p>
  </div></div>`;
}
