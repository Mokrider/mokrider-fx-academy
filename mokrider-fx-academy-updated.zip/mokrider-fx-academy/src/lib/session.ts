import "server-only";
import { cache } from "react";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { hasRoleAtLeast, type RoleName } from "@/lib/permissions";

export type CurrentUser = { id: string; name: string; email: string; role: RoleName };

/** Returns the signed-in user, or null. Role and suspension are always read from the database. */
export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  try {
    const session = await auth.api.getSession({ headers: await headers() });
    if (!session) return null;
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { id: true, name: true, email: true, role: true, suspendedAt: true },
    });
    if (!user || user.suspendedAt) return null;
    return { id: user.id, name: user.name, email: user.email, role: user.role };
  } catch {
    return null;
  }
});

export async function requireUser(nextPath = "/dashboard"): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(nextPath)}`);
  return user;
}

/** Server-side role gate. Use at the top of every protected page and server action. */
export async function requireRole(minimum: RoleName, nextPath = "/"): Promise<CurrentUser> {
  const user = await requireUser(nextPath);
  if (!hasRoleAtLeast(user.role, minimum)) redirect("/");
  return user;
}

/** Only allow same-site relative redirect targets. */
export function safeNextPath(next: string | undefined, fallback = "/dashboard"): string {
  if (!next || !next.startsWith("/") || next.startsWith("//")) return fallback;
  return next;
}
