export type Status = "DRAFT" | "SCHEDULED" | "PUBLISHED" | "ARCHIVED";

/**
 * The time an item goes live. Scheduled items use the chosen time; published items keep any earlier
 * publish time, otherwise "now". Drafts/archived keep whatever they had.
 */
export function resolvePublishedAt(status: Status, publishAt: Date | null, existing: Date | null, now = new Date()): Date | null {
  if (status === "SCHEDULED") return publishAt;
  if (status === "PUBLISHED") return publishAt ?? existing ?? now;
  return existing ?? null;
}

export function isVisible(status: Status, publishedAt: Date | null, now = new Date()): boolean {
  return (status === "PUBLISHED" || status === "SCHEDULED") && publishedAt !== null && publishedAt <= now;
}

/** Prisma `where` fragment for publicly visible content (scheduled items appear once their time passes). */
export function visibleWhere(now = new Date()) {
  return { status: { in: ["PUBLISHED", "SCHEDULED"] as ("PUBLISHED" | "SCHEDULED")[] }, publishedAt: { lte: now } };
}
