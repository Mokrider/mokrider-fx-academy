/**
 * Content-Security-Policy. Scripts still allow 'unsafe-inline' because Next.js and the theme script
 * use inline scripts; moving to per-request nonces is a later hardening step. Everything else is locked down:
 * no plugins, no framing of this site, forms only post to this site, and iframes only from YouTube and Vimeo.
 */
export function buildCsp(isProd: boolean): string {
  const d: Record<string, string[]> = {
    "default-src": ["'self'"],
    "script-src": ["'self'", "'unsafe-inline'", ...(isProd ? [] : ["'unsafe-eval'"])],
    "style-src": ["'self'", "'unsafe-inline'"],
    "img-src": ["'self'", "data:", "blob:", "https:"],
    "font-src": ["'self'", "data:"],
    "connect-src": ["'self'", ...(isProd ? [] : ["ws:", "wss:"])],
    "frame-src": ["https://www.youtube-nocookie.com", "https://player.vimeo.com"],
    "object-src": ["'none'"],
    "base-uri": ["'self'"],
    "form-action": ["'self'"],
    "frame-ancestors": ["'none'"],
  };
  const parts = Object.entries(d).map(([k, v]) => `${k} ${v.join(" ")}`);
  if (isProd) parts.push("upgrade-insecure-requests");
  return parts.join("; ");
}
