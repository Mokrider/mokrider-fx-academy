import { buildCsp } from "./csp";

type Env = Record<string, string | undefined>;

/** Headers added to every response by the middleware. CSP and HSTS apply in production only. */
export function securityHeaders(env: Env = process.env): Record<string, string> {
  const prod = env.NODE_ENV === "production";
  const headers: Record<string, string> = {};
  if (prod) {
    // Set CSP_MODE=report-only to test a change without blocking anything (violations appear in the browser console).
    headers[env.CSP_MODE === "report-only" ? "Content-Security-Policy-Report-Only" : "Content-Security-Policy"] = buildCsp(true);
    headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains";
  }
  return headers;
}
