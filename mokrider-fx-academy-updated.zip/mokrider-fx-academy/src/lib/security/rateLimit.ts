import "server-only";
import { createHash } from "node:crypto";
import { headers } from "next/headers";
import { prisma } from "@/lib/db";

/** A salted hash of the caller's IP. The raw IP address is never stored. */
export async function clientId(): Promise<string> {
  const h = await headers();
  const ip = (h.get("x-forwarded-for") ?? "").split(",")[0].trim() || h.get("x-real-ip") || "unknown";
  return createHash("sha256").update(`${process.env.BETTER_AUTH_SECRET ?? ""}:${ip}`).digest("hex").slice(0, 32);
}

/** Database-backed counter, so the limit holds across serverless instances. Returns false when the limit is reached. */
export async function allow(key: string, limit: number, windowSeconds: number): Promise<boolean> {
  const since = new Date(Date.now() - windowSeconds * 1000);
  const used = await prisma.rateLimitHit.count({ where: { key, createdAt: { gt: since } } });
  if (used >= limit) return false;
  await prisma.rateLimitHit.create({ data: { key } });
  return true;
}
