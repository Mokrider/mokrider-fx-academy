import "server-only";

// Private-bucket file storage on Supabase Storage (REST). The bucket must be PRIVATE.
// The service-role key stays on the server and is never sent to the browser.
function cfg() {
  const url = process.env.SUPABASE_URL?.replace(/\/$/, "");
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const bucket = process.env.SUPABASE_PRIVATE_BUCKET || "products";
  return { url, key, bucket };
}

export function storageConfigured(): boolean {
  const { url, key } = cfg();
  return Boolean(url && key);
}

const enc = (path: string) => path.split("/").map(encodeURIComponent).join("/");
const headers = (key: string) => ({ Authorization: `Bearer ${key}`, apikey: key });

export function isSafeKey(key: string): boolean {
  return /^[A-Za-z0-9/_.-]{3,200}$/.test(key) && !key.includes("..") && !key.startsWith("/");
}

export async function uploadObject(key: string, bytes: Uint8Array, contentType: string): Promise<void> {
  const { url, key: svc, bucket } = cfg();
  if (!url || !svc || !isSafeKey(key)) throw new Error("Storage is not configured.");
  const res = await fetch(`${url}/storage/v1/object/${bucket}/${enc(key)}`, {
    method: "POST",
    headers: { ...headers(svc), "Content-Type": contentType, "x-upsert": "false" },
    body: Buffer.from(bytes),
    signal: AbortSignal.timeout(60_000),
  });
  if (!res.ok) throw new Error("Upload to storage failed.");
}

export async function objectInfo(key: string): Promise<{ size: number; contentType: string | null } | null> {
  const { url, key: svc, bucket } = cfg();
  if (!url || !svc || !isSafeKey(key)) return null;
  const res = await fetch(`${url}/storage/v1/object/info/${bucket}/${enc(key)}`, { headers: headers(svc), signal: AbortSignal.timeout(15_000) });
  if (!res.ok) return null;
  const data = (await res.json().catch(() => ({}))) as { size?: number; content_type?: string; contentType?: string };
  return { size: Number(data.size ?? 0), contentType: data.content_type ?? data.contentType ?? null };
}

/** A short-lived signed URL. It expires quickly, so a copied link is useless soon after. */
export async function signedDownloadUrl(key: string, filename: string, expiresInSeconds = 60): Promise<string | null> {
  const { url, key: svc, bucket } = cfg();
  if (!url || !svc || !isSafeKey(key)) return null;
  const res = await fetch(`${url}/storage/v1/object/sign/${bucket}/${enc(key)}`, {
    method: "POST",
    headers: { ...headers(svc), "Content-Type": "application/json" },
    body: JSON.stringify({ expiresIn: expiresInSeconds }),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) return null;
  const data = (await res.json().catch(() => ({}))) as { signedURL?: string };
  if (!data.signedURL) return null;
  const sep = data.signedURL.includes("?") ? "&" : "?";
  return `${url}/storage/v1${data.signedURL}${sep}download=${encodeURIComponent(filename)}`;
}
