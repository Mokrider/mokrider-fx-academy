/** Daraja timestamp: YYYYMMDDHHmmss in East Africa Time (UTC+3). */
export function darajaTimestamp(d = new Date()): string {
  return new Date(d.getTime() + 3 * 3600 * 1000).toISOString().slice(0, 19).replace(/[-:T]/g, "");
}

export function stkPassword(shortcode: string, passkey: string, timestamp: string): string {
  return Buffer.from(`${shortcode}${passkey}${timestamp}`).toString("base64");
}

export type StkOutcome = "SUCCEEDED" | "CANCELLED" | "TIMED_OUT" | "FAILED";

/** 0 success, 1032 cancelled by the customer, 1037 timed out, anything else failed. */
export function mapResultCode(code: string | number): StkOutcome {
  const c = String(code);
  if (c === "0") return "SUCCEEDED";
  if (c === "1032") return "CANCELLED";
  if (c === "1037") return "TIMED_OUT";
  return "FAILED";
}

export type ParsedCallback = {
  checkoutRequestId: string;
  merchantRequestId: string | null;
  resultCode: number;
  resultDesc: string;
  amount: number | null;
  receipt: string | null;
  transactionDate: string | null;
};

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

/** Defensive parse of Safaricom's STK callback body. Returns null if it does not look like one. */
export function parseStkCallback(body: unknown): ParsedCallback | null {
  if (!isRecord(body) || !isRecord(body.Body) || !isRecord(body.Body.stkCallback)) return null;
  const cb = body.Body.stkCallback;
  if (typeof cb.CheckoutRequestID !== "string" || cb.CheckoutRequestID.length === 0 || cb.CheckoutRequestID.length > 100) return null;
  const resultCode = Number(cb.ResultCode);
  if (!Number.isInteger(resultCode)) return null;

  const meta: Record<string, unknown> = {};
  if (isRecord(cb.CallbackMetadata) && Array.isArray(cb.CallbackMetadata.Item)) {
    for (const item of cb.CallbackMetadata.Item) {
      if (isRecord(item) && typeof item.Name === "string") meta[item.Name] = item.Value;
    }
  }
  const amount = typeof meta.Amount === "number" ? meta.Amount : null;
  const receipt = typeof meta.MpesaReceiptNumber === "string" && /^[A-Z0-9]{8,15}$/.test(meta.MpesaReceiptNumber) ? meta.MpesaReceiptNumber : null;
  return {
    checkoutRequestId: cb.CheckoutRequestID,
    merchantRequestId: typeof cb.MerchantRequestID === "string" ? cb.MerchantRequestID : null,
    resultCode,
    resultDesc: typeof cb.ResultDesc === "string" ? cb.ResultDesc.slice(0, 200) : "",
    amount,
    receipt,
    transactionDate: meta.TransactionDate != null ? String(meta.TransactionDate).slice(0, 20) : null,
  };
}
