import "server-only";
import { darajaTimestamp, stkPassword } from "@/lib/mpesa/parse";

export class DarajaError extends Error {}

function env() {
  const e = process.env;
  return {
    live: e.MPESA_ENV === "production",
    key: e.MPESA_CONSUMER_KEY, secret: e.MPESA_CONSUMER_SECRET, shortcode: e.MPESA_SHORTCODE, passkey: e.MPESA_PASSKEY,
    callbackBase: e.MPESA_CALLBACK_BASE_URL, callbackSecret: e.MPESA_CALLBACK_SECRET,
    txType: e.MPESA_TRANSACTION_TYPE === "CustomerBuyGoodsOnline" ? "CustomerBuyGoodsOnline" : "CustomerPayBillOnline",
  };
}

export function isMpesaConfigured(): boolean {
  const c = env();
  return Boolean(c.key && c.secret && c.shortcode && c.passkey && c.callbackBase?.startsWith("https://") && c.callbackSecret && c.callbackSecret.length >= 16);
}

const baseUrl = () => (env().live ? "https://api.safaricom.co.ke" : "https://sandbox.safaricom.co.ke");

let cached: { token: string; expires: number } | null = null;

async function accessToken(): Promise<string> {
  if (cached && cached.expires > Date.now() + 30_000) return cached.token;
  const c = env();
  const res = await fetch(`${baseUrl()}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${Buffer.from(`${c.key}:${c.secret}`).toString("base64")}` },
    signal: AbortSignal.timeout(15_000),
    cache: "no-store",
  });
  if (!res.ok) throw new DarajaError("Could not authenticate with M-Pesa.");
  const data = (await res.json()) as { access_token?: string; expires_in?: string | number };
  if (!data.access_token) throw new DarajaError("Could not authenticate with M-Pesa.");
  cached = { token: data.access_token, expires: Date.now() + Number(data.expires_in ?? 3000) * 1000 };
  return data.access_token;
}

export type StkPushInput = { phone: string; amountShillings: number; reference: string; description: string };

export async function stkPush(i: StkPushInput): Promise<{ checkoutRequestId: string; merchantRequestId: string }> {
  const c = env();
  const timestamp = darajaTimestamp();
  const body = {
    BusinessShortCode: c.shortcode,
    Password: stkPassword(c.shortcode as string, c.passkey as string, timestamp),
    Timestamp: timestamp,
    TransactionType: c.txType,
    Amount: i.amountShillings,
    PartyA: i.phone,
    PartyB: c.shortcode,
    PhoneNumber: i.phone,
    CallBackURL: `${c.callbackBase}/api/mpesa/callback/${c.callbackSecret}`,
    AccountReference: i.reference.slice(0, 12),
    TransactionDesc: i.description.slice(0, 13),
  };
  const res = await fetch(`${baseUrl()}/mpesa/stkpush/v1/processrequest`, {
    method: "POST",
    headers: { Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(20_000),
    cache: "no-store",
  });
  const data = (await res.json().catch(() => ({}))) as { ResponseCode?: string; CheckoutRequestID?: string; MerchantRequestID?: string; errorMessage?: string; ResponseDescription?: string };
  if (!res.ok || data.ResponseCode !== "0" || !data.CheckoutRequestID) {
    throw new DarajaError(data.errorMessage || data.ResponseDescription || "M-Pesa did not accept the payment request.");
  }
  return { checkoutRequestId: data.CheckoutRequestID, merchantRequestId: data.MerchantRequestID ?? "" };
}

export type StkQuery = { state: "pending" } | { state: "result"; resultCode: string; resultDesc: string };

/** Ask Safaricom directly what happened to a payment request. This is the source of truth we act on. */
export async function stkQuery(checkoutRequestId: string): Promise<StkQuery> {
  const c = env();
  const timestamp = darajaTimestamp();
  const res = await fetch(`${baseUrl()}/mpesa/stkpushquery/v1/query`, {
    method: "POST",
    headers: { Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      BusinessShortCode: c.shortcode,
      Password: stkPassword(c.shortcode as string, c.passkey as string, timestamp),
      Timestamp: timestamp,
      CheckoutRequestID: checkoutRequestId,
    }),
    signal: AbortSignal.timeout(15_000),
    cache: "no-store",
  });
  const data = (await res.json().catch(() => ({}))) as { ResultCode?: string | number; ResultDesc?: string; errorCode?: string };
  if (data.ResultCode !== undefined && data.ResultCode !== null) return { state: "result", resultCode: String(data.ResultCode), resultDesc: String(data.ResultDesc ?? "") };
  if (data.errorCode === "500.001.1001") return { state: "pending" }; // "transaction is being processed"
  throw new DarajaError("Could not check the payment status.");
}
