// Seeds the curriculum OUTLINE as DRAFT courses and the (not live) membership plans.
// Safe to re-run: it upserts by slug and never deletes anything.
import { PrismaClient } from "@prisma/client";
import { curriculum } from "../src/content/curriculum";

const prisma = new PrismaClient();

async function main() {
  for (const c of curriculum) {
    const course = await prisma.course.upsert({
      where: { slug: c.slug },
      update: {},
      create: { slug: c.slug, title: c.title, summary: c.summary, level: c.level, status: "DRAFT", outlineOnly: true },
    });
    const existing = await prisma.module.count({ where: { courseId: course.id } });
    if (existing === 0) {
      await prisma.module.create({
        data: {
          courseId: course.id,
          title: "Course outline",
          position: 1,
          lessons: {
            create: c.topics.map((t, i) => ({
              title: t,
              slug: t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""),
              position: i + 1,
              content: "Outline only. Lesson content is still being written.",
            })),
          },
        },
      });
    }
  }

  const plans = [
    { slug: "free", name: "Free Member", description: "Free articles, selected free lessons, sample resources and newsletter access.", perks: ["Free articles", "Selected free lessons", "Sample resources", "Newsletter"] },
    { slug: "student", name: "Student", description: "Access to the courses and PDFs you have purchased, with progress tracking.", perks: ["Purchased courses", "Purchased PDFs", "Progress tracking"] },
    { slug: "premium", name: "Premium Member", description: "Configured premium content and member-only resources.", perks: ["Premium content", "Member-only resources"] },
    { slug: "mentorship-student", name: "Mentorship Student", description: "Material, assignments and booked sessions for enrolled mentorship students.", perks: ["Mentorship material", "Booked sessions", "Assignments"] },
  ];
  for (const p of plans) {
    await prisma.membershipPlan.upsert({ where: { slug: p.slug }, update: {}, create: { ...p, isLive: false, status: "DRAFT" } });
  }
  console.log("Seed complete: draft course outlines and membership plans (not live).");
}

main().finally(() => prisma.$disconnect());
