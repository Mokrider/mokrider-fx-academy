// Crawls your running site and reports every internal link that does not work.
// Usage (site must be running):  npm run check:links            or  npm run check:links -- http://localhost:3000
const base = (process.argv[2] ?? "http://localhost:3000").replace(/\/$/, "");
const MAX_PAGES = 150;

const seen = new Set();
const queue = ["/"];
const problems = [];

function internal(href) {
  if (!href || href.startsWith("#") || /^(mailto:|tel:|javascript:|data:)/i.test(href)) return null;
  try {
    const u = new URL(href, base + "/");
    if (u.origin !== new URL(base).origin) return null;
    return u.pathname.replace(/\/$/, "") || "/";
  } catch {
    return null;
  }
}

while (queue.length && seen.size < MAX_PAGES) {
  const path = queue.shift();
  if (seen.has(path)) continue;
  seen.add(path);
  let res;
  try {
    res = await fetch(base + path, { redirect: "manual" });
  } catch (e) {
    console.error(`Cannot reach ${base}. Is "npm run dev" running?`);
    process.exit(2);
  }
  // 3xx is fine (sign-in redirects for private pages). 4xx/5xx is a problem.
  if (res.status >= 400) {
    problems.push(`${res.status}  ${path}`);
    continue;
  }
  if (res.status >= 300 || !(res.headers.get("content-type") ?? "").includes("text/html")) continue;
  const html = await res.text();
  for (const m of html.matchAll(/<a\b[^>]*?\shref=["']([^"']+)["']/gi)) {
    const t = internal(m[1].replace(/&amp;/g, "&"));
    if (t && !seen.has(t) && !t.startsWith("/_next")) queue.push(t);
  }
}

console.log(`Checked ${seen.size} pages on ${base}`);
if (problems.length === 0) {
  console.log("All links work.");
} else {
  console.log("\nBROKEN:");
  for (const p of problems) console.log("  " + p);
  process.exit(1);
}
