// Usage: npm run admin:promote -- you@example.com
// Register the account on the site first, then run this once to make it an administrator.
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const email = process.argv[2]?.trim().toLowerCase();
  if (!email) throw new Error("Provide the account email: npm run admin:promote -- you@example.com");
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new Error(`No account found for ${email}. Register on the site first.`);
  await prisma.user.update({ where: { id: user.id }, data: { role: "ADMIN" } });
  await prisma.auditLog.create({ data: { actorId: null, action: "role.promote-admin", entity: "User", entityId: user.id, meta: { via: "cli" } } });
  console.log(`${email} is now an administrator.`);
}

main().catch((e) => { console.error(e.message); process.exit(1); }).finally(() => prisma.$disconnect());
