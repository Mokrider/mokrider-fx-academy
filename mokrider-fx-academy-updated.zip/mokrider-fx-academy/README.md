# MOKRIDER FX ACADEMY

Trading education platform (XAUUSD and EURUSD). Next.js (App Router) + TypeScript + Tailwind v4, PostgreSQL on Neon via Prisma, Better Auth, deployed on Vercel.

## Status: Phases 1 to 5 plus theme and security hardening (Phase 6a)

| Area | Status |
|---|---|
| Design system: black and red "flyer" theme (chrome-white italic headlines, red pill buttons, amber Gold accents), dark + light | Implemented, not yet viewed in a browser |
| Home page, header, footer, risk disclosure (draft text) | Implemented, not yet viewed in a browser |
| Database schema (all models in the brief) | Written, **migration not yet generated or applied** |
| Sign up / sign in / sign out (email + password) | Implemented, not yet run |
| Google sign-in | Implemented, needs credentials |
| Password reset | Server side configured; **reset pages not built yet** |
| Roles + server-side guards (`requireUser`, `requireRole`) | Implemented; permission logic unit-tested |
| Student dashboard (database-backed, empty states) | Implemented, not yet run |
| Admin overview (database-backed metrics) | Implemented, not yet run |
| Newsletter signup with recorded consent | Implemented, not yet run |
| Money helpers, progress calculation | Implemented; logic spot-checked in Node |
| Learn catalogue (search/filter) + course detail + free enrollment | Implemented, not yet run |
| Blog (search, tags, pagination, related, JSON-LD) | Implemented, not yet run |
| Market analysis (timestamps, scenarios, invalidation, historical flag) | Implemented, not yet run |
| Mentorship + About pages (read-only, booking not live) | Implemented, not yet run |
| Admin editors: courses, articles, analyses, mentorship packages, about | Implemented, not yet run |
| Draft / scheduled / published / archived with East Africa Time | Implemented; logic unit-tested |
| Position-size, risk/reward, compounding, pip calculators | Implemented; calculation logic unit-tested |
| Session clock (daylight saving handled with IANA zones) | Implemented; logic unit-tested |
| Trading journal (private, per-currency stats) | Implemented; statistics unit-tested, pages not yet run |
| Economic calendar | Not built: needs a licensed data provider |
| Lesson player (video embeds, free previews, prev/next, mark complete, progress, continue links) | Implemented; helpers unit-tested, pages not yet run |
| Admin lesson editor (modules, lessons, reorder, content, video link, free preview) | Implemented, not yet run |
| Quizzes, assignments, lesson file resources, certificates | Not built yet (schema exists) |
| Shop, cart, orders, secure downloads | Implemented; pricing, cart and order-state logic unit-tested, pages not yet run |
| M-Pesa STK Push (sandbox-ready), verified settlement, idempotent callback | Implemented; message parsing unit-tested. **Awaiting Daraja credentials. Not live.** |
| Admin products, file versions, orders, refund records | Implemented, not yet run |
| Mentorship booking: sessions, seat locking, notice/cancel windows, blackout dates | Implemented; rules unit-tested, pages not yet run |
| Booking payments (pay with M-Pesa, seat re-checked on payment, auto refund request if the seat was lost) | Implemented, not yet run |
| Booking emails (confirmation, reminder, moved) | Implemented; sent via Resend once configured, otherwise printed to the server console |
| Daily cron: reminders and expiring unpaid bookings (vercel.json) | Implemented; needs CRON_SECRET |
| Private 1-on-1 mentorship application page, stored in the database, with an admin review screen and open/closed switch | Implemented, not yet run |
| Packages with several sessions (only the first session is booked in the app) | Partly built |
| Card payments (international), subscriptions | Not built |
| Guest checkout, product reviews, coupons | Not built (an account is required to buy) |
| Categories, social sharing buttons, legal pages (privacy, terms, refunds, affiliate) | Not yet built |
| Image uploads (Cloudinary/Supabase Storage) | Not yet built; editors take image URLs |
| Courses/lessons seed (outline, as DRAFT) | Written, not yet run |
| M-Pesa, cards, downloads, bookings, journal, calculators | **Not started** |
| Affiliates, memberships, community | Schema only |
| Vitest unit tests | Written, **not yet run** (needs `npm install`) |
| Playwright end-to-end tests | Not started |
| Rate limiting (newsletter, booking, free claims in the database; sign-in endpoints in memory) | Implemented, not yet run |
| Security headers, HSTS and Content-Security-Policy (production only; set CSP_MODE=report-only to test) | Implemented; header logic unit-tested. Scripts still allow inline until nonces are added |

Nothing here has been built or deployed yet, because the authoring environment had no internet access.
Run the steps below and fix anything the compiler reports before building further.

## Ideas adapted from bghub.co.ke

| Idea | Where it lives |
|---|---|
| Hero with eyebrow, three call-to-actions and pillar chips | `src/app/page.tsx` |
| Three "doors in" cards, six service cards, numbered "how it works" steps, closing call-to-action | `src/app/page.tsx` |
| Live "what is open right now" panel (counts read from the database, never typed in) | `src/components/StatusPanel.tsx` |
| Auto-advancing news panel (5 s, pauses on hover/focus, jump bars, pause button, respects reduced motion) | `src/components/LatestCarousel.tsx` |
| Pre-filled email dialog (Gmail, Outlook, default app, copy address) + WhatsApp chat + back-to-top dock | `src/components/ContactDock.tsx`, `ContactTrigger.tsx`, `src/lib/contact.ts` |
| Contact page with topic buttons that pre-write the message | `src/app/contact/page.tsx` |
| Stories page with voice filter, "what could have been better", visible consent policy | `src/app/stories/page.tsx`, `src/content/stories.ts` |
| Mentorship "how it works" steps and "not sure which route fits?" prompt | `src/app/mentorship/page.tsx` |
| Four-column footer, social links, skip link, breadcrumbs, share image, Organization JSON-LD | `SiteFooter.tsx`, `layout.tsx`, `Breadcrumbs.tsx`, `opengraph-image.tsx` |

| Sponsor a student page: ways to give, USD 100 full sponsorship, public selection criteria, contact-first (no payment taken on site) | `src/app/sponsor/page.tsx`, `src/content/sponsorship.ts` |
| Numbers strip: owner-stated teaching facts + a live enrolment count that only shows when above zero | `src/components/FactsStrip.tsx`, `src/content/facts.ts` |
| Session photo gallery, hidden until real photos are added | `src/components/SessionGallery.tsx`, `src/content/gallery.ts` |
| Market Coach: adaptive quiz (58 questions) + AI "explain it" mode that asks open questions and marks answers | `src/app/coach`, `src/components/coach`, `src/lib/coach`, `src/app/api/coach/route.ts` |
| Session timer: live local time, countdowns, 24-hour map, what each session is usually like | `src/components/calc/SessionClock.tsx`, `src/lib/trading/sessionInfo.ts` |

Set `NEXT_PUBLIC_WHATSAPP_NUMBER`, hours, location and social links in `.env.local` (see `.env.example`); anything left empty is hidden.
`src/content/stories.ts` ships empty on purpose: add a story only with the person's written permission.

## 1. Run it locally

```bash
npm install
cp .env.example .env.local       # then fill in the values
npm run db:migrate -- --name init  # creates and applies the first migration
npm run db:seed                  # draft course outlines + membership plans (not live)
npm run dev
```

Open http://localhost:3000.

### Checks
```bash
npm run typecheck
npm run lint
npm test
npm run build
```
If `npm install` resolves different package versions than expected, the Better Auth and Prisma APIs
used here are the stable v1 / v6 ones; check their docs if a type error appears.

## 2. Neon database

1. Create a project at https://neon.tech.
2. Copy the **pooled** connection string into `DATABASE_URL` and the **direct** one into `DIRECT_URL`.
3. Run `npm run db:migrate -- --name init` locally once. Commit the generated `prisma/migrations` folder.
4. In production, apply migrations with `npm run db:deploy` (never `migrate reset`).

Booking capacity: the schema enforces one booking per user per slot. Slot capacity is checked inside a
transaction when bookings are built (Phase 5). Add a raw-SQL partial index at that point if needed.

## 3. Create your admin account

1. Register on `/register`.
2. Run `npm run admin:promote -- you@example.com`.
3. Sign in and open `/admin`.

Roles are read from the database on every protected request, and `role` cannot be set from the sign-up form.

## 4. Deploy to Vercel

1. Push to GitHub and import the repo in Vercel.
2. Add every variable from `.env.example` in Vercel project settings (Production + Preview).
3. Set `NEXT_PUBLIC_APP_URL` and `BETTER_AUTH_URL` to your live URL.
4. Run `npm run db:deploy` against the Neon database (locally with the production `DIRECT_URL`, or in a CI step).
5. Deploy, then open the live site and test sign-up, sign-in and `/admin`.

## Principles baked in
- Money = integer minor units + explicit currency. No floats, no silent conversion.
- No fake data: sample/outline content is labelled, courses start as DRAFT.
- Unconfigured integrations are labelled as not live; emails go to a console sink without `RESEND_API_KEY`.
- Authorisation is enforced on the server, never only in the UI.

## Next phases
2. Public site (courses, blog, market analysis, mentorship pages from the database, legal pages)
3. Student tools (calculators, journal, session clock, lesson player and progress)
4. Commerce (cart, orders, M-Pesa Daraja sandbox adapter, idempotent callbacks, signed downloads)
5. Admin editors and mentorship booking
6. Affiliates, memberships, community, email templates, end-to-end tests

## M-Pesa setup (sandbox first)

1. Create a free account at https://developer.safaricom.co.ke and add an app with the Lipa Na M-Pesa Sandbox product.
2. Copy the consumer key and secret, plus the sandbox shortcode and passkey from the simulator page, into `.env`.
3. Set `MPESA_CALLBACK_SECRET` to 16+ random characters.
4. Set `MPESA_CALLBACK_BASE_URL` to a public https address. Locally, run a tunnel (for example Cloudflare Tunnel or ngrok) pointing at port 3000 and use its https URL.
   If you skip the callback, payments are still settled: the order page asks Safaricom for the result every few seconds.
5. Test with the sandbox test phone number from the Daraja simulator.
6. Going live needs Safaricom production approval and your real shortcode and passkey. Then set `MPESA_ENV=production`.

How payments are trusted: a callback only prompts a check. Access is granted only after Safaricom's STK Query API confirms the result, and orders cannot be marked paid by hand.

## Private files (Supabase Storage)

Create a **private** bucket named `products`, then set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`. Uploads in the admin are limited to 4 MB (a serverless request limit).
For larger files, upload them in the Supabase dashboard and register the path in the product's "Add a version" form.

## Booking notes

- Students can book until 2 hours before a session and cancel up to 24 hours before. Unpaid bookings hold a seat for 30 minutes. These numbers live in `src/lib/booking/rules.ts`.
- Double-booking is prevented by locking the session row inside a database transaction, so two people cannot take the last seat together.
- If someone pays after losing their seat, the booking is cancelled and a refund request is recorded automatically.
- Cancellations by students and admins create a refund request. The app never moves money: you refund the customer yourself, then record it on the order page.
- Run `pnpm exec prisma migrate dev --name booking_reminders` after updating (adds one column).

## Theme

Colours live in `src/app/globals.css` (variables near the top). `--accent` is the red, `--amber` is the Gold highlight, `--bg`/`--surface`/`--card` are the blacks.
Fonts are Montserrat (headings, italic), Yellowtail (script accent line) and Schibsted Grotesk (body), loaded in `src/app/layout.tsx`.
